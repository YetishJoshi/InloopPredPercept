/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2016, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     TAppDecTop.cpp
    \brief    Decoder application class
*/

  //================================
  // YGJ - Modifed decoder
  //================================

#include <list>
#include <vector>
#include <stdio.h>
#include <fcntl.h>
#include <assert.h>

#include "TAppDecTop.h"
#include "TLibDecoder/AnnexBread.h"
#include "TLibDecoder/NALread.h"
#if RExt__DECODER_DEBUG_BIT_STATISTICS
#include "TLibCommon/TComCodingStatistics.h"
#endif


//================================
// YGJ - Modifed decoder
#include <math.h>       /* log */
#include "lodepng.h" // Ensure this is added to the project file, else expect linker errors and obj to the make file  (TAppDecoderAnalyser and TAppDecoder)

// http://stackoverflow.com/questions/5781597/incomplete-type-is-not-allowed
#include <sstream>

// http://www.cplusplus.com/doc/tutorial/files/
// Need to create separate log files
#include <iostream>
#include <fstream>  

// No real difference, about the same amount of time. Nevermind. Leave it for now.
const unsigned short LumaSq_LUT[256] =
	{0,1,4,9,16,25,36,49,64,81,100,121,144,169,196,225,
	256,289,324,361,400,441,484,529,576,625,676,729,784,841,900,961,
	1024,1089,1156,1225,1296,1369,1444,1521,1600,1681,1764,1849,1936,2025,2116,2209,
	2304,2401,2500,2601,2704,2809,2916,3025,3136,3249,3364,3481,3600,3721,3844,3969,
	4096,4225,4356,4489,4624,4761,4900,5041,5184,5329,5476,5625,5776,5929,6084,6241,
	6400,6561,6724,6889,7056,7225,7396,7569,7744,7921,8100,8281,8464,8649,8836,9025,
	9216,9409,9604,9801,10000,10201,10404,10609,10816,11025,11236,11449,11664,11881,12100,12321,
	12544,12769,12996,13225,13456,13689,13924,14161,14400,14641,14884,15129,15376,15625,15876,16129,
	16384,16641,16900,17161,17424,17689,17956,18225,18496,18769,19044,19321,19600,19881,20164,20449,
	20736,21025,21316,21609,21904,22201,22500,22801,23104,23409,23716,24025,24336,24649,24964,25281,
	25600,25921,26244,26569,26896,27225,27556,27889,28224,28561,28900,29241,29584,29929,30276,30625,
	30976,31329,31684,32041,32400,32761,33124,33489,33856,34225,34596,34969,35344,35721,36100,36481,
	36864,37249,37636,38025,38416,38809,39204,39601,40000,40401,40804,41209,41616,42025,42436,42849,
	43264,43681,44100,44521,44944,45369,45796,46225,46656,47089,47524,47961,48400,48841,49284,49729,
	50176,50625,51076,51529,51984,52441,52900,53361,53824,54289,54756,55225,55696,56169,56644,57121,
	57600,58081,58564,59049,59536,60025,60516,61009,61504,62001,62500,63001,63504,64009,64516,65025
};

// quartMaxLimit = 2^x + 2^(x-1)
// For x from 12 to 18
// Starting from 2^12 + 2^11 = 6144
// Adds headroom to cover range of scores for SAD/Had with and without APC
// However, the values calculated are too high for 64x64 and 64x32 (and 64x32), so they must be lowered
//
////        8   16  32  64
////     + ----------------
////  8  |  3    6   0   0
////  16 |  6   12  12   0
////  32 |  0   12  24  49
////  64 |  0    0  49  98
////
//long quartMaxLimit[4][4] = {
//    {3072, 6144,0, 0}, // {6144, 6144,0, 0},
//    {6144, 12288, 12288, 0}, // {12288, 24576, 49152, 0},
//    {0, 12288, 24576, 49152}, //    {0, 49152, 98304, 196608},
//    {0,0, 49152, 98304},   // {0,0, 196608, 393216},
//};

// As SSE is always sq, it will be 1D array
// 8x8, 16x16, 32x32, 64x64
//long quartMaxLimitSAD[4] = {3072, 12288, 49152, 98304};
//int  maxLimitSAD_k[4] = {3, 12, 24, 98};
int  maxLimitSAD_k[4] = {16, 64, 256, 1024};

// Used in Had and SAD where ACCS determines if APC is required.
//int APCCrossCornSubThresh = 128; // TComRdCost::APCCrossCornSubThresh;
int APCCrossCornSubThresh = 128; // TComRdCost::APCCrossCornSubThresh;
int APC_Downscale = 7; // TComRdCost::APCCrossCornSubThresh;
int RC_APC_Downscale = 5; // TComRdCost::APCCrossCornSubThresh;

// Now for SSE
// As SSE is always sq, it will be 1D array
// 8x8, 16x16, 32x32, 64x64
//long quartMaxLimitSSE[4] = {16384, 65536, 262144, 1048576};
//int maxLimitSSE_k[4] = {16, 64, 256, 1024};
int maxLimitSSE_k[4] = {64, 256, 1024, 4096};

// Using NormDistribution (1 minus [0.0 to 2.0].
//  This means that the range of max score is less as element in array increases
// e.g. while last element would be 1 - 97% , in order to save memory the values have been scaled up by 10,000 to get 228.
int NormDist_OneMin10k [21] = {5000,4602,4207,3821,3446,3085,2743,2420,2119,1841,1587,1357,1151,968,808,668,548,446,359,287,228};

// threshold max  = (a x b) x (a_scale x b_scale x c_scale) 
// where a = maxLimitSAD_k, or SSE version  and a_scale is times 1,024
// a is user defined by block size
// b is NormDist_OneMin10k and b_scale is divide by 10,000, (1/10000)
// b is selected  to represented the range of max via a setting of 0 to 20. (non-linear)
// Note a_scale * b_scale is fixed at 0.1024
// c_scale is linear scaling of 1/(2^n), where n is setting by the user ranging from 0 to 16.

// For rate-control, activity maps the max is different, since the differences of pixel intensities are used not the differences vs the original.
// This means scores are particularly high.
// For that the activity must be scaled to show greater contrast

// Applicable to MSVC (Microsoft Visual C++ compiler)
// http://stackoverflow.com/questions/70013/how-to-detect-if-im-compiling-code-with-visual-studio-2008
// and elsewhere in this codebase
#if _MSC_VER //> 1000
#pragma once


// Calculates log2 of number.
// http://stackoverflow.com/questions/994593/how-to-do-an-integer-log2-in-c
//static unsigned int log2 (unsigned int val) {
static double log2 (double n) {

    // log(n)/log(2) is log2.
    return log( n ) / log( 2.0 );

}
#endif // _MSC_VER > 1000

//static inline uint32_t log2(const uint32_t x) {
//  uint32_t y;
//  asm ( "\tbsr %1, %0\n"
//      : "=r"(y)
//      : "r" (x)
//  );
//  return y;
//}

//================================

//! \ingroup TAppDecoder
//! \{

// ====================================================================================================================
// Constructor / destructor / initialization / destroy
// ====================================================================================================================

TAppDecTop::TAppDecTop()
: m_iPOCLastDisplay(-MAX_INT)
 ,m_pcSeiColourRemappingInfoPrevious(NULL)
{
}

Void TAppDecTop::create()
{
  //================================
  // YGJ - Modifed decoder
  m_pcPicYuvOrg = new TComPicYuv;
  //================================	
}

Void TAppDecTop::destroy()
{
  m_bitstreamFileName.clear();
  m_reconFileName.clear();
}

// ====================================================================================================================
// Public member functions
// ====================================================================================================================

/**
 - create internal class
 - initialize internal class
 - until the end of the bitstream, call decoding function in TDecTop class
 - delete allocated buffers
 - destroy internal class
 .
 */
Void TAppDecTop::decode()
{
  Int                 poc;
  TComList<TComPic*>* pcListPic = NULL;

  ifstream bitstreamFile(m_bitstreamFileName.c_str(), ifstream::in | ifstream::binary);
  if (!bitstreamFile)
  {
    fprintf(stderr, "\nfailed to open bitstream file `%s' for reading\n", m_bitstreamFileName.c_str());
    exit(EXIT_FAILURE);
  }

  InputByteStream bytestream(bitstreamFile);

  if (!m_outputDecodedSEIMessagesFilename.empty() && m_outputDecodedSEIMessagesFilename!="-")
  {
    m_seiMessageFileStream.open(m_outputDecodedSEIMessagesFilename.c_str(), std::ios::out);
    if (!m_seiMessageFileStream.is_open() || !m_seiMessageFileStream.good())
    {
      fprintf(stderr, "\nUnable to open file `%s' for writing decoded SEI messages\n", m_outputDecodedSEIMessagesFilename.c_str());
      exit(EXIT_FAILURE);
    }
  }

  // create & initialize internal classes
  xCreateDecLib();
  xInitDecLib  ();
  m_iPOCLastDisplay += m_iSkipFrame;      // set the last displayed POC correctly for skip forward.

  // clear contents of colour-remap-information-SEI output file
  if (!m_colourRemapSEIFileName.empty())
  {
    std::ofstream ofile(m_colourRemapSEIFileName.c_str());
    if (!ofile.good() || !ofile.is_open())
    {
      fprintf(stderr, "\nUnable to open file '%s' for writing colour-remap-information-SEI video\n", m_colourRemapSEIFileName.c_str());
      exit(EXIT_FAILURE);
    }
  }

  // main decoder loop
  Bool openedReconFile = false; // reconstruction file not yet opened. (must be performed after SPS is seen)
  Bool loopFiltered = false;

  //================================
  // YGJ 
  
  ChromaFormat chrfmt = m_inputChromaFormat == 0? CHROMA_400 : m_inputChromaFormat == 1? CHROMA_420 :
					   m_inputChromaFormat == 2? CHROMA_422 : CHROMA_444;

  printf("m_iSourceWidth, %d, m_iSourceHeight, %d, m_inputChromaFormat, %d, chrfmt, %d \n", m_iSourceWidth, m_iSourceHeight, m_inputChromaFormat, chrfmt);

  // YGJ 25th June 2015 - bitDepth
  bitDepthLuma = m_outputBitDepth[CHANNEL_TYPE_LUMA];
  bitDepthChroma = m_outputBitDepth[CHANNEL_TYPE_CHROMA];

  // YGJ 26th June 2015 - commonly used in functions
  height = m_iSourceHeight;
  width = m_iSourceWidth;
  FrameRes = (height*width);
  HalfFrameRes = FrameRes >> 1;
  QuartFrameRes = FrameRes >> 2;
  FourTimesFrameRes = FrameRes << 2;
  FrameRes16th = FrameRes >> 4;

  // YGJ 26th June 2015 - Store parition info and accumulate distortion per given block size
  ptrY_PartitionInfo = (Pel *)calloc(FrameRes16th, sizeof(Pel));    if (ptrY_PartitionInfo == NULL)   printf("calloc failed\n");
  // Existing distortion measures (non-perceptual)
  ptrY_PartDistSAD = (Pel *)calloc(FrameRes16th, sizeof(Pel));    if (ptrY_PartDistSAD == NULL)   printf("calloc failed\n");
  ptrY_PartDistSSE = (Pel *)calloc(FrameRes16th, sizeof(Pel));    if (ptrY_PartDistSSE == NULL)   printf("calloc failed\n");
  // Proposed pixel based perceptual distortion measures
  ptrY_PartDistSASD = (Pel *)calloc(FrameRes16th, sizeof(Pel));    if (ptrY_PartDistSASD == NULL)   printf("calloc failed\n");
  ptrY_PartDistAPC = (Pel *)calloc(FrameRes16th, sizeof(Pel));    if (ptrY_PartDistAPC == NULL)   printf("calloc failed\n");
  // Now to access, navigate and populate each one pointer array.

  cPicYuvTrueOrg.create(m_iSourceWidth, m_iSourceHeight, chrfmt, 64, 64, 4, false);
  m_pcPicYuvOrg->create(m_iSourceWidth, m_iSourceHeight, chrfmt, 64, 64, 4, false);

  //if (m_pchRefFile != NULL)
  if (!m_pchRefFile.empty())
  {
      printf("About to open YUV Ref File, m_outputBitDepth %d \n", m_outputBitDepth[0]);

      // m_cTVideoIOYuvInputFile.open( m_inputFileName,     false, m_inputBitDepth, m_MSBExtendedBitDepth, m_internalBitDepth );  // read  mode
      m_cTVideoIOYuvRefFile.open(m_pchRefFile, false, m_outputBitDepth, m_outputBitDepth, m_internalBitDepth);  // read mode
      //  m_cTVideoIOYuvReconFile.open(m_pchReconFile, true, m_outputBitDepth, m_outputBitDepth, m_internalBitDepth);  // write mode

      printf("Opened YUV Ref File \n");
  }
  //================================

  while (!!bitstreamFile)
  {
    /* location serves to work around a design fault in the decoder, whereby
     * the process of reading a new slice that is the first slice of a new frame
     * requires the TDecTop::decode() method to be called again with the same
     * nal unit. */
#if RExt__DECODER_DEBUG_BIT_STATISTICS
    TComCodingStatistics::TComCodingStatisticsData backupStats(TComCodingStatistics::GetStatistics());
    streampos location = bitstreamFile.tellg() - streampos(bytestream.GetNumBufferedBytes());
#else
    streampos location = bitstreamFile.tellg();
#endif
    AnnexBStats stats = AnnexBStats();

    InputNALUnit nalu;
    byteStreamNALUnit(bytestream, nalu.getBitstream().getFifo(), stats);

    // call actual decoding function
    Bool bNewPicture = false;
    if (nalu.getBitstream().getFifo().empty())
    {
      /* this can happen if the following occur:
       *  - empty input file
       *  - two back-to-back start_code_prefixes
       *  - start_code_prefix immediately followed by EOF
       */
      fprintf(stderr, "Warning: Attempt to decode an empty NAL unit\n");
    }
    else
    {
      read(nalu);
      if( (m_iMaxTemporalLayer >= 0 && nalu.m_temporalId > m_iMaxTemporalLayer) || !isNaluWithinTargetDecLayerIdSet(&nalu)  )
      {
        bNewPicture = false;
      }
      else
      {
        bNewPicture = m_cTDecTop.decode(nalu, m_iSkipFrame, m_iPOCLastDisplay);
        if (bNewPicture)
        {
          bitstreamFile.clear();
          /* location points to the current nalunit payload[1] due to the
           * need for the annexB parser to read three extra bytes.
           * [1] except for the first NAL unit in the file
           *     (but bNewPicture doesn't happen then) */
#if RExt__DECODER_DEBUG_BIT_STATISTICS
          bitstreamFile.seekg(location);
          bytestream.reset();
          TComCodingStatistics::SetStatistics(backupStats);
#else
          bitstreamFile.seekg(location-streamoff(3));
          bytestream.reset();
#endif
        }
      }
    }

    if ( (bNewPicture || !bitstreamFile || nalu.m_nalUnitType == NAL_UNIT_EOS) &&
        !m_cTDecTop.getFirstSliceInSequence () )
    {
      if (!loopFiltered || bitstreamFile)
      {
        m_cTDecTop.executeLoopFilters(poc, pcListPic);
      }
      loopFiltered = (nalu.m_nalUnitType == NAL_UNIT_EOS);
      if (nalu.m_nalUnitType == NAL_UNIT_EOS)
      {
        m_cTDecTop.setFirstSliceInSequence(true);
      }
    }
    else if ( (bNewPicture || !bitstreamFile || nalu.m_nalUnitType == NAL_UNIT_EOS ) &&
              m_cTDecTop.getFirstSliceInSequence () ) 
    {
      m_cTDecTop.setFirstSliceInPicture (true);
    }

    if( pcListPic )
    {
      if ( (!m_reconFileName.empty()) && (!openedReconFile) )
      {
        const BitDepths &bitDepths=pcListPic->front()->getPicSym()->getSPS().getBitDepths(); // use bit depths of first reconstructed picture.
        for (UInt channelType = 0; channelType < MAX_NUM_CHANNEL_TYPE; channelType++)
        {
          if (m_outputBitDepth[channelType] == 0)
          {
            m_outputBitDepth[channelType] = bitDepths.recon[channelType];
          }
        }

        m_cTVideoIOYuvReconFile.open( m_reconFileName, true, m_outputBitDepth, m_outputBitDepth, bitDepths.recon ); // write mode
        openedReconFile = true;
      }
      // write reconstruction to file
      if( bNewPicture )
      {
        xWriteOutput( pcListPic, nalu.m_temporalId );
      }
      if ( (bNewPicture || nalu.m_nalUnitType == NAL_UNIT_CODED_SLICE_CRA) && m_cTDecTop.getNoOutputPriorPicsFlag() )
      {
        m_cTDecTop.checkNoOutputPriorPics( pcListPic );
        m_cTDecTop.setNoOutputPriorPicsFlag (false);
      }
      if ( bNewPicture &&
           (   nalu.m_nalUnitType == NAL_UNIT_CODED_SLICE_IDR_W_RADL
            || nalu.m_nalUnitType == NAL_UNIT_CODED_SLICE_IDR_N_LP
            || nalu.m_nalUnitType == NAL_UNIT_CODED_SLICE_BLA_N_LP
            || nalu.m_nalUnitType == NAL_UNIT_CODED_SLICE_BLA_W_RADL
            || nalu.m_nalUnitType == NAL_UNIT_CODED_SLICE_BLA_W_LP ) )
      {
        xFlushOutput( pcListPic );
      }
      if (nalu.m_nalUnitType == NAL_UNIT_EOS)
      {
        xWriteOutput( pcListPic, nalu.m_temporalId );
        m_cTDecTop.setFirstSliceInPicture (false);
      }
      // write reconstruction to file -- for additional bumping as defined in C.5.2.3
      if(!bNewPicture && nalu.m_nalUnitType >= NAL_UNIT_CODED_SLICE_TRAIL_N && nalu.m_nalUnitType <= NAL_UNIT_RESERVED_VCL31)
      {
        xWriteOutput( pcListPic, nalu.m_temporalId );
      }
    }
  }

  xFlushOutput( pcListPic );
  // delete buffers
  m_cTDecTop.deletePicBuffer();

  // destroy internal classes
  xDestroyDecLib();
}

// ====================================================================================================================
// Protected member functions
// ====================================================================================================================

Void TAppDecTop::xCreateDecLib()
{
  // create decoder class
  m_cTDecTop.create();
}

Void TAppDecTop::xDestroyDecLib()
{
  if ( !m_reconFileName.empty() )
  {
    m_cTVideoIOYuvReconFile.close();
  }

  // destroy decoder class
  m_cTDecTop.destroy();

  if (m_pcSeiColourRemappingInfoPrevious != NULL)
  {
    delete m_pcSeiColourRemappingInfoPrevious;
    m_pcSeiColourRemappingInfoPrevious = NULL;
  }
  
  // destroy decoder class
  m_cTDecTop.destroy();
}

Void TAppDecTop::xInitDecLib()
{
  // initialize decoder class
  m_cTDecTop.init();
  m_cTDecTop.setDecodedPictureHashSEIEnabled(m_decodedPictureHashSEIEnabled);
#if O0043_BEST_EFFORT_DECODING
  m_cTDecTop.setForceDecodeBitDepth(m_forceDecodeBitDepth);
#endif
  if (!m_outputDecodedSEIMessagesFilename.empty())
  {
    std::ostream &os=m_seiMessageFileStream.is_open() ? m_seiMessageFileStream : std::cout;
    m_cTDecTop.setDecodedSEIMessageOutputStream(&os);
  }
  if (m_pcSeiColourRemappingInfoPrevious != NULL)
  {
    delete m_pcSeiColourRemappingInfoPrevious;
    m_pcSeiColourRemappingInfoPrevious = NULL;
  }
}

/** \param pcListPic list of pictures to be written to file
    \param tId       temporal sub-layer ID
 */
Void TAppDecTop::xWriteOutput( TComList<TComPic*>* pcListPic, UInt tId )
{
  if (pcListPic->empty())
  {
    return;
  }

  //================================
  // YGJ 29th July 2014 - Used to read YUV file
  int m_aiPad[2];
  m_aiPad[1] = m_aiPad[0] = 0;
  ChromaFormat                   chrfmt = m_inputChromaFormat == 0? CHROMA_400 : m_inputChromaFormat == 1? CHROMA_420 :
										  m_inputChromaFormat == 2? CHROMA_422 : CHROMA_444;
  //================================



  TComList<TComPic*>::iterator iterPic   = pcListPic->begin();
  Int numPicsNotYetDisplayed = 0;
  Int dpbFullness = 0;
  const TComSPS* activeSPS = &(pcListPic->front()->getPicSym()->getSPS());
  UInt numReorderPicsHighestTid;
  UInt maxDecPicBufferingHighestTid;
  UInt maxNrSublayers = activeSPS->getMaxTLayers();

  if(m_iMaxTemporalLayer == -1 || m_iMaxTemporalLayer >= maxNrSublayers)
  {
    numReorderPicsHighestTid = activeSPS->getNumReorderPics(maxNrSublayers-1);
    maxDecPicBufferingHighestTid =  activeSPS->getMaxDecPicBuffering(maxNrSublayers-1); 
  }
  else
  {
    numReorderPicsHighestTid = activeSPS->getNumReorderPics(m_iMaxTemporalLayer);
    maxDecPicBufferingHighestTid = activeSPS->getMaxDecPicBuffering(m_iMaxTemporalLayer); 
  }

  while (iterPic != pcListPic->end())
  {
    TComPic* pcPic = *(iterPic);
    if(pcPic->getOutputMark() && pcPic->getPOC() > m_iPOCLastDisplay)
    {
       numPicsNotYetDisplayed++;
      dpbFullness++;
    }
    else if(pcPic->getSlice( 0 )->isReferenced())
    {
      dpbFullness++;
    }
    iterPic++;
  }

  iterPic = pcListPic->begin();

  if (numPicsNotYetDisplayed>2)
  {
    iterPic++;
  }

  TComPic* pcPic = *(iterPic);
  if (numPicsNotYetDisplayed>2 && pcPic->isField()) //Field Decoding
  {
    TComList<TComPic*>::iterator endPic   = pcListPic->end();
    endPic--;
    iterPic   = pcListPic->begin();
    while (iterPic != endPic)
    {
      TComPic* pcPicTop = *(iterPic);
      iterPic++;
      TComPic* pcPicBottom = *(iterPic);

      if ( pcPicTop->getOutputMark() && pcPicBottom->getOutputMark() &&
          (numPicsNotYetDisplayed >  numReorderPicsHighestTid || dpbFullness > maxDecPicBufferingHighestTid) &&
          (!(pcPicTop->getPOC()%2) && pcPicBottom->getPOC() == pcPicTop->getPOC()+1) &&
          (pcPicTop->getPOC() == m_iPOCLastDisplay+1 || m_iPOCLastDisplay < 0))
      {
        // write to file
        numPicsNotYetDisplayed = numPicsNotYetDisplayed-2;
        if ( !m_reconFileName.empty() )
        {
          const Window &conf = pcPicTop->getConformanceWindow();
          const Window  defDisp = m_respectDefDispWindow ? pcPicTop->getDefDisplayWindow() : Window();
          const Bool isTff = pcPicTop->isTopField();

          Bool display = true;
          if( m_decodedNoDisplaySEIEnabled )
          {
            SEIMessages noDisplay = getSeisByType(pcPic->getSEIs(), SEI::NO_DISPLAY );
            const SEINoDisplay *nd = ( noDisplay.size() > 0 ) ? (SEINoDisplay*) *(noDisplay.begin()) : NULL;
            if( (nd != NULL) && nd->m_noDisplay )
            {
              display = false;
            }
          }

          if (display)
          {
            m_cTVideoIOYuvReconFile.write( pcPicTop->getPicYuvRec(), pcPicBottom->getPicYuvRec(),
                                           m_outputColourSpaceConvert,
                                           conf.getWindowLeftOffset() + defDisp.getWindowLeftOffset(),
                                           conf.getWindowRightOffset() + defDisp.getWindowRightOffset(),
                                           conf.getWindowTopOffset() + defDisp.getWindowTopOffset(),
                                           conf.getWindowBottomOffset() + defDisp.getWindowBottomOffset(), NUM_CHROMA_FORMAT, isTff );
          }
        }
        
        //================================
        // YGJ 
        //
		//m_cTVideoIOYuvRefFile.read(m_pcPicYuvOrg,m_aiPad); // YGJ 29th July 2014 - Read YUV file -- Working here
		// From TAppEncTop
		// read input YUV file
		//m_cTVideoIOYuvInputFile.read( pcPicYuvOrg, &cPicYuvTrueOrg, ipCSC, m_aiPad, m_InputChromaFormatIDC );

//       From TypeDef.h
//        enum InputColourSpaceConversion // defined in terms of conversion prior to input of encoder.
//        {
//          IPCOLOURSPACE_UNCHANGED               = 0,

//        /// chroma formats (according to semantics of chroma_format_idc)
//        enum ChromaFormat
//        {
//          CHROMA_400        = 0,
//          CHROMA_420        = 1,
//          CHROMA_422        = 2,
//          CHROMA_444        = 3,

          
        //if (m_pchRefFile != NULL)
        if (!m_pchRefFile.empty())
        {
		    // read input YUV file
		    m_cTVideoIOYuvRefFile.read( m_pcPicYuvOrg, &cPicYuvTrueOrg, m_outputColourSpaceConvert, m_aiPad, chrfmt );
        }
        //================================

        // update POC of display order
        m_iPOCLastDisplay = pcPicBottom->getPOC();

        // erase non-referenced picture in the reference picture list after display
        if ( !pcPicTop->getSlice(0)->isReferenced() && pcPicTop->getReconMark() == true )
        {
          pcPicTop->setReconMark(false);

          // mark it should be extended later
          pcPicTop->getPicYuvRec()->setBorderExtension( false );
        }
        if ( !pcPicBottom->getSlice(0)->isReferenced() && pcPicBottom->getReconMark() == true )
        {
          pcPicBottom->setReconMark(false);

          // mark it should be extended later
          pcPicBottom->getPicYuvRec()->setBorderExtension( false );
        }
        pcPicTop->setOutputMark(false);
        pcPicBottom->setOutputMark(false);
      }
    }
  }
  else if (!pcPic->isField()) //Frame Decoding
  {
    iterPic = pcListPic->begin();

    while (iterPic != pcListPic->end())
    {
      pcPic = *(iterPic);

      if(pcPic->getOutputMark() && pcPic->getPOC() > m_iPOCLastDisplay &&
        (numPicsNotYetDisplayed >  numReorderPicsHighestTid || dpbFullness > maxDecPicBufferingHighestTid))
      {
        // write to file
         numPicsNotYetDisplayed--;
        if(pcPic->getSlice(0)->isReferenced() == false)
        {
          dpbFullness--;
        }

        if ( !m_reconFileName.empty() )
        {
          const Window &conf    = pcPic->getConformanceWindow();
          const Window  defDisp = m_respectDefDispWindow ? pcPic->getDefDisplayWindow() : Window();

          m_cTVideoIOYuvReconFile.write( pcPic->getPicYuvRec(),
                                         m_outputColourSpaceConvert,
                                         conf.getWindowLeftOffset() + defDisp.getWindowLeftOffset(),
                                         conf.getWindowRightOffset() + defDisp.getWindowRightOffset(),
                                         conf.getWindowTopOffset() + defDisp.getWindowTopOffset(),
                                         conf.getWindowBottomOffset() + defDisp.getWindowBottomOffset(),
                                         NUM_CHROMA_FORMAT, m_bClipOutputVideoToRec709Range  );
        }
        
        //================================
        // YGJ 29th July 2014 - Read YUV file -- Working here
		//m_cTVideoIOYuvRefFile.read(m_pcPicYuvOrg,m_aiPad); // YGJ 29th July 2014 - Read YUV file -- Working here
  
        //if (m_pchRefFile != NULL)
        if (!m_pchRefFile.empty())
        {
		    // read input YUV file
		    m_cTVideoIOYuvRefFile.read( m_pcPicYuvOrg, &cPicYuvTrueOrg, m_outputColourSpaceConvert, m_aiPad, chrfmt );
        }

        if (!m_colourRemapSEIFileName.empty())
        {

		    // Save Output as PNGs
		    if (m_outputFrmPartition && (m_frameoutput == pcPic->getPOC() || m_frameoutput == 0))
		    {
			    saveFrameAsPNGPartition(pcPic);
                //saveFrameAsPNGPartitionwHighlight(pcPic);
			    saveFrameAsPNGPartwQP(pcPic);
                saveFrameAsPNGPartwQPwBlkHighlight(pcPic);
			    saveFrameAsPNGPartwBitUsage(pcPic);
		    }

            // if (m_outputSSIMAndSSELog) saveFrameAsSSIMLog(pcPic);
		
		    if (m_outputSSIMHeatmaps && (m_frameoutput == pcPic->getPOC() || m_frameoutput == 0))
		    {
                // saveFrameAsPNGSSIM(pcPic);
                // Proposed Techniques
                saveFrameAsPNG_HadPreAssess_wCornerTest_APC(pcPic);
                saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC(pcPic);
//                saveFrameAsPNG_AlwaysTrue_RCHadPreAssess_wEdgeScaledMS_APC(pcPic);
                saveFrameAsPNG_SADx_PreAssess_wCornerTest_APC(pcPic);
//                saveFrameAsPNG_AlwaysTrue_SADx_PreAssess_wCornerTest_APC(pcPic);
//                saveFrameAsPNGPartwSADwAPCwBlkHighlight(pcPic);
//                saveFrameAsPNG_SADx_NonSq_PreAssess_wCornerTest_APC(pcPic);
				saveFrameAsPNG_SSEx_wSASD_wEdgeDetect(pcPic);
//                saveFrameAsPNG_AlwaysTrue_SSEx_wSASD_wEdgeDetect(pcPic);
			    // Existing Techniques 
                saveFrameAsPNG_Hadamard(pcPic);
                saveFrameAsPNG_RateControlHad(pcPic);
                saveFrameAsPNG_RateControlJND(pcPic);
                saveFrameAsPNG_SSEx_Only(pcPic);
			    saveFrameAsPNG_SADx_Only(pcPic);
			    saveFrameAsPNG_SADx_NonSq_Only(pcPic);
//                saveFrameAsPNGPartwSADwBlkHighlight(pcPic);
//                saveFrameAsPNGPartwSSEwBlkHighlight(pcPic);
		    }
		
        }
        //================================        

        // update POC of display order
        m_iPOCLastDisplay = pcPic->getPOC();

        // erase non-referenced picture in the reference picture list after display
        if ( !pcPic->getSlice(0)->isReferenced() && pcPic->getReconMark() == true )
        {
          pcPic->setReconMark(false);

          // mark it should be extended later
          pcPic->getPicYuvRec()->setBorderExtension( false );
        }
        pcPic->setOutputMark(false);
      }

      iterPic++;
    }
  }
}

/** \param pcListPic list of pictures to be written to file
 */
Void TAppDecTop::xFlushOutput( TComList<TComPic*>* pcListPic )
{
  if(!pcListPic || pcListPic->empty())
  {
    return;
  }

  // YGJ 29th July 2014 - Used to read YUV file
  int m_aiPad[2];
  m_aiPad[1] = m_aiPad[0] = 0;
//  ChromaFormat                   chrfmt = m_inputChromaFormat == 0? CHROMA_400 : m_inputChromaFormat == 1? CHROMA_420 :
//										  m_inputChromaFormat == 2? CHROMA_422 : CHROMA_444;


  TComList<TComPic*>::iterator iterPic   = pcListPic->begin();

  iterPic   = pcListPic->begin();
  TComPic* pcPic = *(iterPic);

  if (pcPic->isField()) //Field Decoding
  {
    TComList<TComPic*>::iterator endPic   = pcListPic->end();
    endPic--;
    TComPic *pcPicTop, *pcPicBottom = NULL;
    while (iterPic != endPic)
    {
      pcPicTop = *(iterPic);
      iterPic++;
      pcPicBottom = *(iterPic);

      if ( pcPicTop->getOutputMark() && pcPicBottom->getOutputMark() && !(pcPicTop->getPOC()%2) && (pcPicBottom->getPOC() == pcPicTop->getPOC()+1) )
      {
        // write to file
        if ( !m_reconFileName.empty() )
        {
          const Window &conf = pcPicTop->getConformanceWindow();
          const Window  defDisp = m_respectDefDispWindow ? pcPicTop->getDefDisplayWindow() : Window();
          const Bool isTff = pcPicTop->isTopField();
          m_cTVideoIOYuvReconFile.write( pcPicTop->getPicYuvRec(), pcPicBottom->getPicYuvRec(),
                                         m_outputColourSpaceConvert,
                                         conf.getWindowLeftOffset() + defDisp.getWindowLeftOffset(),
                                         conf.getWindowRightOffset() + defDisp.getWindowRightOffset(),
                                         conf.getWindowTopOffset() + defDisp.getWindowTopOffset(),
                                         conf.getWindowBottomOffset() + defDisp.getWindowBottomOffset(), NUM_CHROMA_FORMAT, isTff );
        }

        // update POC of display order
        m_iPOCLastDisplay = pcPicBottom->getPOC();

        // erase non-referenced picture in the reference picture list after display
        if ( !pcPicTop->getSlice(0)->isReferenced() && pcPicTop->getReconMark() == true )
        {
          pcPicTop->setReconMark(false);

          // mark it should be extended later
          pcPicTop->getPicYuvRec()->setBorderExtension( false );
        }
        if ( !pcPicBottom->getSlice(0)->isReferenced() && pcPicBottom->getReconMark() == true )
        {
          pcPicBottom->setReconMark(false);

          // mark it should be extended later
          pcPicBottom->getPicYuvRec()->setBorderExtension( false );
        }
        pcPicTop->setOutputMark(false);
        pcPicBottom->setOutputMark(false);

        if(pcPicTop)
        {
          pcPicTop->destroy();
          delete pcPicTop;
          pcPicTop = NULL;
        }
      }
    }
    if(pcPicBottom)
    {
      pcPicBottom->destroy();
      delete pcPicBottom;
      pcPicBottom = NULL;
    }
  }
  else //Frame decoding
  {
    while (iterPic != pcListPic->end())
    {
      pcPic = *(iterPic);

      if ( pcPic->getOutputMark() )
      {
        // write to file
        if ( !m_reconFileName.empty() )
        {
          const Window &conf    = pcPic->getConformanceWindow();
          const Window  defDisp = m_respectDefDispWindow ? pcPic->getDefDisplayWindow() : Window();

          m_cTVideoIOYuvReconFile.write( pcPic->getPicYuvRec(),
                                         m_outputColourSpaceConvert,
                                         conf.getWindowLeftOffset() + defDisp.getWindowLeftOffset(),
                                         conf.getWindowRightOffset() + defDisp.getWindowRightOffset(),
                                         conf.getWindowTopOffset() + defDisp.getWindowTopOffset(),
                                         conf.getWindowBottomOffset() + defDisp.getWindowBottomOffset(),
                                         NUM_CHROMA_FORMAT, m_bClipOutputVideoToRec709Range );
        }

        if (!m_colourRemapSEIFileName.empty())
        {
          xOutputColourRemapPic(pcPic);
        }

        // update POC of display order
        m_iPOCLastDisplay = pcPic->getPOC();
        
		#if RExt__DECODER_DEBUG_BIT_STATISTICS

		TComCodingStatistics::CurrentBitUsage();

		#endif

        //if (m_pchRefFile != NULL)
        if (!m_pchRefFile.empty())
        {

		    //saveFrameAsPNG
		    // Save Output as PNGs
		    if (m_outputFrmPartition && (m_frameoutput == pcPic->getPOC() || m_frameoutput == 0))
		    {
			    saveFrameAsPNGPartition(pcPic);
			    saveFrameAsPNGPartwQP(pcPic);
                saveFrameAsPNGPartwQPwBlkHighlight(pcPic);
			    saveFrameAsPNGPartwBitUsage(pcPic);
                //saveFrameAsPNGPartitionwHighlight(pcPic);
		    }

            //if (m_outputSSIMAndSSELog) saveFrameAsSSIMLog(pcPic);
				  
		    if (m_outputSSIMHeatmaps && (m_frameoutput == pcPic->getPOC() || m_frameoutput == 0))
		    {
                // YGJ 13th Jan 2016 - Disabled for now
                //saveFrameAsPNGSSIM(pcPic);

                // Proposed techniques
                saveFrameAsPNG_HadPreAssess_wCornerTest_APC(pcPic);
                saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC(pcPic);
//                saveFrameAsPNG_AlwaysTrue_RCHadPreAssess_wEdgeScaledMS_APC(pcPic);
                saveFrameAsPNG_SADx_PreAssess_wCornerTest_APC(pcPic);
//                saveFrameAsPNG_AlwaysTrue_SADx_PreAssess_wCornerTest_APC(pcPic);
//                saveFrameAsPNGPartwSADwAPCwBlkHighlight(pcPic);
                saveFrameAsPNG_SADx_NonSq_PreAssess_wCornerTest_APC(pcPic);
				saveFrameAsPNG_SSEx_wSASD_wEdgeDetect(pcPic);
//                saveFrameAsPNG_AlwaysTrue_SSEx_wSASD_wEdgeDetect(pcPic);
			    // Existing techniques
                saveFrameAsPNG_Hadamard(pcPic);
			    saveFrameAsPNG_RateControlHad(pcPic);
                saveFrameAsPNG_RateControlJND(pcPic);
                saveFrameAsPNG_SSEx_Only(pcPic);
			    saveFrameAsPNG_SADx_Only(pcPic);
			    saveFrameAsPNG_SADx_NonSq_Only(pcPic);
//                saveFrameAsPNGPartwSADwBlkHighlight(pcPic);
//                saveFrameAsPNGPartwSSEwBlkHighlight(pcPic);
		    }
        }
        

        // erase non-referenced picture in the reference picture list after display
        if ( !pcPic->getSlice(0)->isReferenced() && pcPic->getReconMark() == true )
        {
          pcPic->setReconMark(false);

          // mark it should be extended later
          pcPic->getPicYuvRec()->setBorderExtension( false );
        }
        pcPic->setOutputMark(false);
      }
      if(pcPic != NULL)
      {
        pcPic->destroy();
        delete pcPic;
        pcPic = NULL;
      }
      iterPic++;
    }
  }
  pcListPic->clear();
  m_iPOCLastDisplay = -MAX_INT;
}

/** \param nalu Input nalu to check whether its LayerId is within targetDecLayerIdSet
 */
Bool TAppDecTop::isNaluWithinTargetDecLayerIdSet( InputNALUnit* nalu )
{
  if ( m_targetDecLayerIdSet.size() == 0 ) // By default, the set is empty, meaning all LayerIds are allowed
  {
    return true;
  }
  for (std::vector<Int>::iterator it = m_targetDecLayerIdSet.begin(); it != m_targetDecLayerIdSet.end(); it++)
  {
    if ( nalu->m_nuhLayerId == (*it) )
    {
      return true;
    }
  }
  return false;
}

Void TAppDecTop::xOutputColourRemapPic(TComPic* pcPic)
{
  const TComSPS &sps=pcPic->getPicSym()->getSPS();
  SEIMessages colourRemappingInfo = getSeisByType(pcPic->getSEIs(), SEI::COLOUR_REMAPPING_INFO );
  SEIColourRemappingInfo *seiColourRemappingInfo = ( colourRemappingInfo.size() > 0 ) ? (SEIColourRemappingInfo*) *(colourRemappingInfo.begin()) : NULL;

  if (colourRemappingInfo.size() > 1)
  {
    printf ("Warning: Got multiple Colour Remapping Information SEI messages. Using first.");
  }
  if (seiColourRemappingInfo)
  {
    applyColourRemapping(*pcPic->getPicYuvRec(), *seiColourRemappingInfo, sps);

    // save the last CRI SEI received
    if (m_pcSeiColourRemappingInfoPrevious == NULL)
    {
      m_pcSeiColourRemappingInfoPrevious = new SEIColourRemappingInfo();
    }
    m_pcSeiColourRemappingInfoPrevious->copyFrom(*seiColourRemappingInfo);
  }
  else  // using the last CRI SEI received
  {
    // TODO: prevent persistence of CRI SEI across C(L)VS.
    if (m_pcSeiColourRemappingInfoPrevious != NULL)
    {
      if (m_pcSeiColourRemappingInfoPrevious->m_colourRemapPersistenceFlag == false)
      {
        printf("Warning No SEI-CRI message is present for the current picture, persistence of the CRI is not managed\n");
      }
      applyColourRemapping(*pcPic->getPicYuvRec(), *m_pcSeiColourRemappingInfoPrevious, sps);
    }
  }
}

// compute lut from SEI
// use at lutPoints points aligned on a power of 2 value
// SEI Lut must be in ascending values of coded Values
static std::vector<Int>
initColourRemappingInfoLut(const Int                                          bitDepth_in,     // bit-depth of the input values of the LUT
                           const Int                                          nbDecimalValues, // Position of the fixed point
                           const std::vector<SEIColourRemappingInfo::CRIlut> &lut,
                           const Int                                          maxValue, // maximum output value
                           const Int                                          lutOffset)
{
  const Int lutPoints = (1 << bitDepth_in) + 1 ;
  std::vector<Int> retLut(lutPoints);

  // missing values: need to define default values before first definition (check codedValue[0] == 0)
  Int iTargetPrev = (lut.size() && lut[0].codedValue == 0) ? lut[0].targetValue: 0;
  Int startPivot = (lut.size())? ((lut[0].codedValue == 0)? 1: 0): 1;
  Int iCodedPrev  = 0;
  // set max value with the coded bit-depth
  // + ((1 << nbDecimalValues) - 1) is for the added bits
  const Int maxValueFixedPoint = (maxValue << nbDecimalValues) + ((1 << nbDecimalValues) - 1);

  Int iValue = 0;

  for ( Int iPivot=startPivot ; iPivot < (Int)lut.size(); iPivot++ )
  {
    Int iCodedNext  = lut[iPivot].codedValue;
    Int iTargetNext = lut[iPivot].targetValue;

    // ensure correct bit depth and avoid overflow in lut address
    Int iCodedNext_bitDepth = std::min(iCodedNext, (1 << bitDepth_in));

    const Int divValue =  (iCodedNext - iCodedPrev > 0)? (iCodedNext - iCodedPrev): 1;
    const Int lutValInit = (lutOffset + iTargetPrev) << nbDecimalValues;
    const Int roundValue = divValue / 2;
    for ( ; iValue<iCodedNext_bitDepth; iValue++ )
    {
      Int value = iValue;
      Int interpol = ((((value-iCodedPrev) * (iTargetNext - iTargetPrev)) << nbDecimalValues) + roundValue) / divValue;               
      retLut[iValue]  = std::min(lutValInit + interpol , maxValueFixedPoint);
    }
    iCodedPrev  = iCodedNext;
    iTargetPrev = iTargetNext;
  }
  // fill missing values if necessary
  if(iCodedPrev < (1 << bitDepth_in)+1)
  {
    Int iCodedNext  = (1 << bitDepth_in);
    Int iTargetNext = (1 << bitDepth_in) - 1;

    const Int divValue =  (iCodedNext - iCodedPrev > 0)? (iCodedNext - iCodedPrev): 1;
    const Int lutValInit = (lutOffset + iTargetPrev) << nbDecimalValues;
    const Int roundValue = divValue / 2;

    for ( ; iValue<=iCodedNext; iValue++ )
    {
      Int value = iValue;
      Int interpol = ((((value-iCodedPrev) * (iTargetNext - iTargetPrev)) << nbDecimalValues) + roundValue) / divValue; 
      retLut[iValue]  = std::min(lutValInit + interpol , maxValueFixedPoint);
    }
  }
  return retLut;
}

static Void
initColourRemappingInfoLuts(std::vector<Int>      (&preLut)[3],
                            std::vector<Int>      (&postLut)[3],
                            SEIColourRemappingInfo &pCriSEI,
                            const Int               maxBitDepth)
{
  Int internalBitDepth = pCriSEI.m_colourRemapBitDepth;
  for ( Int c=0 ; c<3 ; c++ )
  {
    std::sort(pCriSEI.m_preLut[c].begin(), pCriSEI.m_preLut[c].end()); // ensure preLut is ordered in ascending values of codedValues   
    preLut[c] = initColourRemappingInfoLut(pCriSEI.m_colourRemapInputBitDepth, maxBitDepth - pCriSEI.m_colourRemapInputBitDepth, pCriSEI.m_preLut[c], ((1 << internalBitDepth) - 1), 0); //Fill preLut

    std::sort(pCriSEI.m_postLut[c].begin(), pCriSEI.m_postLut[c].end()); // ensure postLut is ordered in ascending values of codedValues       
    postLut[c] = initColourRemappingInfoLut(pCriSEI.m_colourRemapBitDepth, maxBitDepth - pCriSEI.m_colourRemapBitDepth, pCriSEI.m_postLut[c], (1 << internalBitDepth) - 1, 0); //Fill postLut
  }
}

// apply lut.
// Input lut values are aligned on power of 2 boundaries
static Int
applyColourRemappingInfoLut1D(Int inVal, const std::vector<Int> &lut, const Int inValPrecisionBits)
{
  const Int roundValue = (inValPrecisionBits)? 1 << (inValPrecisionBits - 1): 0;
  inVal = std::min(std::max(0, inVal), (Int)(((lut.size()-1) << inValPrecisionBits)));
  Int index  = (Int) std::min((inVal >> inValPrecisionBits), (Int)(lut.size()-2));
  Int outVal = (( inVal - (index<<inValPrecisionBits) ) * (lut[index+1] - lut[index]) + roundValue) >> inValPrecisionBits;
  outVal +=  lut[index] ;

  return outVal;
}  

static Int
applyColourRemappingInfoMatrix(const Int (&colourRemapCoeffs)[3], const Int postOffsetShift, const Int p0, const Int p1, const Int p2, const Int offset)
{
  Int YUVMat = (colourRemapCoeffs[0]* p0 + colourRemapCoeffs[1]* p1 + colourRemapCoeffs[2]* p2  + offset) >> postOffsetShift;
  return YUVMat;
}

static Void
setColourRemappingInfoMatrixOffset(Int (&matrixOffset)[3], Int offset0, Int offset1, Int offset2)
{
  matrixOffset[0] = offset0;
  matrixOffset[1] = offset1;
  matrixOffset[2] = offset2;
}

static Void
setColourRemappingInfoMatrixOffsets(      Int  (&matrixInputOffset)[3],
                                          Int  (&matrixOutputOffset)[3],
                                    const Int  bitDepth,
                                    const Bool crInputFullRangeFlag,
                                    const Int  crInputMatrixCoefficients,
                                    const Bool crFullRangeFlag,
                                    const Int  crMatrixCoefficients)
{
  // set static matrix offsets
  Int crInputOffsetLuma = (crInputFullRangeFlag)? 0:-(16 << (bitDepth-8));
  Int crOffsetLuma = (crFullRangeFlag)? 0:(16 << (bitDepth-8));
  Int crInputOffsetChroma = 0;
  Int crOffsetChroma = 0;

  switch(crInputMatrixCoefficients)
  {
    case MATRIX_COEFFICIENTS_RGB:
      crInputOffsetChroma = 0;
      if(!crInputFullRangeFlag)
      {
        fprintf(stderr, "WARNING: crInputMatrixCoefficients set to MATRIX_COEFFICIENTS_RGB and crInputFullRangeFlag not set\n");
        crInputOffsetLuma = 0;
      }
      break;
    case MATRIX_COEFFICIENTS_UNSPECIFIED:
    case MATRIX_COEFFICIENTS_BT709:
    case MATRIX_COEFFICIENTS_BT2020_NON_CONSTANT_LUMINANCE:
      crInputOffsetChroma = -(1 << (bitDepth-1));
      break;
    default:
      fprintf(stderr, "WARNING: crInputMatrixCoefficients set to undefined value: %d\n", crInputMatrixCoefficients);
  }

  switch(crMatrixCoefficients)
  {
    case MATRIX_COEFFICIENTS_RGB:
      crOffsetChroma = 0;
      if(!crFullRangeFlag)
      {
        fprintf(stderr, "WARNING: crMatrixCoefficients set to MATRIX_COEFFICIENTS_RGB and crInputFullRangeFlag not set\n");
        crOffsetLuma = 0;
      }
      break;
    case MATRIX_COEFFICIENTS_UNSPECIFIED:
    case MATRIX_COEFFICIENTS_BT709:
    case MATRIX_COEFFICIENTS_BT2020_NON_CONSTANT_LUMINANCE:
      crOffsetChroma = (1 << (bitDepth-1));
      break;
    default:
      fprintf(stderr, "WARNING: crMatrixCoefficients set to undefined value: %d\n", crMatrixCoefficients);
  }

  setColourRemappingInfoMatrixOffset(matrixInputOffset, crInputOffsetLuma, crInputOffsetChroma, crInputOffsetChroma);
  setColourRemappingInfoMatrixOffset(matrixOutputOffset, crOffsetLuma, crOffsetChroma, crOffsetChroma);
}

Void TAppDecTop::applyColourRemapping(const TComPicYuv& pic, SEIColourRemappingInfo& criSEI, const TComSPS &activeSPS)
{  
  const Int maxBitDepth = 16;

  // create colour remapped picture
  if( !criSEI.m_colourRemapCancelFlag && pic.getChromaFormat()!=CHROMA_400) // 4:0:0 not supported.
  {
    const Int          iHeight         = pic.getHeight(COMPONENT_Y);
    const Int          iWidth          = pic.getWidth(COMPONENT_Y);
    const ChromaFormat chromaFormatIDC = pic.getChromaFormat();

    TComPicYuv picYuvColourRemapped;
    picYuvColourRemapped.createWithoutCUInfo( iWidth, iHeight, chromaFormatIDC );

    const Int  iStrideIn   = pic.getStride(COMPONENT_Y);
    const Int  iCStrideIn  = pic.getStride(COMPONENT_Cb);
    const Int  iStrideOut  = picYuvColourRemapped.getStride(COMPONENT_Y);
    const Int  iCStrideOut = picYuvColourRemapped.getStride(COMPONENT_Cb);
    const Bool b444        = ( pic.getChromaFormat() == CHROMA_444 );
    const Bool b422        = ( pic.getChromaFormat() == CHROMA_422 );
    const Bool b420        = ( pic.getChromaFormat() == CHROMA_420 );

    std::vector<Int> preLut[3];
    std::vector<Int> postLut[3];
    Int matrixInputOffset[3];
    Int matrixOutputOffset[3];
    const Pel *YUVIn[MAX_NUM_COMPONENT];
    Pel *YUVOut[MAX_NUM_COMPONENT];
    YUVIn[COMPONENT_Y]  = pic.getAddr(COMPONENT_Y);
    YUVIn[COMPONENT_Cb] = pic.getAddr(COMPONENT_Cb);
    YUVIn[COMPONENT_Cr] = pic.getAddr(COMPONENT_Cr);
    YUVOut[COMPONENT_Y]  = picYuvColourRemapped.getAddr(COMPONENT_Y);
    YUVOut[COMPONENT_Cb] = picYuvColourRemapped.getAddr(COMPONENT_Cb);
    YUVOut[COMPONENT_Cr] = picYuvColourRemapped.getAddr(COMPONENT_Cr);

    const Int bitDepth = criSEI.m_colourRemapBitDepth;
    BitDepths        bitDepthsCriFile;
    bitDepthsCriFile.recon[CHANNEL_TYPE_LUMA]   = bitDepth;
    bitDepthsCriFile.recon[CHANNEL_TYPE_CHROMA] = bitDepth; // Different bitdepth is not implemented

    const Int postOffsetShift = criSEI.m_log2MatrixDenom;
    const Int matrixRound = 1 << (postOffsetShift - 1);
    const Int postLutInputPrecision = (maxBitDepth - criSEI.m_colourRemapBitDepth);

    if ( ! criSEI.m_colourRemapVideoSignalInfoPresentFlag ) // setting default
    {
      setColourRemappingInfoMatrixOffsets(matrixInputOffset, matrixOutputOffset, maxBitDepth,
          activeSPS.getVuiParameters()->getVideoFullRangeFlag(), activeSPS.getVuiParameters()->getMatrixCoefficients(),
          activeSPS.getVuiParameters()->getVideoFullRangeFlag(), activeSPS.getVuiParameters()->getMatrixCoefficients());
    }
    else
    {
      setColourRemappingInfoMatrixOffsets(matrixInputOffset, matrixOutputOffset, maxBitDepth,
          activeSPS.getVuiParameters()->getVideoFullRangeFlag(), activeSPS.getVuiParameters()->getMatrixCoefficients(),
          criSEI.m_colourRemapFullRangeFlag, criSEI.m_colourRemapMatrixCoefficients);
    }

    // add matrix rounding to output matrix offsets
    matrixOutputOffset[0] = (matrixOutputOffset[0] << postOffsetShift) + matrixRound;
    matrixOutputOffset[1] = (matrixOutputOffset[1] << postOffsetShift) + matrixRound;
    matrixOutputOffset[2] = (matrixOutputOffset[2] << postOffsetShift) + matrixRound;

    // Merge   matrixInputOffset and matrixOutputOffset to matrixOutputOffset
    matrixOutputOffset[0] += applyColourRemappingInfoMatrix(criSEI.m_colourRemapCoeffs[0], 0, matrixInputOffset[0], matrixInputOffset[1], matrixInputOffset[2], 0);
    matrixOutputOffset[1] += applyColourRemappingInfoMatrix(criSEI.m_colourRemapCoeffs[1], 0, matrixInputOffset[0], matrixInputOffset[1], matrixInputOffset[2], 0);
    matrixOutputOffset[2] += applyColourRemappingInfoMatrix(criSEI.m_colourRemapCoeffs[2], 0, matrixInputOffset[0], matrixInputOffset[1], matrixInputOffset[2], 0);

    // rescaling output: include CRI/output frame difference
    const Int scaleShiftOut_neg = abs(bitDepth - maxBitDepth);
    const Int scaleOut_round = 1 << (scaleShiftOut_neg-1);

    initColourRemappingInfoLuts(preLut, postLut, criSEI, maxBitDepth);

    assert(pic.getChromaFormat() != CHROMA_400);
    const Int hs = pic.getComponentScaleX(ComponentID(COMPONENT_Cb));
    const Int maxOutputValue = (1 << bitDepth) - 1;

    for( Int y = 0; y < iHeight; y++ )
    {
      for( Int x = 0; x < iWidth; x++ )
      {
        const Int xc = (x>>hs);
        Bool computeChroma = b444 || ((b422 || !(y&1)) && !(x&1));

        Int YUVPre_0 = applyColourRemappingInfoLut1D(YUVIn[COMPONENT_Y][x], preLut[0], 0);
        Int YUVPre_1 = applyColourRemappingInfoLut1D(YUVIn[COMPONENT_Cb][xc], preLut[1], 0);
        Int YUVPre_2 = applyColourRemappingInfoLut1D(YUVIn[COMPONENT_Cr][xc], preLut[2], 0);

        Int YUVMat_0 = applyColourRemappingInfoMatrix(criSEI.m_colourRemapCoeffs[0], postOffsetShift, YUVPre_0, YUVPre_1, YUVPre_2, matrixOutputOffset[0]);
        Int YUVLutB_0 = applyColourRemappingInfoLut1D(YUVMat_0, postLut[0], postLutInputPrecision);
        YUVOut[COMPONENT_Y][x] = std::min(maxOutputValue, (YUVLutB_0 + scaleOut_round) >> scaleShiftOut_neg);

        if( computeChroma )
        {
          Int YUVMat_1 = applyColourRemappingInfoMatrix(criSEI.m_colourRemapCoeffs[1], postOffsetShift, YUVPre_0, YUVPre_1, YUVPre_2, matrixOutputOffset[1]);
          Int YUVLutB_1 = applyColourRemappingInfoLut1D(YUVMat_1, postLut[1], postLutInputPrecision);
          YUVOut[COMPONENT_Cb][xc] = std::min(maxOutputValue, (YUVLutB_1 + scaleOut_round) >> scaleShiftOut_neg);

          Int YUVMat_2 = applyColourRemappingInfoMatrix(criSEI.m_colourRemapCoeffs[2], postOffsetShift, YUVPre_0, YUVPre_1, YUVPre_2, matrixOutputOffset[2]);
          Int YUVLutB_2 = applyColourRemappingInfoLut1D(YUVMat_2, postLut[2], postLutInputPrecision);
          YUVOut[COMPONENT_Cr][xc] = std::min(maxOutputValue, (YUVLutB_2 + scaleOut_round) >> scaleShiftOut_neg);
        }
      }

      YUVIn[COMPONENT_Y]  += iStrideIn;
      YUVOut[COMPONENT_Y] += iStrideOut;
      if( !(b420 && !(y&1)) )
      {
         YUVIn[COMPONENT_Cb]  += iCStrideIn;
         YUVIn[COMPONENT_Cr]  += iCStrideIn;
         YUVOut[COMPONENT_Cb] += iCStrideOut;
         YUVOut[COMPONENT_Cr] += iCStrideOut;
      }
    }
    //Write remapped picture in display order
    picYuvColourRemapped.dump( m_colourRemapSEIFileName, bitDepthsCriFile, true );
    picYuvColourRemapped.destroy();
  }
}


// ====================================================================================================================
// YGJ Functions/Methods
// ====================================================================================================================

// Make this a variable in config file, default being 8
int TAppDecTop::DistWidthSize(int blkwidth)
{
	int value = 8; // default value;

	switch(blkwidth)
	{
	   case 16 : value = 16; break;
	   case 32 : value = 32; break;
	   case 64 : value = 64; break;
	}
	return value;
}

//// YGJ 13th Jan 2016 - Disabled for now
//// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel)
//Void TAppDecTop::saveFrameAsSSIMLog(TComPic* pcPic)
//{

//  // unsigned height = m_iSourceHeight;
//  // unsigned width = m_iSourceWidth;
//  // unsigned FrameRes = (height*width);

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);
//  Pel*  piCb_Org  = imageOrg->getAddr(COMPONENT_Cb);
//  Pel*  piCr_Org  = imageOrg->getAddr(COMPONENT_Cr);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);
//  Pel*  piCb_Rec  = imageRec->getAddr(COMPONENT_Cb);
//  Pel*  piCr_Rec  = imageRec->getAddr(COMPONENT_Cr);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);
//  Pel*  piCb_Part = imageRecPart->getAddr(COMPONENT_Cb);
//  Pel*  piCr_Part  = imageRecPart->getAddr(COMPONENT_Cr);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);
//  unsigned CStride = imageOrg->getStride(COMPONENT_Cb);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // 420: 1:1/4:1/4, Then Y:UV = 2xY:1xChr => CShift = 1
//  // 422: 1:1/2:1/2, Then Y:UV = 2xY:2xChr => CShift = 0
//  // 444: 1:1:1, Then Y:UV = 2xY:4xChr => CShift = -1
//	int CShift = (YStride == (CStride<<1))? 1
//		: YStride == CStride? 0 : -1;


//   // 420: 1/4, 422: 1/2, 444: 1
//   unsigned ChrFrmRes = CShift == 1? QuartFrameRes
//       : CShift == 0? HalfFrameRes : FrameRes;

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");
//  Pel *ptrU_Org;   ptrU_Org = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Org == NULL)   printf("calloc failed\n");
//  Pel *ptrV_Org;   ptrV_Org = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");
//  Pel *ptrU_Rec;   ptrU_Rec = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Rec == NULL)   printf("calloc failed\n");
//  Pel *ptrV_Rec;   ptrV_Rec = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");
//  Pel *ptrU_Part;   ptrU_Part = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Part == NULL)   printf("calloc failed\n");
//  Pel *ptrV_Part;   ptrV_Part = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Part == NULL)   printf("calloc failed\n");

//	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];


//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<bitDepthLuma)-1;
//    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
//    Int   shiftc = bitDepthChroma-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

//int prevCloc = 0; // Previous cloc

// double frmAverageSSIM = 0.0;
// int OverlappingSSIMcount =0;
		  
// //float PxAve_SSIM_distortion = 0.0;
// unsigned long long FrmTotal_SSE_distortion = 0;

//	for ( unsigned y = 0; y < height; y++ )
//	{
//	  for ( unsigned x = 0; x < width; x++ )
//	  {
//		unsigned yloc = y*width+x;
//		unsigned cloc = prevCloc;

//		// CShift: 1, 0, -1
//		// 420: 1/4, 422: 1/2, 444: 1
//		if (CShift == 1)
//		{
//		  if (x%2 == 0)
//			cloc = (y >> 2) * (width >> 2) + (x >> 2);
//		}
//		else if (CShift == 1)
//		{
//		  if (x%2 == 0)
//			cloc = (y >> 1) * (width >> 1) + (x >> 1);
//		}
//		else if (CShift == -1)
//		  cloc = yloc;

//		prevCloc = cloc;

//		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//		int yInt_Org = (int)ptrY_Org[yloc];
//        int yInt_Rec = (int)ptrY_Rec[yloc];

//		// seems fine here
//		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
//			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

//		int iTemp = abs(yInt_Org - yInt_Rec);
//		int SSE = iTemp*iTemp;
//		// seems fine here
//		if (iTemp > 255 || iTemp < 0 || SSE > 65025 || SSE < 0)
//			printf("Out of range pixel value, iTemp, %d, SSE, %d \n", iTemp, SSE);

//		FrmTotal_SSE_distortion += iTemp; //SSE;
		 
//		if ((x% CShift) == 0)
//		{
//		  unsigned cx = (x >> CShift);

//		  ptrU_Org[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Org[cx]+offsetc)>>shiftc); ptrV_Org[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Org[cx]+offsetc)>>shiftc);
//		  ptrU_Rec[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Rec[cx]+offsetc)>>shiftc); ptrV_Rec[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Rec[cx]+offsetc)>>shiftc);
//		  ptrU_Part[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Part[cx]+offsetc)>>shiftc); ptrV_Part[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Part[cx]+offsetc)>>shiftc);

//		}

//		// Y-SSIM
//		// From img_dist_ssim.c (JM 18.6 H.264 Ref Encoder)

//		if ((y < (height-8)) && (x < (width-8)))
//		{
//		  static const float K1 = 0.01f, K2 = 0.03f;
//		  float max_pix_value_sqd;
//		  float C1, C2;
//		  float win_pixels = (float) (8 * 8);
//		  float win_pixels_bias = win_pixels - 1;
//		  float mb_ssim, meanOrg, meanEnc;
//		  float varOrg, varEnc, covOrgEnc;
//		  int imeanOrg, imeanEnc, ivarOrg, ivarEnc, icovOrgEnc;
//		  float cur_distortion = 0.0;
		  
//		  max_pix_value_sqd = (float) ( MaxValue * MaxValue);
//		  C1 = K1 * K1 * max_pix_value_sqd;
//		  C2 = K2 * K2 * max_pix_value_sqd;

//		  imeanOrg = 0;
//		  imeanEnc = 0;
//		  ivarOrg  = 0;
//		  ivarEnc  = 0;
//		  icovOrgEnc = 0;
		  
//			for ( unsigned n = 0; n < 8; n++ )
//			{
//				for ( unsigned m = 0; m < 8; m++ )
//				{
//					unsigned yloc8x8 = n*m+m;

//					ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//					ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//					int y_Org = (int)ptrY_Org8x8[yloc8x8];
//					int y_Rec = (int)ptrY_Rec8x8[yloc8x8];


//					imeanOrg   += y_Org;
//					imeanEnc   += y_Rec;
//					ivarOrg    += y_Org * y_Org;
//					ivarEnc    += y_Rec * y_Rec;
//					icovOrgEnc += y_Org * y_Rec;
//				}
//			}


//		  meanOrg = (float) imeanOrg / win_pixels;
//		  meanEnc = (float) imeanEnc / win_pixels;

//		  varOrg    = ((float) ivarOrg - ((float) imeanOrg) * meanOrg) / win_pixels_bias;
//		  varEnc    = ((float) ivarEnc - ((float) imeanEnc) * meanEnc) / win_pixels_bias;
//		  covOrgEnc = ((float) icovOrgEnc - ((float) imeanOrg) * meanEnc) / win_pixels_bias;

//		  mb_ssim  = (float) ((2.0 * meanOrg * meanEnc + C1) * (2.0 * covOrgEnc + C2));
//		  mb_ssim /= (float) (meanOrg * meanOrg + meanEnc * meanEnc + C1) * (varOrg + varEnc + C2);

//		  cur_distortion = mb_ssim;
		  
//		  //Test Scenarios SSIM of 1, 0 and -1
//		  if (cur_distortion >= 1.0 && cur_distortion < 1.01) // avoid float accuracy problem at very low QP(e.g.2)
//			cur_distortion = 1.0;

//		  frmAverageSSIM +=  cur_distortion;
//		  OverlappingSSIMcount++;

//		  //printf("PxAve_SSIM_distortion, %f, OneMinSSIM, %f \n", PxAve_SSIM_distortion, OneMinSSIM);

//		}


//	  }
//	  //piY += YStride;
//	  piY_Org += YStride;
//	  piY_Rec += YStrideRec;
//	  piY_Part += YStrideRec;


//	  // CShift: 1, 0, -1
//	  // 420: 1/4, 422: 1/2, 444: 1
//	  if (CShift == 1)
//	  {
//		if (y%2 == 0)
//		{
//		  piCr_Org += CStride; piCb_Org += CStride;
//		  piCr_Rec += CStride; piCb_Rec += CStride;
//		}
//	  }
//	  else if (CShift == 1)
//	  {
//		if (y%2 == 0)
//		{
//		  piCr_Org += CStride; piCb_Org += CStride;
//		  piCr_Rec += CStride; piCb_Rec += CStride;
//		}
//	  }
//	  else if (CShift == -1)
//	  {
//		  piCr_Org += CStride; piCb_Org += CStride;
//		  piCr_Rec += CStride; piCb_Rec += CStride;
//	  }
//	}

//	//printf("frmAverageSSIM, %f, 1-SSIM, %f, \n", frmAverageSSIM, 1-frmAverageSSIM);
	
//	//PxAve_SSIM_distortion = PxAve_SSIM_distortion/((height-8) * (width-8));
//	//printf("Frame (8x8 overlapping) SSIM and 1-SSIM scores, %f, %f, Frame SSE, %d ", PxAve_SSIM_distortion, 1-PxAve_SSIM_distortion), FrmTotal_SSE_distortion;
//		//std::vector<unsigned char> png;
//	//std::cout << "Frame (8x8 overlapping) SSIM and 1-SSIM scores, " << PxAve_SSIM_distortion << ", " << 1-PxAve_SSIM_distortion << ",  Frame SSE, " << FrmTotal_SSE_distortion << std::endl;

//	free(ptrY_Org8x8);
//	free(ptrY_Rec8x8);

//	free(ptrY_Org);
//	free(ptrU_Org);
//	free(ptrV_Org);

//	free(ptrY_Rec);
//	free(ptrU_Rec);
//	free(ptrV_Rec);


//	free(ptrY_Part);
//	free(ptrU_Part);
//	free(ptrV_Part);

//	////-----------------------

//	if(m_outputSSIMAndSSELog)
//	{
//		frmAverageSSIM /=  (double)OverlappingSSIMcount;
//		//int frmAveSSE = 0; //(int)((double)FrmTotal_SSE_distortion/(double)FrameRes);
//		int frmAveSSE = (int)((double)FrmTotal_SSE_distortion/(double)FrameRes);

//		char SSIMFrmAveFile[255];
//		strcpy(SSIMFrmAveFile, m_pchSSIMLogAndImageFile);
//		strcat(SSIMFrmAveFile, "_DecFrmSSIMandSSE.txt");
//		//strcpy(SSIMFrmAveFile, "_DecFrmSSIMandSSE.txt");

//		ofstream DecFrmSSIM;
//		DecFrmSSIM.open (SSIMFrmAveFile, ios::out | ios::app);

//		// Log out the Existing  without Proposed , Existing  with Proposed, Final threshold based Result (with or without Proposed), Threshold Result , SSIM, 1-SSIM, stats,
//		DecFrmSSIM << frmAverageSSIM << ","  << 1-frmAverageSSIM << ","  << FrmTotal_SSE_distortion << ","  << frmAveSSE << endl;

//		DecFrmSSIM.close();
//	}


//}

//// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel)
//Void TAppDecTop::saveFrameAsPNGSSIM(TComPic* pcPic)
//{
//  // YGJ 14th Oct 2013 - Attempting to save decoded frames/images as PNG

//  // unsigned height = m_iSourceHeight;
//  // unsigned width = m_iSourceWidth;
//  // unsigned FrameRes = (height*width);

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  // Decode order from reading from YUV file.

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);
//  Pel*  piCb_Org  = imageOrg->getAddr(COMPONENT_Cb);
//  Pel*  piCr_Org  = imageOrg->getAddr(COMPONENT_Cr);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);
//  Pel*  piCb_Rec  = imageRec->getAddr(COMPONENT_Cb);
//  Pel*  piCr_Rec  = imageRec->getAddr(COMPONENT_Cr);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);
//  Pel*  piCb_Part = imageRecPart->getAddr(COMPONENT_Cb);
//  Pel*  piCr_Part  = imageRecPart->getAddr(COMPONENT_Cr);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);
//  unsigned CStride = imageOrg->getStride(COMPONENT_Cb);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);
//  //unsigned CStrideRec = imageRec->getCStride();

//  // 420: 1:1/4:1/4, Then Y:UV = 2xY:1xChr => CShift = 1
//  // 422: 1:1/2:1/2, Then Y:UV = 2xY:2xChr => CShift = 0
//  // 444: 1:1:1, Then Y:UV = 2xY:4xChr => CShift = -1
//	int CShift = (YStride == (CStride<<1))? 1
//		: YStride == CStride? 0 : -1;

////    int CShiftRec = (YStrideRec == (CStrideRec<<1))? 1
////        : YStrideRec == CStrideRec? 0 : -1;

//   // 420: 1/4, 422: 1/2, 444: 1
//   unsigned ChrFrmRes = CShift == 1? QuartFrameRes
//       : CShift == 0? HalfFrameRes : FrameRes;

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");
//  Pel *ptrU_Org;   ptrU_Org = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Org == NULL)   printf("calloc failed\n");
//  Pel *ptrV_Org;   ptrV_Org = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");
//  Pel *ptrU_Rec;   ptrU_Rec = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Rec == NULL)   printf("calloc failed\n");
//  Pel *ptrV_Rec;   ptrV_Rec = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");
//  Pel *ptrU_Part;   ptrU_Part = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Part == NULL)   printf("calloc failed\n");
//  Pel *ptrV_Part;   ptrV_Part = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Part == NULL)   printf("calloc failed\n");

//	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];

//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  
//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);  strcat(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");

//  // YGJ Tues 26th May 2015
//  // Store the QP to text file
//  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile);  strcat(FrmAsTxt, "DecFrm_SSIMHeatMap_");    strcat(FrmAsTxt, strpoc);        strcat(FrmAsTxt, ".txt");


//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);
//  // YGJ Thurs 28th May 2015
//  // Store the QP to array
//  std::vector<float> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);


//  unsigned MaxValue = (1<<bitDepthLuma)-1;   unsigned HalfMaxValue = (MaxValue-1) >> 1;
//    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
//    Int   shiftc = bitDepthChroma-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

//int prevCloc = 0; // Previous cloc

// double frmAverageSSIM = 0.0;
// int OverlappingSSIMcount =0;
		  
// //float PxAve_SSIM_distortion = 0.0;
// unsigned long long FrmTotal_SSE_distortion = 0;

//	for ( unsigned y = 0; y < height; y++ )
//	{
//	  for ( unsigned x = 0; x < width; x++ )
//	  {
//		unsigned yloc = y*width+x;
//		unsigned cloc = prevCloc;

//		// CShift: 1, 0, -1
//		// 420: 1/4, 422: 1/2, 444: 1
//		if (CShift == 1)
//		{
//		  if (x%2 == 0)
//			cloc = (y >> 2) * (width >> 2) + (x >> 2);
//		}
//		else if (CShift == 1)
//		{
//		  if (x%2 == 0)
//			cloc = (y >> 1) * (width >> 1) + (x >> 1);
//		}
//		else if (CShift == -1)
//		  cloc = yloc;

//		prevCloc = cloc;

//		// allocate YUV value
//        int yInt = 0, uInt = 0, vInt = 0;

//		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//		int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//        int yInt_Rec = (int)ptrY_Rec[yloc];  int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//		// seems fine here
//		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
//			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

//		int iTemp = abs(yInt_Org - yInt_Rec);
//		int SSE = iTemp*iTemp;
//		// seems fine here
//		if (iTemp > 255 || iTemp < 0 || SSE > 65025 || SSE < 0)
//			printf("Out of range pixel value, iTemp, %d, SSE, %d \n", iTemp, SSE);


//		FrmTotal_SSE_distortion += iTemp; //SSE;
//		//// store max value max
//		//FrmTotal_SSE_distortion =  SSE > FrmTotal_SSE_distortion ? SSE : FrmTotal_SSE_distortion;
//		//
//		//if (FrmTotal_SSE_distortion > 65025 || FrmTotal_SSE_distortion < 0 )
//		//    printf("Out of range pixel value, FrmTotal_SSE_distortion, %d \n", FrmTotal_SSE_distortion);
		 
//		if ((x% CShift) == 0)
//		{
//		  unsigned cx = (x >> CShift);

//		  ptrU_Org[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Org[cx]+offsetc)>>shiftc); ptrV_Org[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Org[cx]+offsetc)>>shiftc);
//		  ptrU_Rec[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Rec[cx]+offsetc)>>shiftc); ptrV_Rec[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Rec[cx]+offsetc)>>shiftc);
//		  ptrU_Part[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Part[cx]+offsetc)>>shiftc); ptrV_Part[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Part[cx]+offsetc)>>shiftc);

//		  uInt_Rec = (int)ptrU_Rec[cloc];  vInt_Rec = (int)ptrV_Rec[cloc];

//		}
//		else
//		{
//		  uInt_Rec = (int)ptrU_Rec[cloc];  vInt_Rec = (int)ptrV_Rec[cloc];
//		}

//		// Y-SSIM
//		// From img_dist_ssim.c (JM 18.6 H.264 Ref Encoder)

//		float OneMinSSIM = 0.0;  // Assuming Perfect score at this point
//		bool SSIMRegion = false;

//		if ((y < (height-8)) && (x < (width-8)))
//		{
//		  SSIMRegion = true;
//		  static const float K1 = 0.01f, K2 = 0.03f;
//		  float max_pix_value_sqd;
//		  float C1, C2;
//		  float win_pixels = (float) (8 * 8);
//		  float win_pixels_bias = win_pixels - 1;
//		  float mb_ssim, meanOrg, meanEnc;
//		  float varOrg, varEnc, covOrgEnc;
//		  int imeanOrg, imeanEnc, ivarOrg, ivarEnc, icovOrgEnc;
//		  float cur_distortion = 0.0;

//		  max_pix_value_sqd = (float) ( MaxValue * MaxValue);
//		  C1 = K1 * K1 * max_pix_value_sqd;
//		  C2 = K2 * K2 * max_pix_value_sqd;

//		  imeanOrg = 0;
//		  imeanEnc = 0;
//		  ivarOrg  = 0;
//		  ivarEnc  = 0;
//		  icovOrgEnc = 0;

//			for ( unsigned n = 0; n < 8; n++ )
//			{
//				for ( unsigned m = 0; m < 8; m++ )
//				{
//					unsigned yloc8x8 = n*m+m;

//					ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//					ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);


//					int y_Org = (int)ptrY_Org8x8[yloc8x8];
//					int y_Rec = (int)ptrY_Rec8x8[yloc8x8];

//					imeanOrg   += y_Org;
//					imeanEnc   += y_Rec;
//					ivarOrg    += y_Org * y_Org;
//					ivarEnc    += y_Rec * y_Rec;
//					icovOrgEnc += y_Org * y_Rec;
//				}
//			}


//		  meanOrg = (float) imeanOrg / win_pixels;
//		  meanEnc = (float) imeanEnc / win_pixels;

//		  varOrg    = ((float) ivarOrg - ((float) imeanOrg) * meanOrg) / win_pixels_bias;
//		  varEnc    = ((float) ivarEnc - ((float) imeanEnc) * meanEnc) / win_pixels_bias;
//		  covOrgEnc = ((float) icovOrgEnc - ((float) imeanOrg) * meanEnc) / win_pixels_bias;

//		  mb_ssim  = (float) ((2.0 * meanOrg * meanEnc + C1) * (2.0 * covOrgEnc + C2));
//		  mb_ssim /= (float) (meanOrg * meanOrg + meanEnc * meanEnc + C1) * (varOrg + varEnc + C2);

//		  cur_distortion = mb_ssim;

//		  //Test Scenarios SSIM of 1, 0 and -1
//		  if (cur_distortion >= 1.0 && cur_distortion < 1.01) // avoid float accuracy problem at very low QP(e.g.2)
//			cur_distortion = 1.0;

//		  //PxAve_SSIM_distortion =cur_distortion;

//		  OneMinSSIM = 1- cur_distortion;

//		  frmAverageSSIM +=  cur_distortion;
//		  OverlappingSSIMcount++;

//		  //printf("PxAve_SSIM_distortion, %f, OneMinSSIM, %f \n", PxAve_SSIM_distortion, OneMinSSIM);

//		}

//		yInt = yInt_Rec;

//		uInt = yInt_Rec; //uInt_Rec;
//		vInt = yInt_Rec; //vInt_Rec;

//		//--------------


//		// Rec - Org

////		int u_MinHalfMaxVal = uInt - HalfMaxValue;   int v_MinHalfMaxVal = vInt - HalfMaxValue;
////
////        // Convert YUV to RGB


//		int r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
//		int g = yInt; //- ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
//		int b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);


//        //-------------------------
//        // YGJ Thurs 28th May 2015
//        // Store the QP to array

//        if (SSIMRegion == true)
//            imgFrmAsTxt[width * y + x] = (float)OneMinSSIM;
//        else
//            imgFrmAsTxt[width * y + x] = -1;
//        //-------------------------

//		if (SSIMRegion == true)
//		{

////            //-------------------------
////            // YGJ Tues 26th May 2015
////            // Store the QP to text file

////            ofstream DecFrmAsTxt;
////            DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);

////            if (x < (width-1))
////                DecFrmAsTxt << OneMinSSIM  << ","; // CSV friendly
////            else
////                DecFrmAsTxt << OneMinSSIM << endl; // new line no need for comma

////            DecFrmAsTxt.close();

////            //-------------------------


//			float capped1MinSSIM = (float) (OneMinSSIM > 1.0 ? 1.0 : OneMinSSIM);  // Limit it to 1.

//			float avScaledScore = capped1MinSSIM; //(float)((cappedSSENorm + cappedSADNorm)/2.0);
//			//float
//			avScaledScore = (2*avScaledScore - (avScaledScore*avScaledScore)); // y=4(2x-x^2)

//			unsigned int val = (unsigned int)(avScaledScore*4.0);  // This will ensure 1-SSIM is 0 if < 0.5, 1 if < 1.0, 2 if < 1.5 and 3 if > 1.5.


//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((avScaledScore/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((avScaledScore-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((avScaledScore-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((avScaledScore-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------

//		}


//		// Rec - Org
//		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//		// Partitioning -- Not Working
//		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//		{
//		  r = 0; //yInt_RmO;
//		  g = 0; //yInt_RmO;
//		  b = 0; //yInt_RmO;
//		}

//		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//	  }
//	  //piY += YStride;
//	  piY_Org += YStride;
//	  piY_Rec += YStrideRec;
//	  piY_Part += YStrideRec;


//	  // CShift: 1, 0, -1
//	  // 420: 1/4, 422: 1/2, 444: 1
//	  if (CShift == 1)
//	  {
//		if (y%2 == 0)
//		{
//		  piCr_Org += CStride; piCb_Org += CStride;
//		  piCr_Rec += CStride; piCb_Rec += CStride;
//		}
//	  }
//	  else if (CShift == 1)
//	  {
//		if (y%2 == 0)
//		{
//		  piCr_Org += CStride; piCb_Org += CStride;
//		  piCr_Rec += CStride; piCb_Rec += CStride;
//		}
//	  }
//	  else if (CShift == -1)
//	  {
//		  piCr_Org += CStride; piCb_Org += CStride;
//		  piCr_Rec += CStride; piCb_Rec += CStride;
//	  }
//	}

//	//printf("frmAverageSSIM, %f, 1-SSIM, %f, \n", frmAverageSSIM, 1-frmAverageSSIM);
	
//	//PxAve_SSIM_distortion = PxAve_SSIM_distortion/((height-8) * (width-8));
//	//printf("Frame (8x8 overlapping) SSIM and 1-SSIM scores, %f, %f, Frame SSE, %d ", PxAve_SSIM_distortion, 1-PxAve_SSIM_distortion), FrmTotal_SSE_distortion;
//		//std::vector<unsigned char> png;
//	//std::cout << "Frame (8x8 overlapping) SSIM and 1-SSIM scores, " << PxAve_SSIM_distortion << ", " << 1-PxAve_SSIM_distortion << ",  Frame SSE, " << FrmTotal_SSE_distortion << std::endl;

//	free(ptrY_Org8x8);
//	free(ptrY_Rec8x8);

//	free(ptrY_Org);
//	free(ptrU_Org);
//	free(ptrV_Org);

//	free(ptrY_Rec);
//	free(ptrU_Rec);
//	free(ptrV_Rec);


//	free(ptrY_Part);
//	free(ptrU_Part);
//	free(ptrV_Part);


//	//-----------------------

//	if(m_outputSSIMHeatmaps)
//	{
//	  std::vector<unsigned char> png;

//	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//	  //if there's an error, display it
//	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//	}

//   //-----------------------

//    if (m_rawTextData)
//    {
//        //-------------------------
//        // YGJ Thurs 28th May 2015
//        // Output vector to txt file
//        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
//        ofstream DecFrmAsTxt;
//        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
//        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
//        {
//            if ((i+1)%width==0)
//                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
//            else
//                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
//        }
//        DecFrmAsTxt.close();
//        //-------------------------
//    }

//}

// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel) -- Working
Void TAppDecTop::saveFrameAsPNGPartition(TComPic* pcPic)
{
  // YGJ 14th Oct 2013 - Attempting to save decoded frames/images as PNG

  // unsigned height = m_iSourceHeight;
  // unsigned width = m_iSourceWidth;
  // unsigned FrameRes = (height*width);

  TComPicYuv* imageRec = pcPic->getPicYuvWPart(); 

  int pcPOC = pcPic->getPOC(); // Decode order from reading from YUV file.

  int poc = pcPOC; // For Test purpose override poc with correct poc for decoded stream

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);
  Pel*  piCb_Rec  = imageRec->getAddr(COMPONENT_Cb);
  Pel*  piCr_Rec  = imageRec->getAddr(COMPONENT_Cr);

  unsigned YStride = imageRec->getStride(COMPONENT_Y);
  unsigned CStride = imageRec->getStride(COMPONENT_Cb);

	int CShift = (YStride == (CStride<<1))? 1
		: YStride == CStride? 0 : -1;

   // 420: 1/4, 422: 1/2, 444: 1
   unsigned ChrFrmRes = CShift == 1? QuartFrameRes
       : CShift == 0? HalfFrameRes : FrameRes;

  // Allocate memory for output frame

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");
  Pel *ptrU_Rec;   ptrU_Rec = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Rec == NULL)   printf("calloc failed\n");
  Pel *ptrV_Rec;   ptrV_Rec = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Rec == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  char FrmAsPNG[255];  strcpy(FrmAsPNG, m_pchSSIMLogAndImageFile.c_str());  strcat(FrmAsPNG, "DecFrm_Partition_");    strcat(FrmAsPNG, strpoc);        strcat(FrmAsPNG, ".png");

  // YGJ Wed 27th May 2015
  // Store the partition info to text file
  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());  strcat(FrmAsTxt, "DecFrm_Partition_");    strcat(FrmAsTxt, strpoc);        strcat(FrmAsTxt, ".txt");

  std::vector<unsigned char> imgFrmAsPNG; imgFrmAsPNG.resize(FourTimesFrameRes);
  // YGJ Wed 27th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

  unsigned MaxValue = (1<<bitDepthLuma)-1;   unsigned HalfMaxValue = (MaxValue-1) >> 1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
    Int   shiftc = bitDepthChroma-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

int prevCloc = 0; // Previous cloc

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;
		unsigned cloc = prevCloc;

		// CShift: 1, 0, -1
		// 420: 1/4, 422: 1/2, 444: 1
		if (CShift == 1)
		{
		  if (x%2 == 0)
			cloc = (y >> 2) * (width >> 2) + (x >> 2);
		}
		else if (CShift == 1)
		{
		  if (x%2 == 0)
			cloc = (y >> 1) * (width >> 1) + (x >> 1);
		}
		else if (CShift == -1)
		  cloc = yloc;

		prevCloc = cloc;

		// allocate YUV value
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);

		int yInt_Rec = (int)ptrY_Rec[yloc];  int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];

		if ((x% CShift) == 0)
		{
		  unsigned cx = (x >> CShift);
		  
		  ptrU_Rec[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Rec[cx]+offsetc)>>shiftc); ptrV_Rec[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Rec[cx]+offsetc)>>shiftc);

		  uInt_Rec = (int)ptrU_Rec[cloc];  vInt_Rec = (int)ptrV_Rec[cloc];

		}
		else
		{
		  uInt_Rec = (int)ptrU_Rec[cloc];  vInt_Rec = (int)ptrV_Rec[cloc];
		}


		// Original is read fin
		//int yInt_RmO = yInt_Org; int u_MinHalfMaxVal_RmO = uInt_Org - HalfMaxValue;   int v_MinHalfMaxVal_RmO = vInt_Org - HalfMaxValue;
		// Reconstructed not read correctly.
		int yInt_RmO = yInt_Rec; int u_MinHalfMaxVal_RmO = uInt_Rec - HalfMaxValue;   int v_MinHalfMaxVal_RmO = vInt_Rec - HalfMaxValue;


		// Need to abs(green) to avoid negative values. abs(Y-U/2-V/2)

		// Rec - Org
		int r_RmO = yInt_RmO + v_MinHalfMaxVal_RmO + ((13 * v_MinHalfMaxVal_RmO) >> 5);
		int g_RmO = abs(yInt_RmO - ((11 * u_MinHalfMaxVal_RmO) >> 5) - ((23 * v_MinHalfMaxVal_RmO) >> 5));
		int b_RmO = yInt_RmO + u_MinHalfMaxVal_RmO + ((99 * u_MinHalfMaxVal_RmO) >> 7);

		// Rec - Org
		r_RmO =  r_RmO > MaxValue ? MaxValue : r_RmO < 0 ? 0 : r_RmO;
		g_RmO =  g_RmO > MaxValue ? MaxValue : g_RmO < 0 ? 0 : g_RmO;
		b_RmO =  b_RmO > MaxValue ? MaxValue : b_RmO < 0 ? 0 : b_RmO;

		// Partitioning
		if (yInt_RmO == 0 && (x % 2 == 0 || y % 2 == 0))
		{
		  r_RmO = yInt_RmO;
		  g_RmO = yInt_RmO;
		  b_RmO = yInt_RmO;
		}

		imgFrmAsPNG[4 * width * y + 4 * x + 0] = r_RmO; //Red
		imgFrmAsPNG[4 * width * y + 4 * x + 1] = g_RmO; //Green
		imgFrmAsPNG[4 * width * y + 4 * x + 2] = b_RmO; //Blue
		imgFrmAsPNG[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

        //-------------------------
        // YGJ Wed 27th May 2015
        // Store the partition info to array

        if (yInt_RmO == 0 && (x % 2 == 0 || y % 2 == 0))
            imgFrmAsTxt[width * y + x] = 1;
        else
            imgFrmAsTxt[width * y + x] = -1;
        //-------------------------

	  }
	  piY_Rec += YStride;


	  // CShift: 1, 0, -1
	  // 420: 1/4, 422: 1/2, 444: 1
	  if (CShift == 1)
	  {
		if (y%2 == 0)
		{
		  piCr_Rec += CStride; piCb_Rec += CStride;
		}
	  }
	  else if (CShift == 1)
	  {
		if (y%2 == 0)
		{
		  piCr_Rec += CStride; piCb_Rec += CStride;
		}
	  }
	  else if (CShift == -1)
	  {		  
		  piCr_Rec += CStride; piCb_Rec += CStride;
	  }
	}

	free(ptrY_Rec);
	free(ptrU_Rec);
	free(ptrV_Rec);


	  //Encode the image
	  unsigned error = lodepng::encode(FrmAsPNG, imgFrmAsPNG, width, height);

	  //if there's an error, display it
	  if(error) std::cout << "encoder error " << error << ": "<< lodepng_error_text(error) << std::endl;

      if (m_rawTextData)
      {
          //-------------------------
          // YGJ Wed 27th May 2015
          // Output vector to txt file
          // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
          ofstream DecFrmAsTxt;
          DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
          for(int i = 0; i < imgFrmAsTxt.size(); ++i)
          {
              if ((i+1)%width==0)
                  DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
              else
                  DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
          }
          DecFrmAsTxt.close();
          //-------------------------
      }

}

//// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel) -- Working
//Void TAppDecTop::saveFrameAsPNGPartitionwHighlight(TComPic* pcPic)
//{
//  // YGJ 14th Oct 2013 - Attempting to save decoded frames/images as PNG
//
//  // unsigned height = m_iSourceHeight;
//  // unsigned width = m_iSourceWidth;
//  // unsigned FrameRes = (height*width);
//
//  TComPicYuv* imageRec = pcPic->getPicYuvWPart();
//  TComPicYuv* imagePartSize = pcPic->getPicYuvWPartSize();
//
//  int pcPOC = pcPic->getPOC(); // Decode order from reading from YUV file.
//
//  int poc = pcPOC; // For Test purpose override poc with correct poc for decoded stream
//
//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);
//
//  Pel*  piY_PartSize   = imagePartSize->getAddr(COMPONENT_Y);
//
//  unsigned YStride = imageRec->getStride(COMPONENT_Y);
//  unsigned YPartStride = imagePartSize->getStride(COMPONENT_Y);
//
//  // Allocate memory for output frame
//
//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");
//
//  // Allocate memory to store partition size value
//  Pel *ptrY_PartSize;   ptrY_PartSize = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_PartSize == NULL)   printf("calloc failed\n");
//
//   // To Do:
//
//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.
//
//  //unsigned poc = ;
//  char strpoc[6];
//
//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif
//
//  // Set up file names
//
//  if (poc < 10)
//      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);
//
//  char FrmAsPNG[255];  strcpy(FrmAsPNG, m_pchSSIMLogAndImageFile);  strcat(FrmAsPNG, "DecFrm_PartitionhigHighlight_");    strcat(FrmAsPNG, strpoc);        strcat(FrmAsPNG, ".png");
//
//  // YGJ Wed 27th May 2015
//  // Store the partition info to text file
//  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile);  strcat(FrmAsTxt, "DecFrm_PartitionHighlight_");    strcat(FrmAsTxt, strpoc);        strcat(FrmAsTxt, ".txt");
//
//  std::vector<unsigned char> imgFrmAsPNG; imgFrmAsPNG.resize(FourTimesFrameRes);
//  // YGJ Wed 27th May 2015
//  // Store the QP to array
//  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);
//
//    unsigned MaxValue = (1<<bitDepthLuma)-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
//
//    for ( unsigned y = 0; y < height; y++ )
//    {
//      for ( unsigned x = 0; x < width; x++ )
//      {
//        unsigned yloc = y*width+x;
//
//
//        // allocate YUV value
//        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//
//        // This links the signalling value in stream to a local array
//        // Gather current parition size
//        ptrY_PartSize[yloc]  = Clip3<Pel>(0, MaxValue, (piY_PartSize[x]+offset)>>shift);
//
//        int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//
//        // Take current value parition size:
//        int yInt_PartSize = (int)ptrY_PartSize[yloc];
//
//        // YGJ - Using five states of highlighlighting
//        // 4 (Red), 8 (Yellow), 16 (Green), 32 (Blue), 64 (Clear)
//
//        // Only need luma
//        //int yInt_RmO = yInt_Rec;
//
//        // Rec - Org
//        int r = 0;
//        int g = 0;
//        int b = 0;
//
//        // Fized at 1/2 way (128)
//        // Normalise Had against assumed max.
//        float normQP = 0.5; //((float)yInt_Sig)/51;
//
//        //------------------
//        // YGJ 27th Oct 2014
//        // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//        // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//        switch (yInt_PartSize)
//        {
//            case 32 :  r = 0; g = (int)((normQP/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//                break;
//            case 16 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normQP-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//                break;
//            case 8 :  r = (int)(((normQP-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//                break;
//            case 4 : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normQP-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//                break;
//            default : 	r = g = b = yInt_Rec; // For 64x64
//        }
//
//        // Why is this not showing any 4x4?
//        //
//        if (yInt_PartSize < 8)
//            printf("saveFrameAsPNGPartitionwHighlight yInt_PartSize %d \n", yInt_PartSize);
//        //------------------
//
//        // Rec - Org
//        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;
//
//        // Partitioning
//        if (yInt_Rec == 0 && (x % 2 == 0 || y % 2 == 0))
//        {
//          r = yInt_Rec;
//          g = yInt_Rec;
//          b = yInt_Rec;
//        }
//
//        imgFrmAsPNG[4 * width * y + 4 * x + 0] = r; //Red
//        imgFrmAsPNG[4 * width * y + 4 * x + 1] = g; //Green
//        imgFrmAsPNG[4 * width * y + 4 * x + 2] = b; //Blue
//        imgFrmAsPNG[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now
//
//        //-------------------------
//        // YGJ Wed 27th May 2015
//        // Store the partition info to array
//
//        if (yInt_Rec == 0 && (x % 2 == 0 || y % 2 == 0))
//            imgFrmAsTxt[width * y + x] = 1;
//        else
//            imgFrmAsTxt[width * y + x] = -1;
//        //-------------------------
//
//      }
//      // Next row
//      piY_Rec += YStride;
//      piY_PartSize += YPartStride;
//
//
//    }
//
//    free(ptrY_Rec);
//    free(ptrY_PartSize);
//
//
//      //Encode the image
//      unsigned error = lodepng::encode(FrmAsPNG, imgFrmAsPNG, width, height);
//
//      //if there's an error, display it
//      if(error) std::cout << "encoder error " << error << ": "<< lodepng_error_text(error) << std::endl;
//
//      if (m_rawTextData)
//      {
//          //-------------------------
//          // YGJ Wed 27th May 2015
//          // Output vector to txt file
//          // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
//          ofstream DecFrmAsTxt;
//          DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
//          for(int i = 0; i < imgFrmAsTxt.size(); ++i)
//          {
//              if ((i+1)%width==0)
//                  DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
//              else
//                  DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
//          }
//          DecFrmAsTxt.close();
//          //-------------------------
//      }
//
//}
//

// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel) -- Working
Void TAppDecTop::saveFrameAsPNGPartwQP(TComPic* pcPic)
{

  // unsigned height = m_iSourceHeight;
  // unsigned width = m_iSourceWidth;
  // unsigned FrameRes = (height*width);

  TComPicYuv* imageRec = pcPic->getPicYuvWPart(); 
  TComPicYuv* imageSig = pcPic->getPicYuvWQPPart(); 

  int pcPOC = pcPic->getPOC(); // Decode order from reading from YUV file.

  int poc = pcPOC; // For Test purpose override poc with correct poc for decoded stream

  Pel*  piY_Sig   = imageSig->getAddr(COMPONENT_Y);
  Pel*  piCb_Sig  = imageSig->getAddr(COMPONENT_Cb);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  unsigned YStride = imageRec->getStride(COMPONENT_Y);
  unsigned CStride = imageRec->getStride(COMPONENT_Cb);


  // 420: 1:1/4:1/4, Then Y:UV = 2xY:1xChr => CShift = 1
  // 422: 1:1/2:1/2, Then Y:UV = 2xY:2xChr => CShift = 0
  // 444: 1:1:1, Then Y:UV = 2xY:4xChr => CShift = -1
	int CShift = (YStride == (CStride<<1))? 1
		: YStride == CStride? 0 : -1;

   // 420: 1/4, 422: 1/2, 444: 1
   unsigned ChrFrmRes = CShift == 1? QuartFrameRes
       : CShift == 0? HalfFrameRes : FrameRes;

  // Allocate memory for output frame

  //// Orig
  Pel *ptrY_Sig;   ptrY_Sig = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Sig == NULL)   printf("calloc failed\n");
  Pel *ptrU_Sig;   ptrU_Sig = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Sig == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  char strpoc[6];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

 char FrmAsPNG[255];  strcpy(FrmAsPNG, m_pchSSIMLogAndImageFile.c_str());  strcat(FrmAsPNG, "DecFrm_PartwQP_");    strcat(FrmAsPNG, strpoc);        strcat(FrmAsPNG, ".png");

  // YGJ Tues 26th May 2015
  // Store the QP to text file
  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());  strcat(FrmAsTxt, "DecFrm_PartwQP_");    strcat(FrmAsTxt, strpoc);        strcat(FrmAsTxt, ".txt");

  std::vector<unsigned char> imgFrmAsPNG; imgFrmAsPNG.resize(FourTimesFrameRes);
  // YGJ Wed 27th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

  unsigned MaxValue = (1<<bitDepthLuma)-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
    Int   shiftc = bitDepthChroma-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

int prevCloc = 0; // Previous cloc

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;
		unsigned cloc = prevCloc;

		// CShift: 1, 0, -1
		// 420: 1/4, 422: 1/2, 444: 1
		if (CShift == 1)
		{
		  if (x%2 == 0)
			cloc = (y >> 2) * (width >> 2) + (x >> 2);
		}
		else if (CShift == 1)
		{
		  if (x%2 == 0)
			cloc = (y >> 1) * (width >> 1) + (x >> 1);
		}
		else if (CShift == -1)
		  cloc = yloc;

		prevCloc = cloc;

		// allocate YUV value

		// Y_Sig contains QP and U_Sig contains skipped_flag

		ptrY_Sig[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Sig[x]+offset)>>shift);
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);

		int yInt_Sig = (int)ptrY_Sig[yloc];  int  uInt_Sig = (int)ptrU_Sig[cloc]; 
		int yInt_Rec = (int)ptrY_Rec[yloc];  

        //-------------------------
        imgFrmAsTxt[width * y + x] = yInt_Sig; //-1;
        //-------------------------

		if ((x% CShift) == 0)
		{
		  unsigned cx = (x >> CShift);

		  ptrU_Sig[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Sig[cx]+offsetc)>>shiftc); 

		  uInt_Sig = (int)ptrU_Sig[cloc];  

		}
		else
		{
		  uInt_Sig = (int)ptrU_Sig[cloc]; 
		}

		// Rec - Org
		int r = 0;
		int g = 0;
		int b = 0;


		int val = yInt_Sig < 13 ? 0 : yInt_Sig < 26 ? 1 : yInt_Sig < 39 ? 2 : 3;

		// Normalise Had against assumed max.
		float normQP = ((float)yInt_Sig)/51; 

		if ( uInt_Sig == 0 ) // Skipped Flag is zero
		{

			//------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
			switch (val)
			{
				case 0 :  r = 0; g = (int)((normQP/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
					break;
				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normQP-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
					break;
				case 2 :  r = (int)(((normQP-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
					break;
				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normQP-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
					break;
			}
            //------------------

		}
		else
		{
			r = g = b = yInt_Rec;
		}


		// Rec - Org
		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;

		// Partitioning
		if (yInt_Rec == 0 && (x % 2 == 0 || y % 2 == 0))
		{
		  r = yInt_Rec;
		  g = yInt_Rec;
		  b = yInt_Rec;
		}

		imgFrmAsPNG[4 * width * y + 4 * x + 0] = r; //Red
		imgFrmAsPNG[4 * width * y + 4 * x + 1] = g; //Green
		imgFrmAsPNG[4 * width * y + 4 * x + 2] = b; //Blue
		imgFrmAsPNG[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  //piY += YStride;
	  piY_Sig += YStride;
	  piY_Rec += YStride;


	  // CShift: 1, 0, -1
	  // 420: 1/4, 422: 1/2, 444: 1
	  if (CShift == 1)
	  {
		if (y%2 == 0)
		{
		  piCb_Sig += CStride;
		}
	  }
	  else if (CShift == 1)
	  {
		if (y%2 == 0)
		{
		  piCb_Sig += CStride;
		}
	  }
	  else if (CShift == -1)
	  {
		  piCb_Sig += CStride;
	  }
	}

	free(ptrY_Sig);
	free(ptrU_Sig);

	free(ptrY_Rec);


 
	  //Encode the image
	  unsigned error = lodepng::encode(FrmAsPNG, imgFrmAsPNG, width, height);

	  //if there's an error, display it
	  if(error) std::cout << "encoder error " << error << ": "<< lodepng_error_text(error) << std::endl;

      if (m_rawTextData)
      {
          //-------------------------
          // YGJ Wed 27th May 2015
          // Output vector to txt file
          // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
          ofstream DecFrmAsTxt;
          DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
          for(int i = 0; i < imgFrmAsTxt.size(); ++i)
          {
              if ((i+1)%width==0)
                  DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
              else
                  DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
          }
          DecFrmAsTxt.close();
          //-------------------------
      }

	////---------------------


}

// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel) -- Working
Void TAppDecTop::saveFrameAsPNGPartwQPwBlkHighlight(TComPic* pcPic)
{

  // unsigned height = m_iSourceHeight;
  // unsigned width = m_iSourceWidth;
  // unsigned FrameRes = (height*width);

//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec = pcPic->getPicYuvWPart();
  TComPicYuv* imageSig = pcPic->getPicYuvWQPPart();
  TComPicYuv* imagePartSize = pcPic->getPicYuvWPartSize();

  int pcPOC = pcPic->getPOC(); // Decode order from reading from YUV file.

  int poc = pcPOC; // For Test purpose override poc with correct poc for decoded stream

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Sig   = imageSig->getAddr(COMPONENT_Y);
  Pel*  piCb_Sig  = imageSig->getAddr(COMPONENT_Cb);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_PartSize   = imagePartSize->getAddr(COMPONENT_Y);

//  unsigned YStrideOrg = imageOrg->getStride(COMPONENT_Y);

  unsigned YStride = imageRec->getStride(COMPONENT_Y);
  unsigned CStride = imageRec->getStride(COMPONENT_Cb);

  unsigned YPartStride = imagePartSize->getStride(COMPONENT_Y);


  // 420: 1:1/4:1/4, Then Y:UV = 2xY:1xChr => CShift = 1
  // 422: 1:1/2:1/2, Then Y:UV = 2xY:2xChr => CShift = 0
  // 444: 1:1:1, Then Y:UV = 2xY:4xChr => CShift = -1
    int CShift = (YStride == (CStride<<1))? 1
        : YStride == CStride? 0 : -1;

   // 420: 1/4, 422: 1/2, 444: 1
   unsigned ChrFrmRes = CShift == 1? QuartFrameRes
       : CShift == 0? HalfFrameRes : FrameRes;

  // Allocate memory for output frame

  //// Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  Pel *ptrY_Sig;   ptrY_Sig = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Sig == NULL)   printf("calloc failed\n");
  Pel *ptrU_Sig;   ptrU_Sig = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Sig == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Allocate memory to store partition size value
  Pel *ptrY_PartSize;   ptrY_PartSize = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_PartSize == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  char strpoc[6];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

 char FrmAsPNG[255];  strcpy(FrmAsPNG, m_pchSSIMLogAndImageFile.c_str());  strcat(FrmAsPNG, "DecFrm_PartwQPwHighlight_");    strcat(FrmAsPNG, strpoc);        strcat(FrmAsPNG, ".png");

  // YGJ Tues 26th May 2015
  // Store the QP to text file
  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());  strcat(FrmAsTxt, "DecFrm_PartwQPwHighlight_");    strcat(FrmAsTxt, strpoc);        strcat(FrmAsTxt, ".txt");

  std::vector<unsigned char> imgFrmAsPNG; imgFrmAsPNG.resize(FourTimesFrameRes);
  // YGJ Wed 27th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

  unsigned MaxValue = (1<<bitDepthLuma)-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
    Int   shiftc = bitDepthChroma-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

int prevCloc = 0; // Previous cloc

    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;
        unsigned cloc = prevCloc;

        // CShift: 1, 0, -1
        // 420: 1/4, 422: 1/2, 444: 1
        if (CShift == 1)
        {
          if (x%2 == 0)
            cloc = (y >> 2) * (width >> 2) + (x >> 2);
        }
        else if (CShift == 1)
        {
          if (x%2 == 0)
            cloc = (y >> 1) * (width >> 1) + (x >> 1);
        }
        else if (CShift == -1)
          cloc = yloc;

        prevCloc = cloc;

        // allocate YUV value

//        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);

        // Y_Sig contains QP and U_Sig contains skipped_flag

        ptrY_Sig[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Sig[x]+offset)>>shift);
        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);

        // This links the signalling value in stream to a local array
        // Gather current parition size
        ptrY_PartSize[yloc]  = Clip3<Pel>(0, MaxValue, (piY_PartSize[x]+offset)>>shift);

//        int yInt_Org = (int)ptrY_Org[yloc];

        int yInt_Sig = (int)ptrY_Sig[yloc];  int  uInt_Sig = (int)ptrU_Sig[cloc];
        int yInt_Rec = (int)ptrY_Rec[yloc];

        // Take current value parition size:
        int yInt_PartSize = (int)ptrY_PartSize[yloc];

        //-------------------------
        imgFrmAsTxt[width * y + x] = yInt_Sig; //-1;
        //-------------------------

        if ((x% CShift) == 0)
        {
          unsigned cx = (x >> CShift);

          ptrU_Sig[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Sig[cx]+offsetc)>>shiftc);

          uInt_Sig = (int)ptrU_Sig[cloc];

        }
        else
        {
          uInt_Sig = (int)ptrU_Sig[cloc];
        }

        // Rec - Org
        int r = 0;
        int g = 0;
        int b = 0;


//        int val = yInt_Sig < 13 ? 0 : yInt_Sig < 26 ? 1 : yInt_Sig < 39 ? 2 : 3;

        // Normalise Had against assumed max.
        float normQP = ((float)yInt_Sig)/51;

        if ( uInt_Sig == 0 ) // Skipped Flag is zero
        {

//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((normQP/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normQP-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((normQP-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normQP-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------

//            //------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//            switch (yInt_PartSize)
//            {
//                case 32 :  r = 0; g = (int)((normQP/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//                    break;
//                case 16 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normQP-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//                    break;
//                case 8 :  r = (int)(((normQP-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//                    break;
//                case 4 : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normQP-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//                    break;
//                default : 	r = g = b = yInt_Rec; // For 64x64
//            }

//            //------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//            switch (yInt_PartSize)
//            {
//                case 4 :  r = 255; g = (int)((normQP/(float)0.8)*yInt_Rec); b = (int)((normQP/(float)0.8)*yInt_Rec);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//                    break;
//                case 8 :  r = 255; g = (int)((normQP/(float)0.55)*yInt_Rec); b = (int)((normQP/(float)0.8)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//                    break;
//                case 16 :  r = 255; g = 255; b = (int)((normQP/(float)0.8)*yInt_Rec); // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//                    break;
//                case 32 : r = (int)((normQP/(float)0.8)*yInt_Rec); g = 255; b = (int)((normQP/(float)0.8)*yInt_Rec); // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//                    break;
//                default : 	r = (int)((normQP/(float)0.8)*yInt_Rec); g = 255; b = 255; // For 64x64
//            }

                //------------------
                // YGJ 27th Oct 2014
                // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
                // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
                switch (yInt_PartSize)
                {
                    case 4 :  r = 255; g = (int)((normQP/(float)0.8)*(min(yInt_Rec << 1, 255))); b = (int)((normQP/(float)0.8)*(min(yInt_Rec << 1, 255)));   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                        break;
                    case 8 :  r = 255; g = (int)((normQP/(float)0.55)*(min(yInt_Rec << 1, 255))); b = (int)((normQP/(float)0.8)*(min(yInt_Rec << 1, 255))); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                        break;
                    case 16 :  r = 255; g = 255; b = (int)((normQP/(float)0.8)*(min(yInt_Rec << 1, 255))); // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                        break;
                    case 32 : r = (int)((normQP/(float)0.8)*(min(yInt_Rec << 1, 255))); g = 255; b = (int)((normQP/(float)0.8)*(min(yInt_Rec << 1, 255))); // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                        break;
                    default : 	r = (int)((normQP/(float)0.8)*(min(yInt_Rec << 1, 255))); g = 255; b = 255; // For 64x64
                }

        }
        else
        {
            r = g = b = yInt_Rec;
        }


        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;

        // Partitioning
        if (yInt_Rec == 0 && (x % 2 == 0 || y % 2 == 0))
        {
//            if ( uInt_Sig == 1  && (x % 1 == 0 || y % 1 == 0)) // Skipped Flag is zero
//            {
//                r = yInt_Org;
//                g = yInt_Org;
//                b = yInt_Org;
//            }
//            else
//            {
                r = yInt_Rec;
                g = yInt_Rec;
                b = yInt_Rec;
//            }

        }

        imgFrmAsPNG[4 * width * y + 4 * x + 0] = r; //Red
        imgFrmAsPNG[4 * width * y + 4 * x + 1] = g; //Green
        imgFrmAsPNG[4 * width * y + 4 * x + 2] = b; //Blue
        imgFrmAsPNG[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      //piY += YStride;
//      piY_Org += YStrideOrg;
      piY_Sig += YStride;
      piY_Rec += YStride;
      piY_PartSize += YPartStride;



      // CShift: 1, 0, -1
      // 420: 1/4, 422: 1/2, 444: 1
      if (CShift == 1)
      {
        if (y%2 == 0)
        {
          piCb_Sig += CStride;
        }
      }
      else if (CShift == 1)
      {
        if (y%2 == 0)
        {
          piCb_Sig += CStride;
        }
      }
      else if (CShift == -1)
      {
          piCb_Sig += CStride;
      }
    }

//    free(ptrY_Org);

    free(ptrY_Sig);
    free(ptrU_Sig);

    free(ptrY_Rec);

    free(ptrY_PartSize);



      //Encode the image
      unsigned error = lodepng::encode(FrmAsPNG, imgFrmAsPNG, width, height);

      //if there's an error, display it
      if(error) std::cout << "encoder error " << error << ": "<< lodepng_error_text(error) << std::endl;

      if (m_rawTextData)
      {
          //-------------------------
          // YGJ Wed 27th May 2015
          // Output vector to txt file
          // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
          ofstream DecFrmAsTxt;
          DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
          for(int i = 0; i < imgFrmAsTxt.size(); ++i)
          {
              if ((i+1)%width==0)
                  DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
              else
                  DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
          }
          DecFrmAsTxt.close();
          //-------------------------
      }

    ////---------------------


}


Void TAppDecTop::saveFrameAsPNGPartwBitUsage(TComPic* pcPic)
{
  // unsigned height = m_iSourceHeight;
  // unsigned width = m_iSourceWidth;
  // unsigned FrameRes = (height*width);

  TComPicYuv* imageRec = pcPic->getPicYuvWPart(); 
  TComPicYuv* imageSig = pcPic->getPicYuv_CU_BitUsage(); 

  int pcPOC = pcPic->getPOC(); // Decode order from reading from YUV file.

  int poc = pcPOC; // For Test purpose override poc with correct poc for decoded stream

  Pel*  piY_Sig   = imageSig->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  unsigned YStride = imageRec->getStride(COMPONENT_Y);
 
  // Allocate memory for output frame

  //// Orig
  Pel *ptrY_Sig;   ptrY_Sig = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Sig == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  char strpoc[6];
  char strMaxCUsize[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strMaxCUsize, sizeof(strMaxCUsize), "%d", m_maxCUsize);

  char FrmAsPNG[255];  strcpy(FrmAsPNG, m_pchSSIMLogAndImageFile.c_str());
    
  strcat(FrmAsPNG, "DecFrm_PartwCU_BitUsage_");    
  strcat(FrmAsPNG, strpoc);   
  strcat(FrmAsPNG, "_MaxCUsize");  strcat(FrmAsPNG, strMaxCUsize);  
  strcat(FrmAsPNG, ".png");

  // YGJ Tues 26th May 2015
  // Store the QP to text file
  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());
  strcat(FrmAsTxt, "DecFrm_PartwCU_BitUsage_");
  strcat(FrmAsTxt, strpoc);
  strcat(FrmAsTxt, "_MaxCUsize");  strcat(FrmAsTxt, strMaxCUsize);
  strcat(FrmAsTxt, ".txt");
  
  std::vector<unsigned char> imgFrmAsPNG; imgFrmAsPNG.resize(FourTimesFrameRes);
  // YGJ Thurs 28th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

  unsigned MaxValue = (1<<bitDepthLuma)-1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//int prevCloc = 0; // Previous cloc

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;

		// Position to be at the start of the Coding Unit (CU)
		// Since first four px in every row in the Sub-CU has been set with Bit Usage value it is OK to start at the beginning of the row for every CU
		unsigned CUx = (x >> 6) << 6; // Round down to the nearest 64th px.
		unsigned ylocCU = y*width+CUx;

		ptrY_Sig[ylocCU]  = Clip3<Pel>(0, MaxValue, (piY_Sig[CUx]+offset)>>shift);
		ptrY_Sig[ylocCU + 1]  = Clip3<Pel>(0, MaxValue, (piY_Sig[CUx + 1]+offset)>>shift);
		ptrY_Sig[ylocCU + 2]  = Clip3<Pel>(0, MaxValue, (piY_Sig[CUx + 2]+offset)>>shift);
		ptrY_Sig[ylocCU + 3]  = Clip3<Pel>(0, MaxValue, (piY_Sig[CUx + 3]+offset)>>shift);

		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
	
		// Assuming Coding Unit is fixed at 64 x 64.
		// However, remaining width and height may be less than 64 by 64.

		// This stays the same within CU
		//int yInt_Sig = (int)ptrY_Sig[ylocCU];  //int  uInt_Sig = (int)ptrU_Sig[cloc]; //int  vInt_Org = (int)ptrV_Org[cloc];vInt_Org
		// Obtain the y (luma part).
		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];

		// Rec - Org
		int r = 0;
		int g = 0;
		int b = 0;

		int  px[4];

		px[0] = (int)ptrY_Sig[ylocCU];  
		px[1] = (int)ptrY_Sig[ylocCU + 1];  
		px[2] = (int)ptrY_Sig[ylocCU + 2];  
		px[3] = (int)ptrY_Sig[ylocCU + 3];  
		
		// Put the bit usage value back together.
		Int64 combinedScore = px[3] << 24 | px[2] << 16 | px[1] << 8 | px[0];  

		Int BitUsage = (Int)combinedScore;

        //-------------------------
        imgFrmAsTxt[width * y + x] = BitUsage; //-1;
        //-------------------------
		

		int MaxBitUsage = m_maxCUsize;

		BitUsage = BitUsage > MaxBitUsage? MaxBitUsage : BitUsage;
		 
		int val = BitUsage < (MaxBitUsage >> 2) ? 0 : BitUsage < (MaxBitUsage >> 1) ? 1 : BitUsage < ((MaxBitUsage >> 1) + ( MaxBitUsage >> 2)) ? 2 : 3;

		// Normalise Had against assumed max.
		float normBit = ((float)BitUsage)/((float)MaxBitUsage); 

		//if ( BitUsage > 0 )        
        if ( BitUsage > (MaxBitUsage >> 8) )        
		{

			//------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
			switch (val)
			{
				case 0 :  r = 0; g = (int)((normBit/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
					break;
				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normBit-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
					break;
				case 2 :  r = (int)(((normBit-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
					break;
				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normBit-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
					break;
			}
            //------------------

		}
		else
		{
			r = g = b = yInt_Rec;
		}


		// Rec - Org
		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;

		// Partitioning
		if (yInt_Rec == 0 && (x % 2 == 0 || y % 2 == 0))
		{
		  r = yInt_Rec;
		  g = yInt_Rec;
		  b = yInt_Rec;
		}

		imgFrmAsPNG[4 * width * y + 4 * x + 0] = r; //Red
		imgFrmAsPNG[4 * width * y + 4 * x + 1] = g; //Green
		imgFrmAsPNG[4 * width * y + 4 * x + 2] = b; //Blue
		imgFrmAsPNG[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  piY_Sig += YStride;
	  piY_Rec += YStride;


	}

	free(ptrY_Sig);

	free(ptrY_Rec);


 
	  //Encode the image
	  unsigned error = lodepng::encode(FrmAsPNG, imgFrmAsPNG, width, height);

	  //if there's an error, display it
	  if(error) std::cout << "encoder error " << error << ": "<< lodepng_error_text(error) << std::endl;

      if (m_rawTextData)
      {
          //-------------------------
          // YGJ Thurs 28th May 2015
          // Output vector to txt file
          // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
          ofstream DecFrmAsTxt;
          DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
          for(int i = 0; i < imgFrmAsTxt.size(); ++i)
          {
              if ((i+1)%width==0)
                  DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
              else
                  DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
          }
          DecFrmAsTxt.close();
          //-------------------------
      }


	////---------------------


}

Void TAppDecTop::saveFrameAsPNG_SADx_Only(TComPic* pcPic)
{

  // unsigned height = m_iSourceHeight;
  // unsigned width = m_iSourceWidth;
  // unsigned FrameRes = (height*width);

  // YGJ 22nd Septy 2014
  // Set width
  unsigned blkwidth = DistWidthSize(m_distWidthSize);
  unsigned blksz = blkwidth*blkwidth;
  
  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    // YGJ 16th March 2015 - Block size can vary in SSE version.

    int shiftby = (int)log2(blkwidth);
    int downscaleby = (int)log2(blksz);

    Distortion *ptrDist_iSumHad;   ptrDist_iSumHad = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_iSumHad == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  char strpoc[6];  
  char strRange[8];
  char strFactor[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  char strblkwidth[6];
  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);
  
  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);
  
  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile.c_str());
  strcat(SSIMHeatmap, "DecFrm_SAD");    strcat(SSIMHeatmap, strblkwidth);  
  strcat(SSIMHeatmap, "_OnlyHeatMap_");    
  strcat(SSIMHeatmap, strpoc);   
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);        
  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);  
  strcat(SSIMHeatmap, ".png");

  // YGJ Tues 26th May 2015
  // Store the QP to text file
  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());
  //strcat(FrmAsTxt, "DecFrm_HadamardDistortionHeatMap_");
  strcat(FrmAsTxt, "DecFrm_SADOnlyDistortionHeatMap_");
  strcat(FrmAsTxt, strpoc);
  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
  strcat(FrmAsTxt, "_Factor");  strcat(FrmAsTxt, strFactor);
  strcat(FrmAsTxt, ".txt");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);
  // YGJ Thurs 28th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

  unsigned MaxValue = (1<<bitDepthLuma)-1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;


	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;

		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

		int yInt_Org = (int)ptrY_Org[yloc]; 
		int yInt_Rec = (int)ptrY_Rec[yloc];  
		int yInt_Part = (int)ptrY_Part[yloc];

		// seems fine here
		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);
        

		bool HadRegion = false;
		Distortion iSumHad =0;

        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        //if ((y < (height-blkwidth)) && (x < (width-blkwidth)) && ((y % blkwidth == 0) && (x % blkwidth == 0)))
        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) )
		{
		  HadRegion = true;

		  //int HadDiff[blksz];
		  // http://www.cplusplus.com/forum/general/40423/
		  int* HadDiff = new int[blksz];


			//for ( unsigned n = 0; n < blkwidth; n++ )
			//{
			//	for ( unsigned m = 0; m < blkwidth; m++ )
			//	{
                    unsigned n = 0, m = 0;
					// y*width + x
					unsigned yloc8x8 = n*blkwidth+m;

					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

					////------------------
					//// YGJ 12th July 2014
					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
					//// a -- set up and initialise variables

					////------------------

					HadDiff[yloc8x8] = y_Org - y_Rec; 
                    imgFrmAsTxt[width * y + x] = (int)abs(HadDiff[yloc8x8]);
			//	}
			//}

			int i, j;

			for (i = 0; i < blkwidth; i++)
			{
			  for (j = 0; j < blkwidth; j++)
			  {
				iSumHad += abs(HadDiff[i+j*blkwidth]); 
			  }
			}
			
            ptrDist_iSumHad[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = iSumHad;

			delete HadDiff;

		}
        else if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
        {

            iSumHad = ptrDist_iSumHad[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
            HadRegion = true;
        }

		int yInt = yInt_Rec;

		int r, b, g;

        //-------------------------
        // YGJ Thurs 28th May 2015
        // Store the QP to array

        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) )
        {
            //imgFrmAsTxt[width * y + x] = (int)iSumHad;        
        }
        else
            imgFrmAsTxt[width * y + x] = -1;
        //-------------------------


		//  APC score will be between 0 and 127.
		// Dependent upon value apply different colour
		if (HadRegion == true)
		{
			//------------------
			// Using arrays as look up tables to ensure values set are consistent
			int loc = (int)log2((double)blkwidth) - 3;
			
			int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
			float maxScaled = (float)((float)maxUnscaled * (0.1024));
			float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

			Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;
								
//			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//				printf("SAD %d is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
			float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = ((float)normHad) > 1.0? (float)1.0 : normHad;

            int val =  ((double)normHad) < 0.25? 0 :
                       ((double)normHad) < 0.5? 1 :
                       ((double)normHad) < 0.75? 2 : 3;
			

			//------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
			switch (val)
			{
				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
					break;
				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
					break;
				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
					break;				
				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
					break;
			}
            //------------------
		}
		else
		{
			r = yInt; 
			g = yInt; 
			b = yInt; 
		}


		// Rec - Org
		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


		// Partitioning -- Not Working
		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
		{
		  r = 0; 
		  g = 0; 
		  b = 0; 
		}

		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  piY_Org += YStride;
	  piY_Rec += YStrideRec;
	  piY_Part += YStrideRec;
      
	}


	free(ptrY_Org8x8);
	free(ptrY_Rec8x8);

	free(ptrY_Org);

	free(ptrY_Rec);

	free(ptrY_Part);

	//-----------------------

	if(m_outputSSIMHeatmaps)
	{
	  std::vector<unsigned char> png;

	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

	  //if there's an error, display it
	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
	}

   //-----------------------

    if (m_rawTextData)
    {
        //-------------------------
        // YGJ Thurs 28th May 2015
        // Output vector to txt file
        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
        ofstream DecFrmAsTxt;
        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
        {
            if ((i+1)%width==0)
                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
            else
                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
        }
        DecFrmAsTxt.close();
    }

}

//// YGJ 28th June 2015 - SAD per pixel with block size coloured
//// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel) -- Working
//Void TAppDecTop::saveFrameAsPNGPartwSADwBlkHighlight(TComPic* pcPic)
//{

//  // unsigned height = m_iSourceHeight;
//  // unsigned width = m_iSourceWidth;
//  // unsigned FrameRes = (height*width);

//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec = pcPic->getPicYuvWPart();
//  TComPicYuv* imageSig = pcPic->getPicYuvWQPPart();
//  TComPicYuv* imagePartSize = pcPic->getPicYuvWPartSize();

//  int pcPOC = pcPic->getPOC(); // Decode order from reading from YUV file.

//  int poc = pcPOC; // For Test purpose override poc with correct poc for decoded stream

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Sig   = imageSig->getAddr(COMPONENT_Y);
//  Pel*  piCb_Sig  = imageSig->getAddr(COMPONENT_Cb);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_PartSize   = imagePartSize->getAddr(COMPONENT_Y);

//  unsigned YStrideOrg = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStride = imageRec->getStride(COMPONENT_Y);
//  unsigned CStride = imageRec->getStride(COMPONENT_Cb);

//  unsigned YPartStride = imagePartSize->getStride(COMPONENT_Y);


//  // 420: 1:1/4:1/4, Then Y:UV = 2xY:1xChr => CShift = 1
//  // 422: 1:1/2:1/2, Then Y:UV = 2xY:2xChr => CShift = 0
//  // 444: 1:1:1, Then Y:UV = 2xY:4xChr => CShift = -1
//    int CShift = (YStride == (CStride<<1))? 1
//        : YStride == CStride? 0 : -1;

//   // 420: 1/4, 422: 1/2, 444: 1
//   unsigned ChrFrmRes = CShift == 1? QuartFrameRes
//       : CShift == 0? HalfFrameRes : FrameRes;

//  // Allocate memory for output frame

//  //// Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  Pel *ptrY_Sig;   ptrY_Sig = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Sig == NULL)   printf("calloc failed\n");
//  Pel *ptrU_Sig;   ptrU_Sig = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Sig == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Allocate memory to store partition size value
//  Pel *ptrY_PartSize;   ptrY_PartSize = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_PartSize == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  char strpoc[6];

//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);

// char FrmAsPNG[255];  strcpy(FrmAsPNG, m_pchSSIMLogAndImageFile);  strcat(FrmAsPNG, "DecFrm_PartwSADwHighlight_");    strcat(FrmAsPNG, strpoc);        strcat(FrmAsPNG, ".png");

//  // YGJ Tues 26th May 2015
//  // Store the QP to text file
//  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile);  strcat(FrmAsTxt, "DecFrm_PartwSADwHighlight_");    strcat(FrmAsTxt, strpoc);        strcat(FrmAsTxt, ".txt");

//  std::vector<unsigned char> imgFrmAsPNG; imgFrmAsPNG.resize(FourTimesFrameRes);
//  // YGJ Wed 27th May 2015
//  // Store the QP to array
//  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

//  unsigned MaxValue = (1<<bitDepthLuma)-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
//    Int   shiftc = bitDepthChroma-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

//int prevCloc = 0; // Previous cloc

//    for ( unsigned y = 0; y < height; y++ )
//    {
//      for ( unsigned x = 0; x < width; x++ )
//      {
//        unsigned yloc = y*width+x;
//        unsigned cloc = prevCloc;

//        // CShift: 1, 0, -1
//        // 420: 1/4, 422: 1/2, 444: 1
//        if (CShift == 1)
//        {
//          if (x%2 == 0)
//            cloc = (y >> 2) * (width >> 2) + (x >> 2);
//        }
//        else if (CShift == 1)
//        {
//          if (x%2 == 0)
//            cloc = (y >> 1) * (width >> 1) + (x >> 1);
//        }
//        else if (CShift == -1)
//          cloc = yloc;

//        prevCloc = cloc;

//        // allocate YUV value

//        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);

//        // Y_Sig contains QP and U_Sig contains skipped_flag

//        ptrY_Sig[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Sig[x]+offset)>>shift);
//        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);

//        // This links the signalling value in stream to a local array
//        // Gather current parition size
//        ptrY_PartSize[yloc]  = Clip3<Pel>(0, MaxValue, (piY_PartSize[x]+offset)>>shift);

//        int yInt_Org = (int)ptrY_Org[yloc];

//        int yInt_Sig = (int)ptrY_Sig[yloc];  int  uInt_Sig = (int)ptrU_Sig[cloc];
//        int yInt_Rec = (int)ptrY_Rec[yloc];

//        // Take current value parition size:
//        int yInt_PartSize = (int)ptrY_PartSize[yloc];

//        int yInt_diff = abs(yInt_Org - yInt_Rec);

//        //-------------------------
//        imgFrmAsTxt[width * y + x] = yInt_Sig; //-1;
//        //-------------------------

//        if ((x% CShift) == 0)
//        {
//          unsigned cx = (x >> CShift);

//          ptrU_Sig[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Sig[cx]+offsetc)>>shiftc);

//          uInt_Sig = (int)ptrU_Sig[cloc];

//        }
//        else
//        {
//          uInt_Sig = (int)ptrU_Sig[cloc];
//        }

//        // Rec - Org
//        int r = 0;
//        int g = 0;
//        int b = 0;


////        int val = yInt_Sig < 13 ? 0 : yInt_Sig < 26 ? 1 : yInt_Sig < 39 ? 2 : 3;

//        // Normalise Had against assumed max.
//        //float normQP = ((float)yInt_Sig)/51;
//        float normQP = ((float)yInt_diff)/255;
//        // But need to it to be upto 40%
//        normQP = 1 - (normQP*0.4);

//        if ( uInt_Sig == 0 ) // Skipped Flag is zero
//        {

////            //------------------
////            // YGJ 27th Oct 2014
////            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
////            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
////            switch (yInt_PartSize)
////            {
////                case 4 :  r = 255; g = 204-(int)(normQP*yInt_Rec); b = 204-(int)(normQP*yInt_Rec);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
////                    break;
////                case 8 :  r = 255; g = 229-(int)(normQP*yInt_Rec); b = 204-(int)(normQP*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
////                    break;
////                case 16 :  r = 255; g = 255; b = 204-(int)(normQP*yInt_Rec); // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
////                    break;
////                case 32 : r = 204-(int)(normQP*yInt_Rec); g = 255; b = 204-(int)(normQP*yInt_Rec); // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
////                    break;
////                default : 	r = 204-(int)(normQP*yInt_Rec); g = 255; b = 255; // For 64x64
////            }

////            //------------------
////            // YGJ 27th Oct 2014
////            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
////            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
////            switch (yInt_PartSize)
////            {
////                case 4 :  r = 255; g = 204-(int)((normQP/(float)0.8)*yInt_Rec); b = 204-(int)((normQP/(float)0.8)*yInt_Rec);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
////                    break;
////                case 8 :  r = 255; g = 229-(int)((normQP/(float)0.8)*yInt_Rec); b = 204-(int)((normQP/(float)0.8)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
////                    break;
////                case 16 :  r = 255; g = 255; b = 204-(int)((normQP/(float)0.8)*yInt_Rec); // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
////                    break;
////                case 32 : r = 204-(int)((normQP/(float)0.8)*yInt_Rec); g = 255; b = 204-(int)((normQP/(float)0.8)*yInt_Rec); // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
////                    break;
////                default : 	r = 204-(int)((normQP/(float)0.8)*yInt_Rec); g = 255; b = 255; // For 64x64
////            }

////			//------------------
////            // YGJ 27th Oct 2014
////            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
////            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
////			switch (yInt_PartSize)
////			{
////				case 4 :  r = 0; g = (int)((normQP/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
////					break;
////				case 8 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normQP-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
////					break;
////				case 16 :  r = (int)(((normQP-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
////					break;
////                case 32 :  r = (int)(((normQP-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
////                    break;
////				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normQP-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
////					break;
////			}
////            //------------------

////            //------------------
////            // YGJ 27th Oct 2014
////            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
////            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
////            switch (yInt_PartSize)
////            {
////                case 4 :  r = 255; g = max(229-(yInt_Rec << 1), 102); b = 240-(int)((normQP/(float)0.8)*yInt_Rec);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
////                    break;
////                case 8 :  r = 255; g = max(255-(yInt_Rec << 1), 229); b = 240-(int)((normQP/(float)0.8)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
////                    break;
////                case 16 :  r = max(255-(yInt_Rec << 1), 102); g = 255; b = 240-(int)((normQP/(float)0.8)*yInt_Rec); // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
////                    break;
////                case 32 : r = 240-(int)((normQP/(float)0.8)*yInt_Rec); g = 255; b = max(255-(yInt_Rec << 1), 102); // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
////                    break;
////                default : 	r = 240-(int)((normQP/(float)0.8)*yInt_Rec); g = max(255-(yInt_Rec << 1), 102); b = 255; // For 64x64
////            }

////            //------------------
////            // YGJ 27th Oct 2014
////            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
////            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
////            switch (yInt_PartSize)
////            {
////                case 4 :  r = 255; g = (int)((normQP/(float)0.8)*yInt_Rec); b = (int)((normQP/(float)0.8)*yInt_Rec);  // Red   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
////                    break;
////                case 8 :  r = 255; g = (int)((normQP/(float)0.55)*yInt_Rec); b = (int)((normQP/(float)0.8)*yInt_Rec); // Orange   // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
////                    break;
////                case 16 :  r = 255; g = 255; b = (int)((normQP/(float)0.8)*yInt_Rec); // Yellow  // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
////                    break;
////                case 32 : r = (int)((normQP/(float)0.8)*yInt_Rec); g = 255; b = (int)((normQP/(float)0.8)*yInt_Rec); // Green   // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
////                    break;
////                default : 	r = (int)((normQP/(float)0.8)*yInt_Rec); g = 255; b = 255; // For 64x64  // Cyan (Sky blue)
////            }
////            //------------------

//            //------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//            switch (yInt_PartSize)
//            {
//                case 4 :  r = 255; g = (int)((normQP/(float)0.95)*yInt_Rec); b = (int)((normQP/(float)0.95)*yInt_Rec);  // Red   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//                    break;
//                case 8 :  r = 255; g = (int)((normQP/(float)0.65)*yInt_Rec); b = (int)((normQP/(float)0.95)*yInt_Rec); // Orange   // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//                    break;
//                case 16 :  r = 255; g = 255; b = (int)((normQP/(float)0.95)*yInt_Rec); // Yellow  // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//                    break;
//                case 32 : r = (int)((normQP/(float)0.95)*yInt_Rec); g = 255; b = (int)((normQP/(float)0.95)*yInt_Rec); // Green   // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//                    break;
//                default : 	r = (int)((normQP/(float)0.95)*yInt_Rec); g = 255; b = 255; // For 64x64  // Cyan (Sky blue)
//            }
//            //------------------

//        }
//        else
//        {
//            r = g = b = yInt_Rec;
//        }


//        // Rec - Org
//        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;

//        // Partitioning
//        if (yInt_Rec == 0 && (x % 2 == 0 || y % 2 == 0))
//        {
//            r = yInt_Rec;
//            g = yInt_Rec;
//            b = yInt_Rec;
//        }

//        imgFrmAsPNG[4 * width * y + 4 * x + 0] = r; //Red
//        imgFrmAsPNG[4 * width * y + 4 * x + 1] = g; //Green
//        imgFrmAsPNG[4 * width * y + 4 * x + 2] = b; //Blue
//        imgFrmAsPNG[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//      }
////      piY += YStride;
//      piY_Org += YStrideOrg;
//      piY_Sig += YStride;
//      piY_Rec += YStride;
//      piY_PartSize += YPartStride;



//      // CShift: 1, 0, -1
//      // 420: 1/4, 422: 1/2, 444: 1
//      if (CShift == 1)
//      {
//        if (y%2 == 0)
//        {
//          piCb_Sig += CStride;
//        }
//      }
//      else if (CShift == 1)
//      {
//        if (y%2 == 0)
//        {
//          piCb_Sig += CStride;
//        }
//      }
//      else if (CShift == -1)
//      {
//          piCb_Sig += CStride;
//      }
//    }

////    free(ptrY_Org);

//    free(ptrY_Sig);
//    free(ptrU_Sig);

//    free(ptrY_Rec);

//    free(ptrY_PartSize);



//      //Encode the image
//      unsigned error = lodepng::encode(FrmAsPNG, imgFrmAsPNG, width, height);

//      //if there's an error, display it
//      if(error) std::cout << "encoder error " << error << ": "<< lodepng_error_text(error) << std::endl;

//      if (m_rawTextData)
//      {
//          //-------------------------
//          // YGJ Wed 27th May 2015
//          // Output vector to txt file
//          // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
//          ofstream DecFrmAsTxt;
//          DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
//          for(int i = 0; i < imgFrmAsTxt.size(); ++i)
//          {
//              if ((i+1)%width==0)
//                  DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
//              else
//                  DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
//          }
//          DecFrmAsTxt.close();
//          //-------------------------
//      }

//    ////---------------------

//}

Void TAppDecTop::saveFrameAsPNG_SADx_NonSq_Only(TComPic* pcPic)
{
  // unsigned height = m_iSourceHeight;
  // unsigned width = m_iSourceWidth;
  // unsigned FrameRes = (height*width);


  unsigned blkwidth = DistWidthSize(m_distWidthSize);
  unsigned blkheight = (blkwidth >> 1);
  unsigned blksz = blkwidth*blkheight;

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);
  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");
  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];
  char strFactor[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);
  
  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);
  
  char strblkwidth[6];
  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);
  
  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile.c_str());
  strcat(SSIMHeatmap, "DecFrm_SAD");    strcat(SSIMHeatmap, strblkwidth);  
  strcat(SSIMHeatmap, "NonSq_OnlyHeatMap_");    
  strcat(SSIMHeatmap, strpoc);   
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);        
  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);  
  strcat(SSIMHeatmap, ".png");

  // YGJ Tues 26th May 2015
  // Store the QP to text file
  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());
  strcat(FrmAsTxt, "DecFrm_SAD");    strcat(FrmAsTxt, strblkwidth);
  strcat(FrmAsTxt, "NonSq_OnlyHeatMap_");
  strcat(FrmAsTxt, strpoc);
  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
  strcat(FrmAsTxt, "_Factor");  strcat(FrmAsTxt, strFactor);
  strcat(FrmAsTxt, ".txt");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);
  // YGJ Thurs 28th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);


  unsigned MaxValue = (1<<bitDepthLuma)-1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;

		int yInt = 0; 

		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

		int yInt_Org = (int)ptrY_Org[yloc]; 
		int yInt_Rec = (int)ptrY_Rec[yloc]; 
		int yInt_Part = (int)ptrY_Part[yloc]; 

		// seems fine here
		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


		bool HadRegion = false;
		Distortion iSumHad =0;

		if ((y < (height-blkheight)) && (x < (width-blkwidth)))
		{
		  HadRegion = true;

		  //int HadDiff[blksz];		  		  
		  // http://www.cplusplus.com/forum/general/40423/
		  int* HadDiff = new int[blksz];
		  
			for ( unsigned n = 0; n < blkheight; n++ )
			{
				for ( unsigned m = 0; m < blkwidth; m++ )
				{
					// y*width + x
					unsigned yloc8x8 = n*blkwidth+m;

					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

					////------------------
					//// YGJ 12th July 2014
					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
					//// a -- set up and initialise variables

					////------------------

					HadDiff[yloc8x8] = y_Org - y_Rec; 
				}
			}

			int i, j; //, jj;//, k;

			for (j = 0; j < blkheight; j++)
			{
			  for (i = 0; i < blkwidth; i++)
			  {
				iSumHad += abs(HadDiff[i+j*blkwidth]); 
			  }
			}

			delete HadDiff;

		}

		yInt = yInt_Rec;

		int r, b, g;


        //-------------------------
        // YGJ Thurs 28th May 2015
        // Store the QP to array

        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) )
            imgFrmAsTxt[width * y + x] = (int)iSumHad;
        else
            imgFrmAsTxt[width * y + x] = -1;
        //-------------------------

		//  APC score will be between 0 and 127.
		// Dependent upon value apply different colour
		if (HadRegion == true)
		{			
			//------------------

			// Using arrays as look up tables to ensure values set are consistent
			int loc = (int)log2((double)blkwidth) - 3;
			
			int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
			float maxScaled = (float)((float)maxUnscaled * (0.1024));
			float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

			Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

			// For Non-Sq
			halfMaxThreshold >>= 1; // Half

			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;
									
//			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//				printf("SAD %d NonSq is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
			float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = ((double)normHad) > 1.0? (float)1.0 : normHad;

            int val =  ((double)normHad) < 0.25? 0 :
                       ((double)normHad) < 0.5? 1 :
                       ((double)normHad) < 0.75? 2 : 3;
			

			//------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
			switch (val)
			{
				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
					break;
				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
					break;
				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
					break;				
				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
					break;
			}
            //------------------

		}
		else
		{
			r = yInt; 
			g = yInt; 
			b = yInt; 
		}


		// Rec - Org
		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


		// Partitioning -- Not Working
		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
		{
		  r = 0; //yInt_RmO;
		  g = 0; //yInt_RmO;
		  b = 0; //yInt_RmO;
		}

		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  
	  piY_Org += YStride;
	  piY_Rec += YStrideRec;
	  piY_Part += YStrideRec;
      
	}


	free(ptrY_Org8x8);
	free(ptrY_Rec8x8);

	free(ptrY_Org);

	free(ptrY_Rec);

	free(ptrY_Part);


	//-----------------------

	if(m_outputSSIMHeatmaps)
	{
	  std::vector<unsigned char> png;

	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

	  //if there's an error, display it
	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
	}

   //-----------------------

    if (m_rawTextData)
    {
        //-------------------------
        // YGJ Thurs 28th May 2015
        // Output vector to txt file
        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
        ofstream DecFrmAsTxt;
        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
        {
            if ((i+1)%width==0)
                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
            else
                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
        }
        DecFrmAsTxt.close();
        //-------------------------
    }
}

Void TAppDecTop::saveFrameAsPNG_SSEx_Only(TComPic* pcPic)
{

  // unsigned height = m_iSourceHeight;
  // unsigned width = m_iSourceWidth;
  // unsigned FrameRes = (height*width);

  unsigned blkwidth = DistWidthSize(m_distWidthSize);
  unsigned blksz = blkwidth*blkwidth;

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);
  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    // YGJ 16th March 2015 - Block size can vary in SSE version.

    int shiftby = (int)log2(blkwidth);
    int downscaleby = (int)log2(blksz);

    Distortion *ptrDist_SSE;   ptrDist_SSE = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_SSE == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strRange, sizeof(strRange), "%d", m_distRange);

  char strblkwidth[6];
  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile.c_str());
  strcat(SSIMHeatmap, "DecFrm_SSE");  strcat(SSIMHeatmap, strblkwidth); 
  strcat(SSIMHeatmap, "_OnlyHeatMap_");    
  strcat(SSIMHeatmap, strpoc);        
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);    
  strcat(SSIMHeatmap, ".png");

  // YGJ Tues 26th May 2015
  // Store the QP to text file
  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());
  strcat(FrmAsTxt, "DecFrm_SSE");      strcat(FrmAsTxt, strblkwidth);
  strcat(FrmAsTxt, "_OnlyHeatMap_");
  strcat(FrmAsTxt, strpoc);
  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
  strcat(FrmAsTxt, ".txt");


  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);
  // YGJ Thurs 28th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);


  unsigned MaxValue = (1<<bitDepthLuma)-1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;

		// allocate YUV value
		int yInt = 0; //, uInt = 0, vInt = 0;

		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

		int yInt_Org = (int)ptrY_Org[yloc];  
		int yInt_Rec = (int)ptrY_Rec[yloc]; 
		int yInt_Part = (int)ptrY_Part[yloc]; 

		// seems fine here
		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


		bool SSERegion = false;
		Distortion iSumHad =0;

        

        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        //if ((y < (height-blkwidth)) && (x < (width-blkwidth)) && ((y % blkwidth == 0) && (x % blkwidth == 0)))
        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) )
		{
		  SSERegion = true;

		  //int SSEDiff[blksz];
		  // http://www.cplusplus.com/forum/general/40423/
		  int* SSEDiff = new int[blksz];
		  
			//for ( unsigned n = 0; n < blkwidth; n++ )
			//{
			//	for ( unsigned m = 0; m < blkwidth; m++ )
			//	{

                    unsigned n = 0, m = 0;
					// y*width + x
					unsigned yloc8x8 = n*blkwidth+m;

					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

					////------------------
					//// YGJ 12th July 2014
					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
					//// a -- set up and initialise variables

					////------------------

					int Temp = y_Org - y_Rec;

					SSEDiff[yloc8x8] = shift == 0? LumaSq_LUT[abs(Temp)] : Temp*Temp;
                    imgFrmAsTxt[width * y + x] = ( (int)(SSEDiff[yloc8x8]));

			//	}
			//}

			int i, j; 

			for (i = 0; i < blkwidth; i++)
			{
			  for (j = 0; j < blkwidth; j++)
			  {
				iSumHad += abs(SSEDiff[i+j*blkwidth]); 
			  }
			}

            ptrDist_SSE[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = iSumHad;

			delete SSEDiff;

		}
        else if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
        {
            SSERegion = true;

            iSumHad = ptrDist_SSE[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
        }

		yInt = yInt_Rec;
		
        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) )
        {
            //imgFrmAsTxt[width * y + x] = (int)iSumHad;
        }
        else
            imgFrmAsTxt[width * y + x] = -1;
        //-------------------------

//
		int r, b, g;

		//  APC score will be between 0 and 127.
		// Dependent upon value apply different colour
		if (SSERegion == true)
		{

			//------------------------------
			// YGJ 28th Sept 2014 - Instead of 1/2 max, here it is 1/(2^2), 1/4 Max
			// Correction 1/16. This will reduce the dynamic range.
			// However, the banding is log scale, doubling each time (bit like Fibbannaci sequence)
			// Then the intensity is scaled lineary, within these non-linear sized bands

			int loc = (int)log2((double)blkwidth) - 3;

			int maxUnscaled = (maxLimitSSE_k[loc] * NormDist_OneMin10k[m_distRange]);
			float maxScaled = (float)((float)maxUnscaled * (0.1024));

			Distortion halfMaxThreshold = (Distortion)maxScaled;

			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;
									
//			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//				printf("SSE %d is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
			float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = ((double)normHad) > 1.0? (float)1.0 : normHad;

            int val =  ((double)normHad) < 0.25? 0 :
                       ((double)normHad) < 0.5? 1 :
                       ((double)normHad) < 0.75? 2 : 3;

			//------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
			switch (val)
			{
				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
					break;
				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
					break;
				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
					break;				
				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
					break;
			}
            //------------------

		}
		else
		{
			r = yInt; 
			g = yInt; 
			b = yInt; 
		}


		// Rec - Org
		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


		// Partitioning -- Not Working
		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
		{
		  r = 0; 
		  g = 0; 
		  b = 0; 
		}

		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  //piY += YStride;
	  piY_Org += YStride;
	  piY_Rec += YStrideRec;
	  piY_Part += YStrideRec;

	}


	free(ptrY_Org8x8);
	free(ptrY_Rec8x8);

	free(ptrY_Org);

	free(ptrY_Rec);

	free(ptrY_Part);


	//-----------------------

	if(m_outputSSIMHeatmaps)
	{
	  std::vector<unsigned char> png;

	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

	  //if there's an error, display it
	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
	}

   //-----------------------

    if (m_rawTextData)
    {
        //-------------------------
        // YGJ Thurs 28th May 2015
        // Output vector to txt file
        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
        ofstream DecFrmAsTxt;
        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
        {
            if ((i+1)%width==0)
                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
            else
                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
        }
        DecFrmAsTxt.close();
        //-------------------------
    }

}

// No need same output as QP version - QP version much simplier to understand
//// YGJ 28th June 2015 - SAD per pixel with block size coloured
//// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel) -- Working
//Void TAppDecTop::saveFrameAsPNGPartwSSEwBlkHighlight(TComPic* pcPic)
//{

//  // unsigned height = m_iSourceHeight;
//  // unsigned width = m_iSourceWidth;
//  // unsigned FrameRes = (height*width);

//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec = pcPic->getPicYuvWPart();
//  TComPicYuv* imageSig = pcPic->getPicYuvWQPPart();
//  TComPicYuv* imagePartSize = pcPic->getPicYuvWPartSize();

//  int pcPOC = pcPic->getPOC(); // Decode order from reading from YUV file.

//  int poc = pcPOC; // For Test purpose override poc with correct poc for decoded stream

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Sig   = imageSig->getAddr(COMPONENT_Y);
//  Pel*  piCb_Sig  = imageSig->getAddr(COMPONENT_Cb);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_PartSize   = imagePartSize->getAddr(COMPONENT_Y);

//  unsigned YStrideOrg = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStride = imageRec->getStride(COMPONENT_Y);
//  unsigned CStride = imageRec->getStride(COMPONENT_Cb);

//  unsigned YPartStride = imagePartSize->getStride(COMPONENT_Y);


//  // 420: 1:1/4:1/4, Then Y:UV = 2xY:1xChr => CShift = 1
//  // 422: 1:1/2:1/2, Then Y:UV = 2xY:2xChr => CShift = 0
//  // 444: 1:1:1, Then Y:UV = 2xY:4xChr => CShift = -1
//    int CShift = (YStride == (CStride<<1))? 1
//        : YStride == CStride? 0 : -1;

//   // 420: 1/4, 422: 1/2, 444: 1
//   unsigned ChrFrmRes = CShift == 1? QuartFrameRes
//       : CShift == 0? HalfFrameRes : FrameRes;

//  // Allocate memory for output frame

//  //// Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  Pel *ptrY_Sig;   ptrY_Sig = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Sig == NULL)   printf("calloc failed\n");
//  Pel *ptrU_Sig;   ptrU_Sig = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Sig == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Allocate memory to store partition size value
//  Pel *ptrY_PartSize;   ptrY_PartSize = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_PartSize == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  char strpoc[6];

//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);

// char FrmAsPNG[255];  strcpy(FrmAsPNG, m_pchSSIMLogAndImageFile);  strcat(FrmAsPNG, "DecFrm_PartwSSEwHighlight_");    strcat(FrmAsPNG, strpoc);        strcat(FrmAsPNG, ".png");

//  // YGJ Tues 26th May 2015
//  // Store the QP to text file
//  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile);  strcat(FrmAsTxt, "DecFrm_PartwSSEwHighlight_");    strcat(FrmAsTxt, strpoc);        strcat(FrmAsTxt, ".txt");

//  std::vector<unsigned char> imgFrmAsPNG; imgFrmAsPNG.resize(FourTimesFrameRes);
//  // YGJ Wed 27th May 2015
//  // Store the QP to array
//  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

//  unsigned MaxValue = (1<<bitDepthLuma)-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
//    Int   shiftc = bitDepthChroma-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

//int prevCloc = 0; // Previous cloc

//    for ( unsigned y = 0; y < height; y++ )
//    {
//      for ( unsigned x = 0; x < width; x++ )
//      {
//        unsigned yloc = y*width+x;
//        unsigned cloc = prevCloc;

//        // CShift: 1, 0, -1
//        // 420: 1/4, 422: 1/2, 444: 1
//        if (CShift == 1)
//        {
//          if (x%2 == 0)
//            cloc = (y >> 2) * (width >> 2) + (x >> 2);
//        }
//        else if (CShift == 1)
//        {
//          if (x%2 == 0)
//            cloc = (y >> 1) * (width >> 1) + (x >> 1);
//        }
//        else if (CShift == -1)
//          cloc = yloc;

//        prevCloc = cloc;

//        // allocate YUV value

//        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);

//        // Y_Sig contains QP and U_Sig contains skipped_flag

//        ptrY_Sig[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Sig[x]+offset)>>shift);
//        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);

//        // This links the signalling value in stream to a local array
//        // Gather current parition size
//        ptrY_PartSize[yloc]  = Clip3<Pel>(0, MaxValue, (piY_PartSize[x]+offset)>>shift);

//        int yInt_Org = (int)ptrY_Org[yloc];

//        int yInt_Sig = (int)ptrY_Sig[yloc];  int  uInt_Sig = (int)ptrU_Sig[cloc];
//        int yInt_Rec = (int)ptrY_Rec[yloc];

//        // Take current value parition size:
//        int yInt_PartSize = (int)ptrY_PartSize[yloc];

//        int yInt_diff = (yInt_Org - yInt_Rec);
//        yInt_diff = pow(yInt_diff,2);

//        //-------------------------
//        imgFrmAsTxt[width * y + x] = yInt_Sig; //-1;
//        //-------------------------

//        if ((x% CShift) == 0)
//        {
//          unsigned cx = (x >> CShift);

//          ptrU_Sig[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Sig[cx]+offsetc)>>shiftc);

//          uInt_Sig = (int)ptrU_Sig[cloc];

//        }
//        else
//        {
//          uInt_Sig = (int)ptrU_Sig[cloc];
//        }

//        // Rec - Org
//        int r = 0;
//        int g = 0;
//        int b = 0;


////        int val = yInt_Sig < 13 ? 0 : yInt_Sig < 26 ? 1 : yInt_Sig < 39 ? 2 : 3;

//        // Normalise Had against assumed max.
//        //float normQP = ((float)yInt_Sig)/51;
//        //float normQP = ((float)yInt_diff)/255;
//        float normQP = ((float)yInt_diff)/65025; // 255^2
//        // But need to it to be upto 40%
//        normQP = 1 - (normQP*0.4);

//        if ( uInt_Sig == 0 ) // Skipped Flag is zero
//        {

////            //------------------
////            // YGJ 27th Oct 2014
////            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
////            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
////            switch (yInt_PartSize)
////            {
////                case 4 :  r = 255; g = 204-(int)(normQP*yInt_Rec); b = 204-(int)(normQP*yInt_Rec);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
////                    break;
////                case 8 :  r = 255; g = 229-(int)(normQP*yInt_Rec); b = 204-(int)(normQP*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
////                    break;
////                case 16 :  r = 255; g = 255; b = 204-(int)(normQP*yInt_Rec); // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
////                    break;
////                case 32 : r = 204-(int)(normQP*yInt_Rec); g = 255; b = 204-(int)(normQP*yInt_Rec); // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
////                    break;
////                default : 	r = 204-(int)(normQP*yInt_Rec); g = 255; b = 255; // For 64x64
////            }

////            //------------------
////            // YGJ 27th Oct 2014
////            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
////            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
////            switch (yInt_PartSize)
////            {
////                case 4 :  r = 255; g = 204-(int)((normQP/(float)0.8)*yInt_Rec); b = 204-(int)((normQP/(float)0.8)*yInt_Rec);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
////                    break;
////                case 8 :  r = 255; g = 229-(int)((normQP/(float)0.8)*yInt_Rec); b = 204-(int)((normQP/(float)0.8)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
////                    break;
////                case 16 :  r = 255; g = 255; b = 204-(int)((normQP/(float)0.8)*yInt_Rec); // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
////                    break;
////                case 32 : r = 204-(int)((normQP/(float)0.8)*yInt_Rec); g = 255; b = 204-(int)((normQP/(float)0.8)*yInt_Rec); // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
////                    break;
////                default : 	r = 204-(int)((normQP/(float)0.8)*yInt_Rec); g = 255; b = 255; // For 64x64
////            }

////			//------------------
////            // YGJ 27th Oct 2014
////            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
////            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
////			switch (yInt_PartSize)
////			{
////				case 4 :  r = 0; g = (int)((normQP/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
////					break;
////				case 8 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normQP-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
////					break;
////				case 16 :  r = (int)(((normQP-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
////					break;
////                case 32 :  r = (int)(((normQP-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
////                    break;
////				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normQP-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
////					break;
////			}
////            //------------------

////            //------------------
////            // YGJ 27th Oct 2014
////            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
////            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
////            switch (yInt_PartSize)
////            {
////                case 4 :  r = 255; g = max(229-(yInt_Rec << 1), 102); b = 240-(int)((normQP/(float)0.8)*yInt_Rec);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
////                    break;
////                case 8 :  r = 255; g = max(255-(yInt_Rec << 1), 229); b = 240-(int)((normQP/(float)0.8)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
////                    break;
////                case 16 :  r = max(255-(yInt_Rec << 1), 102); g = 255; b = 240-(int)((normQP/(float)0.8)*yInt_Rec); // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
////                    break;
////                case 32 : r = 240-(int)((normQP/(float)0.8)*yInt_Rec); g = 255; b = max(255-(yInt_Rec << 1), 102); // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
////                    break;
////                default : 	r = 240-(int)((normQP/(float)0.8)*yInt_Rec); g = max(255-(yInt_Rec << 1), 102); b = 255; // For 64x64
////            }

////            //------------------
////            // YGJ 27th Oct 2014
////            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
////            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
////            switch (yInt_PartSize)
////            {
////                case 4 :  r = 255; g = (int)((normQP/(float)0.8)*yInt_Rec); b = (int)((normQP/(float)0.8)*yInt_Rec);  // Red   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
////                    break;
////                case 8 :  r = 255; g = (int)((normQP/(float)0.55)*yInt_Rec); b = (int)((normQP/(float)0.8)*yInt_Rec); // Orange   // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
////                    break;
////                case 16 :  r = 255; g = 255; b = (int)((normQP/(float)0.8)*yInt_Rec); // Yellow  // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
////                    break;
////                case 32 : r = (int)((normQP/(float)0.8)*yInt_Rec); g = 255; b = (int)((normQP/(float)0.8)*yInt_Rec); // Green   // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
////                    break;
////                default : 	r = (int)((normQP/(float)0.8)*yInt_Rec); g = 255; b = 255; // For 64x64  // Cyan (Sky blue)
////            }
////            //------------------

//            //------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//            switch (yInt_PartSize)
//            {
//                case 4 :  r = 255; g = (int)((normQP/(float)0.95)*yInt_Rec); b = (int)((normQP/(float)0.95)*yInt_Rec);  // Red   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//                    break;
//                case 8 :  r = 255; g = (int)((normQP/(float)0.65)*yInt_Rec); b = (int)((normQP/(float)0.95)*yInt_Rec); // Orange   // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//                    break;
//                case 16 :  r = 255; g = 255; b = (int)((normQP/(float)0.95)*yInt_Rec); // Yellow  // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//                    break;
//                case 32 : r = (int)((normQP/(float)0.95)*yInt_Rec); g = 255; b = (int)((normQP/(float)0.95)*yInt_Rec); // Green   // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//                    break;
//                default : 	r = (int)((normQP/(float)0.95)*yInt_Rec); g = 255; b = 255; // For 64x64  // Cyan (Sky blue)
//            }
//            //------------------

//        }
//        else
//        {
//            r = g = b = yInt_Rec;
//        }


//        // Rec - Org
//        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;

//        // Partitioning
//        if (yInt_Rec == 0 && (x % 2 == 0 || y % 2 == 0))
//        {
//            r = yInt_Rec;
//            g = yInt_Rec;
//            b = yInt_Rec;
//        }

//        imgFrmAsPNG[4 * width * y + 4 * x + 0] = r; //Red
//        imgFrmAsPNG[4 * width * y + 4 * x + 1] = g; //Green
//        imgFrmAsPNG[4 * width * y + 4 * x + 2] = b; //Blue
//        imgFrmAsPNG[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//      }
////      piY += YStride;
//      piY_Org += YStrideOrg;
//      piY_Sig += YStride;
//      piY_Rec += YStride;
//      piY_PartSize += YPartStride;



//      // CShift: 1, 0, -1
//      // 420: 1/4, 422: 1/2, 444: 1
//      if (CShift == 1)
//      {
//        if (y%2 == 0)
//        {
//          piCb_Sig += CStride;
//        }
//      }
//      else if (CShift == 1)
//      {
//        if (y%2 == 0)
//        {
//          piCb_Sig += CStride;
//        }
//      }
//      else if (CShift == -1)
//      {
//          piCb_Sig += CStride;
//      }
//    }

////    free(ptrY_Org);

//    free(ptrY_Sig);
//    free(ptrU_Sig);

//    free(ptrY_Rec);

//    free(ptrY_PartSize);



//      //Encode the image
//      unsigned error = lodepng::encode(FrmAsPNG, imgFrmAsPNG, width, height);

//      //if there's an error, display it
//      if(error) std::cout << "encoder error " << error << ": "<< lodepng_error_text(error) << std::endl;

//      if (m_rawTextData)
//      {
//          //-------------------------
//          // YGJ Wed 27th May 2015
//          // Output vector to txt file
//          // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
//          ofstream DecFrmAsTxt;
//          DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
//          for(int i = 0; i < imgFrmAsTxt.size(); ++i)
//          {
//              if ((i+1)%width==0)
//                  DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
//              else
//                  DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
//          }
//          DecFrmAsTxt.close();
//          //-------------------------
//      }

//    ////---------------------


//}

//=========================================
//=========================================
// Proposed Methods shown as Heatmaps
//=========================================
//=========================================





//Void TAppDecTop::saveFrameAsPNG_AlwaysTrue_SADx_PreAssess_wCornerTest_APC(TComPic* pcPic)
//{

//  // unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
//  // unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
//  // unsigned FrameRes = (height*width);


//  unsigned blkwidth = DistWidthSize(m_distWidthSize);
//  unsigned blksz = blkwidth*blkwidth;

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");
//    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
//    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
//    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
//    // YGJ 16th March 2015 - Block size can vary in SSE version.

//    int shiftby = (int)log2(blkwidth);
//    int downscaleby = (int)log2(blksz);

//    Distortion *ptrDist_iSumHad;   ptrDist_iSumHad = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_iSumHad == NULL)   printf("calloc failed\n");
//    Distortion *ptrDist_iSumHadAPC;   ptrDist_iSumHadAPC = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_iSumHadAPC == NULL)   printf("calloc failed\n");
//    bool *ptrbool_ProceedwAPC;   ptrbool_ProceedwAPC = (bool *)calloc((FrameRes >> downscaleby), sizeof(bool));    if (ptrbool_ProceedwAPC == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.
  
//  char strpoc[6];
//  char strRange[8];
//  char strFactor[8];


//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);


//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  char strblkwidth[6];
//  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

  
//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_AlwaysTrue_SAD");    strcat(SSIMHeatmap, strblkwidth);
  
//  strcat(SSIMHeatmap, "_PreAssess_wCornerTest_APCHeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  // YGJ Tues 26th May 2015
//  // Store the QP to text file
//  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile);
//  strcat(FrmAsTxt, "DecFrm_AlwaysTrue_SAD");    strcat(FrmAsTxt, strblkwidth);
//  strcat(FrmAsTxt, "_PreAssess_wCornerTest_APCHeatMap_");
//  strcat(FrmAsTxt, strpoc);
//  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
//  strcat(FrmAsTxt, "_Factor");  strcat(FrmAsTxt, strFactor);
//  strcat(FrmAsTxt, ".txt");


//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);
//  // YGJ Thurs 28th May 2015
//  // Store the QP to array
//  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

//  unsigned MaxValue = (1<<bitDepthLuma)-1;
//  Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;


//  UInt Threshold = APCCrossCornSubThresh;
//  // YGJ 4th May 2015 - Four test corner test points used.
//  UInt AbsAsymCost = 0;


//    for ( unsigned y = 0; y < height; y++ )
//    {
//      for ( unsigned x = 0; x < width; x++ )
//      {
//        unsigned yloc = y*width+x;

//        // allocate YUV value
//        int yInt = 0;

//        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//        int yInt_Org = (int)ptrY_Org[yloc];
//        int yInt_Rec = (int)ptrY_Rec[yloc];
//        int yInt_Part = (int)ptrY_Part[yloc];

//        // seems fine here
//        if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
//        //if (yInt_Org > MaxValue || yInt_Org < 0 || yInt_Rec > MaxValue || yInt_Rec < 0)
//            printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

//        //bool HadRegion = false;
//        Distortion iSumHad =0;
//        Distortion iSumHadAPC =0;
//        bool ProceedwAPC = false;

//        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
//        // YGJ 5th Jan 2014 - Every 8x8 block
//        //if ((y < (height-blkwidth)) && (x < (width-blkwidth)) && ((y % blkwidth == 0) && (x % blkwidth == 0)))
//        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) )
//        {
//          // http://www.cplusplus.com/forum/general/40423/
//          int* HadDiff = new int[blksz];

//          //Int APC[blksz]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
//          // http://www.cplusplus.com/forum/general/40423/
//          int* APC = new int[blksz];

//            //for ( unsigned n = 0; n < blkwidth; n++ )
//            //{
//            //    for ( unsigned m = 0; m < blkwidth; m++ )
//            //    {

//                    unsigned n = 0, m = 0;
//                    // y*width + x
//                    unsigned yloc8x8 = n*blkwidth+m;

//                    Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//                    Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//                    ////------------------
//                    //// YGJ 12th July 2014
//                    //// Please note here the encoder assumes current/reconstructed block is `all zero block'
//                    //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//                    //// a -- set up and initialise variables
//                    ////------------------

//                    HadDiff[yloc8x8] = y_Org - y_Rec;
//                    APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0);
//                    imgFrmAsTxt[width * y + x] =  abs(APC[yloc8x8]); //((int)(iSumHadAPC >> APC_Downscale));

//            //    }
//            //}

//            int i, j;
            
//            AbsAsymCost = abs((APC[0]-APC[(blkwidth*blkwidth)-1])-(APC[(blkwidth-1)]-APC[(blkwidth*blkwidth)-blkwidth])); // Less test points to estimate distortion perceptual variance

//            ProceedwAPC = true; //AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained


//            for (i = 0; i < blkwidth; i++)
//            {
//              for (j = 0; j < blkwidth; j++)
//              {
//                     iSumHad += abs(HadDiff[i+j*blkwidth]);
//                     iSumHadAPC += abs(APC[i+j*blkwidth]);
//              }
//            }


//            ptrDist_iSumHad[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = iSumHad;
//            ptrDist_iSumHadAPC[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = iSumHadAPC;
//            ptrbool_ProceedwAPC[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = ProceedwAPC;

//            delete HadDiff;
//            delete APC;

//            //printf("SAD %d x %d, ACCS Threshold, %d, AbsAsymCost, %d, iSumHad, %d, iSumHadAPC, %d \n", blkwidth, blkwidth, Threshold, AbsAsymCost, iSumHad, iSumHadAPC);

//        }
//        else if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
//        {
//            iSumHad = ptrDist_iSumHad[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
//            iSumHadAPC = ptrDist_iSumHadAPC[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
//            ProceedwAPC = ptrbool_ProceedwAPC[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
//        }

//        yInt = yInt_Rec;

//        int r, b, g;

//        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) )
//        {
//            //if (ProceedwAPC == true)
//            //    //imgFrmAsTxt[width * y + x] = ((int)iSumHad+ (int)(iSumHadAPC >> APC_Downscale));
//            //    imgFrmAsTxt[width * y + x] = ((int)(iSumHadAPC >> APC_Downscale));
//            //else
//            //    imgFrmAsTxt[width * y + x] = (int)iSumHad;
//        }
//        else
//            imgFrmAsTxt[width * y + x] = -1;
//        //-------------------------

//        if (ProceedwAPC == true)
//        {

//            //------------------

//            // Using arrays as look up tables to ensure values set are consistent
//            int loc = (int)log2((double)blkwidth) - 3;

//            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
//            float maxScaled = (float)((float)maxUnscaled * (0.1024));
//            float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

//            Distortion halfMaxThreshold = (Distortion)maxCommonFactor;
//            iSumHadAPC = iSumHadAPC >> APC_Downscale ; // fixed scale for APC

//            //iSumHad += iSumHadAPC;
//            iSumHad = iSumHadAPC;

//            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;


////            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
////                printf("PreAssess SAD %d with APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
////                blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);

//            float normHad = ((float)dist)/((float)halfMaxThreshold);

//            // YGJ 15th March 2015
//            // Use 1/2 max based normalised value
//            // Based on normJND

//            normHad = ((double)normHad) > 1.0? 1.0 : normHad;

//            int val =  ((double)normHad) < 0.25? 0 :
//                       ((double)normHad) < 0.5? 1 :
//                       ((double)normHad) < 0.75? 2 : 3;

//            //------------------


//            //------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//            switch (val)
//            {
//                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//                    break;
//                case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//                    break;
//                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//                    break;
//                default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//                    break;
//            }
//            //------------------

//        }
//        else
//        {
//            r = yInt;
//            g = yInt;
//            b = yInt;
//        }


//        // Rec - Org
//        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//        // Partitioning -- Not Working
//        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//        {
//          r = 0;
//          g = 0;
//          b = 0;
//        }

//        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//      }
//      //piY += YStride;
//      piY_Org += YStride;
//      piY_Rec += YStrideRec;
//      piY_Part += YStrideRec;

//    }

//    free(ptrY_Org8x8);
//    free(ptrY_Rec8x8);

//    free(ptrY_Org);

//    free(ptrY_Rec);

//    free(ptrY_Part);


//    //-----------------------

//    if(m_outputSSIMHeatmaps)
//    {
//      std::vector<unsigned char> png;

//      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//      //if there's an error, display it
//      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//    }

//   //-----------------------

//    if (m_rawTextData)
//    {
//        //-------------------------
//        // YGJ Thurs 28th May 2015
//        // Output vector to txt file
//        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
//        ofstream DecFrmAsTxt;
//        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
//        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
//        {
//            if ((i+1)%width==0)
//                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
//            else
//                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
//        }
//        DecFrmAsTxt.close();
//        //-------------------------
//    }

//}





Void TAppDecTop::saveFrameAsPNG_SADx_PreAssess_wCornerTest_APC(TComPic* pcPic)
{

  // unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
  // unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
  // unsigned FrameRes = (height*width);


  unsigned blkwidth = DistWidthSize(m_distWidthSize);
  unsigned blksz = blkwidth*blkwidth;

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");
    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    // YGJ 16th March 2015 - Block size can vary in SSE version.

    int shiftby = (int)log2(blkwidth);
    int downscaleby = (int)log2(blksz);

    Distortion *ptrDist_iSumHad;   ptrDist_iSumHad = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_iSumHad == NULL)   printf("calloc failed\n");
    Distortion *ptrDist_iSumHadAPC;   ptrDist_iSumHadAPC = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_iSumHadAPC == NULL)   printf("calloc failed\n");
    bool *ptrbool_ProceedwAPC;   ptrbool_ProceedwAPC = (bool *)calloc((FrameRes >> downscaleby), sizeof(bool));    if (ptrbool_ProceedwAPC == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.
  
  char strpoc[6];
  char strRange[8];
  char strFactor[8];


  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);


  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  char strblkwidth[6];
  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

  
  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile.c_str());
  strcat(SSIMHeatmap, "DecFrm_SAD");    strcat(SSIMHeatmap, strblkwidth);
  
  strcat(SSIMHeatmap, "_PreAssess_wCornerTest_APCHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
  strcat(SSIMHeatmap, ".png");

  // YGJ Tues 26th May 2015
  // Store the QP to text file
  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());
  strcat(FrmAsTxt, "DecFrm_SAD");    strcat(FrmAsTxt, strblkwidth);
  strcat(FrmAsTxt, strpoc);
  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
  strcat(FrmAsTxt, "_Factor");  strcat(FrmAsTxt, strFactor);
  strcat(FrmAsTxt, ".txt");


  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);
  // YGJ Thurs 28th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

  unsigned MaxValue = (1<<bitDepthLuma)-1;
  Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;


  UInt Threshold = APCCrossCornSubThresh;
  // YGJ 4th May 2015 - Four test corner test points used.
  UInt AbsAsymCost = 0; 


    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;

        // allocate YUV value
        int yInt = 0; 

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc];  
        int yInt_Rec = (int)ptrY_Rec[yloc];  
        int yInt_Part = (int)ptrY_Part[yloc]; 

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
        //if (yInt_Org > MaxValue || yInt_Org < 0 || yInt_Rec > MaxValue || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

        //bool HadRegion = false;
        Distortion iSumHad =0;
        Distortion iSumHadAPC =0;
        bool ProceedwAPC = false;

        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) && ((y % blkwidth == 0) && (x % blkwidth == 0)))
        {
          // http://www.cplusplus.com/forum/general/40423/
          int* HadDiff = new int[blksz];

          //Int APC[blksz]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
          // http://www.cplusplus.com/forum/general/40423/
          int* APC = new int[blksz];

            for ( unsigned n = 0; n < blkwidth; n++ )
            {
                for ( unsigned m = 0; m < blkwidth; m++ )
                {
                    // y*width + x
                    unsigned yloc8x8 = n*blkwidth+m;

                    Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
                    Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

                    ////------------------
                    //// YGJ 12th July 2014
                    //// Please note here the encoder assumes current/reconstructed block is `all zero block'
                    //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
                    //// a -- set up and initialise variables
                    ////------------------

                    HadDiff[yloc8x8] = y_Org - y_Rec; 
                    APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0);

                }
            }

            int i, j; 
            
            AbsAsymCost = abs((APC[0]-APC[(blkwidth*blkwidth)-1])-(APC[(blkwidth-1)]-APC[(blkwidth*blkwidth)-blkwidth])); // Less test points to estimate distortion perceptual variance

            ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained


            for (i = 0; i < blkwidth; i++)
            {
              for (j = 0; j < blkwidth; j++)
              {
                     iSumHad += abs(HadDiff[i+j*blkwidth]);
                     iSumHadAPC += abs(APC[i+j*blkwidth]);
              }
            }


            ptrDist_iSumHad[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = iSumHad;
            ptrDist_iSumHadAPC[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = iSumHadAPC;
            ptrbool_ProceedwAPC[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = ProceedwAPC;

            delete HadDiff;
            delete APC;

            //printf("SAD %d x %d, ACCS Threshold, %d, AbsAsymCost, %d, iSumHad, %d, iSumHadAPC, %d \n", blkwidth, blkwidth, Threshold, AbsAsymCost, iSumHad, iSumHadAPC);

        }
        else if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
        {
            iSumHad = ptrDist_iSumHad[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
            iSumHadAPC = ptrDist_iSumHadAPC[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
            ProceedwAPC = ptrbool_ProceedwAPC[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
        }

        yInt = yInt_Rec;

        int r, b, g;

        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) )
        {
            if (ProceedwAPC == true)
                imgFrmAsTxt[width * y + x] = ((int)iSumHad+ (int)(iSumHadAPC >> APC_Downscale));
            else
                imgFrmAsTxt[width * y + x] = (int)iSumHad;
        }
        else
            imgFrmAsTxt[width * y + x] = -1;
        //-------------------------

        if (ProceedwAPC == true)
        {

            //------------------

            // Using arrays as look up tables to ensure values set are consistent
            int loc = (int)log2((double)blkwidth) - 3;

            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
            float maxScaled = (float)((float)maxUnscaled * (0.1024));
            float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

            Distortion halfMaxThreshold = (Distortion)maxCommonFactor;
            iSumHadAPC = iSumHadAPC >> APC_Downscale ; // fixed scale for APC

            iSumHad += iSumHadAPC;

            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;


//            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//                printf("PreAssess SAD %d with APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//                blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);

            float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = ((double)normHad) > 1.0? (float)1.0 : normHad;

            int val =  ((double)normHad) < 0.25? 0 :
                       ((double)normHad) < 0.5? 1 :
                       ((double)normHad) < 0.75? 2 : 3;

            //------------------


            //------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
            switch (val)
            {
                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                    break;
                case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                    break;
                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                    break;
                default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                    break;
            }
            //------------------

        }
        else
        {
            r = yInt; 
            g = yInt; 
            b = yInt; 
        }


        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


        // Partitioning -- Not Working
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; 
          g = 0; 
          b = 0; 
        }

        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      //piY += YStride;
      piY_Org += YStride;
      piY_Rec += YStrideRec;
      piY_Part += YStrideRec;

    }

    free(ptrY_Org8x8);
    free(ptrY_Rec8x8);

    free(ptrY_Org);

    free(ptrY_Rec);

    free(ptrY_Part);


    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

    if (m_rawTextData)
    {
        //-------------------------
        // YGJ Thurs 28th May 2015
        // Output vector to txt file
        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
        ofstream DecFrmAsTxt;
        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
        {
            if ((i+1)%width==0)
                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
            else
                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
        }
        DecFrmAsTxt.close();
        //-------------------------
    }

}



//// YGJ 28th June 2015 - SAD per pixel with block size coloured
//// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel) -- Working
//Void TAppDecTop::saveFrameAsPNGPartwSADwAPCwBlkHighlight(TComPic* pcPic)
//{

//  // unsigned height = m_iSourceHeight;
//  // unsigned width = m_iSourceWidth;
//  // unsigned FrameRes = (height*width);

//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec = pcPic->getPicYuvWPart();
//  TComPicYuv* imageSig = pcPic->getPicYuvWQPPart();
//  TComPicYuv* imagePartSize = pcPic->getPicYuvWPartSize();

//  int pcPOC = pcPic->getPOC(); // Decode order from reading from YUV file.

//  int poc = pcPOC; // For Test purpose override poc with correct poc for decoded stream

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Sig   = imageSig->getAddr(COMPONENT_Y);
//  Pel*  piCb_Sig  = imageSig->getAddr(COMPONENT_Cb);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_PartSize   = imagePartSize->getAddr(COMPONENT_Y);

//  unsigned YStrideOrg = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStride = imageRec->getStride(COMPONENT_Y);
//  unsigned CStride = imageRec->getStride(COMPONENT_Cb);

//  unsigned YPartStride = imagePartSize->getStride(COMPONENT_Y);


//  // 420: 1:1/4:1/4, Then Y:UV = 2xY:1xChr => CShift = 1
//  // 422: 1:1/2:1/2, Then Y:UV = 2xY:2xChr => CShift = 0
//  // 444: 1:1:1, Then Y:UV = 2xY:4xChr => CShift = -1
//    int CShift = (YStride == (CStride<<1))? 1
//        : YStride == CStride? 0 : -1;

//   // 420: 1/4, 422: 1/2, 444: 1
//   unsigned ChrFrmRes = CShift == 1? QuartFrameRes
//       : CShift == 0? HalfFrameRes : FrameRes;

//  // Allocate memory for output frame

//  //// Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  Pel *ptrY_Sig;   ptrY_Sig = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Sig == NULL)   printf("calloc failed\n");
//  Pel *ptrU_Sig;   ptrU_Sig = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Sig == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Allocate memory to store partition size value
//  Pel *ptrY_PartSize;   ptrY_PartSize = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_PartSize == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  char strpoc[6];

//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);

// char FrmAsPNG[255];  strcpy(FrmAsPNG, m_pchSSIMLogAndImageFile);  strcat(FrmAsPNG, "DecFrm_PartwSADwAPCwHighlight_");    strcat(FrmAsPNG, strpoc);        strcat(FrmAsPNG, ".png");

//  // YGJ Tues 26th May 2015
//  // Store the QP to text file
//  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile);  strcat(FrmAsTxt, "DecFrm_PartwSADwAPCwHighlight_");    strcat(FrmAsTxt, strpoc);        strcat(FrmAsTxt, ".txt");

//  std::vector<unsigned char> imgFrmAsPNG; imgFrmAsPNG.resize(FourTimesFrameRes);
//  // YGJ Wed 27th May 2015
//  // Store the QP to array
//  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

//  unsigned MaxValue = (1<<bitDepthLuma)-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
//    Int   shiftc = bitDepthChroma-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

//int prevCloc = 0; // Previous cloc

//    for ( unsigned y = 0; y < height; y++ )
//    {
//      for ( unsigned x = 0; x < width; x++ )
//      {
//        unsigned yloc = y*width+x;
//        unsigned cloc = prevCloc;

//        // CShift: 1, 0, -1
//        // 420: 1/4, 422: 1/2, 444: 1
//        if (CShift == 1)
//        {
//          if (x%2 == 0)
//            cloc = (y >> 2) * (width >> 2) + (x >> 2);
//        }
//        else if (CShift == 1)
//        {
//          if (x%2 == 0)
//            cloc = (y >> 1) * (width >> 1) + (x >> 1);
//        }
//        else if (CShift == -1)
//          cloc = yloc;

//        prevCloc = cloc;

//        // allocate YUV value

//        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);

//        // Y_Sig contains QP and U_Sig contains skipped_flag

//        ptrY_Sig[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Sig[x]+offset)>>shift);
//        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);

//        // This links the signalling value in stream to a local array
//        // Gather current parition size
//        ptrY_PartSize[yloc]  = Clip3<Pel>(0, MaxValue, (piY_PartSize[x]+offset)>>shift);

//        int yInt_Org = (int)ptrY_Org[yloc];

//        int yInt_Sig = (int)ptrY_Sig[yloc];  int  uInt_Sig = (int)ptrU_Sig[cloc];
//        int yInt_Rec = (int)ptrY_Rec[yloc];

//        // Take current value parition size:
//        int yInt_PartSize = (int)ptrY_PartSize[yloc];

//        // SAD with APC, but for each pixel, so no total of a block, nor any APC related corner test, assumes to be true all the time.
//        // Keeping it simple, take average
//        int yInt_diff = (abs(yInt_Org - yInt_Rec) + abs(TComRdCost::HadAPC(yInt_Org, yInt_Rec, 0))) >> 1;

//        //-------------------------
//        imgFrmAsTxt[width * y + x] = yInt_Sig; //-1;
//        //-------------------------

//        if ((x% CShift) == 0)
//        {
//          unsigned cx = (x >> CShift);

//          ptrU_Sig[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Sig[cx]+offsetc)>>shiftc);

//          uInt_Sig = (int)ptrU_Sig[cloc];

//        }
//        else
//        {
//          uInt_Sig = (int)ptrU_Sig[cloc];
//        }

//        // Rec - Org
//        int r = 0;
//        int g = 0;
//        int b = 0;


////        int val = yInt_Sig < 13 ? 0 : yInt_Sig < 26 ? 1 : yInt_Sig < 39 ? 2 : 3;

//        // Normalise Had against assumed max.
//        //float normQP = ((float)yInt_Sig)/51;
//        float normQP = ((float)yInt_diff)/255;
//        // But need to it to be upto 40%
//        normQP = 1 - (normQP*0.4);

//        if ( uInt_Sig == 0 ) // Skipped Flag is zero
//        {

//            //------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//            switch (yInt_PartSize)
//            {
//                case 4 :  r = 255; g = (int)((normQP/(float)0.95)*yInt_Rec); b = (int)((normQP/(float)0.95)*yInt_Rec);  // Red   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//                    break;
//                case 8 :  r = 255; g = (int)((normQP/(float)0.65)*yInt_Rec); b = (int)((normQP/(float)0.95)*yInt_Rec); // Orange   // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//                    break;
//                case 16 :  r = 255; g = 255; b = (int)((normQP/(float)0.95)*yInt_Rec); // Yellow  // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//                    break;
//                case 32 : r = (int)((normQP/(float)0.95)*yInt_Rec); g = 255; b = (int)((normQP/(float)0.95)*yInt_Rec); // Green   // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//                    break;
//                default : 	r = (int)((normQP/(float)0.95)*yInt_Rec); g = 255; b = 255; // For 64x64  // Cyan (Sky blue)
//            }
//            //------------------

//        }
//        else
//        {
//            r = g = b = yInt_Rec;
//        }


//        // Rec - Org
//        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;

//        // Partitioning
//        if (yInt_Rec == 0 && (x % 2 == 0 || y % 2 == 0))
//        {
//            r = yInt_Rec;
//            g = yInt_Rec;
//            b = yInt_Rec;
//        }

//        imgFrmAsPNG[4 * width * y + 4 * x + 0] = r; //Red
//        imgFrmAsPNG[4 * width * y + 4 * x + 1] = g; //Green
//        imgFrmAsPNG[4 * width * y + 4 * x + 2] = b; //Blue
//        imgFrmAsPNG[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//      }
////      piY += YStride;
//      piY_Org += YStrideOrg;
//      piY_Sig += YStride;
//      piY_Rec += YStride;
//      piY_PartSize += YPartStride;



//      // CShift: 1, 0, -1
//      // 420: 1/4, 422: 1/2, 444: 1
//      if (CShift == 1)
//      {
//        if (y%2 == 0)
//        {
//          piCb_Sig += CStride;
//        }
//      }
//      else if (CShift == 1)
//      {
//        if (y%2 == 0)
//        {
//          piCb_Sig += CStride;
//        }
//      }
//      else if (CShift == -1)
//      {
//          piCb_Sig += CStride;
//      }
//    }

////    free(ptrY_Org);

//    free(ptrY_Sig);
//    free(ptrU_Sig);

//    free(ptrY_Rec);

//    free(ptrY_PartSize);



//      //Encode the image
//      unsigned error = lodepng::encode(FrmAsPNG, imgFrmAsPNG, width, height);

//      //if there's an error, display it
//      if(error) std::cout << "encoder error " << error << ": "<< lodepng_error_text(error) << std::endl;

//      if (m_rawTextData)
//      {
//          //-------------------------
//          // YGJ Wed 27th May 2015
//          // Output vector to txt file
//          // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
//          ofstream DecFrmAsTxt;
//          DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
//          for(int i = 0; i < imgFrmAsTxt.size(); ++i)
//          {
//              if ((i+1)%width==0)
//                  DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
//              else
//                  DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
//          }
//          DecFrmAsTxt.close();
//          //-------------------------
//      }

//    ////---------------------


//}

Void TAppDecTop::saveFrameAsPNG_SADx_NonSq_PreAssess_wCornerTest_APC(TComPic* pcPic)
{

  // unsigned height = m_iSourceHeight;
  // unsigned width = m_iSourceWidth;
  // unsigned FrameRes = (height*width);


  unsigned blkwidth = DistWidthSize(m_distWidthSize);
  unsigned blkheight = (blkwidth >> 1);
  unsigned blksz = blkwidth*blkheight;

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    // YGJ 16th March 2015 - Block size can vary in SSE version.
    // YGJ 14th May 2015 - Was missing in non-sq version

    int shiftby_x = (int)log2(blkwidth);
    int shiftby_y = (int)log2(blkheight);
    int downscaleby = (int)log2(blksz);

    Distortion *ptrDist_iSumHad;   ptrDist_iSumHad = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_iSumHad == NULL)   printf("calloc failed\n");
    Distortion *ptrDist_iSumHadAPC;   ptrDist_iSumHadAPC = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_iSumHadAPC == NULL)   printf("calloc failed\n");
    bool *ptrbool_ProceedwAPC;   ptrbool_ProceedwAPC = (bool *)calloc((FrameRes >> downscaleby), sizeof(bool));    if (ptrbool_ProceedwAPC == NULL)   printf("calloc failed\n");


   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];
  char strFactor[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  char strblkwidth[6];
  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);
  
  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile.c_str());
  strcat(SSIMHeatmap, "DecFrm_SAD");    strcat(SSIMHeatmap, strblkwidth);
  strcat(SSIMHeatmap, "NonSq_PreAssess_wCornerTest_APCHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
  strcat(SSIMHeatmap, ".png");

  // YGJ Tues 26th May 2015
  // Store the QP to text file
  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());
  strcat(FrmAsTxt, "DecFrm_SAD");
  strcat(FrmAsTxt, "NonSq_PreAssess_wCornerTest_APCHeatMap_");
  strcat(FrmAsTxt, strpoc);
  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
  strcat(FrmAsTxt, "_Factor");  strcat(FrmAsTxt, strFactor);
  strcat(FrmAsTxt, ".txt");


  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  // YGJ Thurs 28th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);


  unsigned MaxValue = (1<<bitDepthLuma)-1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

    UInt Threshold = APCCrossCornSubThresh;
    // YGJ 4th May 2015 - Four test corner test points used.
    UInt AbsAsymCost = 0;


    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;

        // allocate YUV value
        int yInt = 0; 

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc]; 
        int yInt_Rec = (int)ptrY_Rec[yloc];  
        int yInt_Part = (int)ptrY_Part[yloc]; 

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

//		bool HadRegion = false;
        Distortion iSumHad =0;
        Distortion iSumHadAPC =0;
        bool ProceedwAPC = false;

        if ((y < (height-blkheight)) && (x < (width-blkwidth)) && ((y % blkheight == 0) && (x % blkwidth == 0)))
        {
			
          // http://www.cplusplus.com/forum/general/40423/
          int* HadDiff = new int[blksz];

          //Int APC[blksz]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
          // http://www.cplusplus.com/forum/general/40423/
          int* APC = new int[blksz];

            for ( unsigned n = 0; n < blkheight; n++ )
            {
                for ( unsigned m = 0; m < blkwidth; m++ )
                {
                    // y*width + x
                    unsigned yloc8x8 = n*blkwidth+m;

                    Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
                    Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

                    ////------------------
                    //// YGJ 12th July 2014
                    //// Please note here the encoder assumes current/reconstructed block is `all zero block'
                    //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
                    //// a -- set up and initialise variables

                    ////------------------

                    HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
                    APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0);

                }
            }

            int i, j; 

//            // Use loops to recreate accumulation of APC on edges to judge if SAD or SAD with APC is calculated


            AbsAsymCost = abs((APC[0]-APC[(blkwidth*blkheight)-1])-(APC[(blkwidth-1)]-APC[(blkwidth*blkheight)-blkwidth])); // Less test points to estimate distortion perceptual variance

//            printf("SAD %d x %d, ACCS Threshold, %d, AbsAsymCost, %d \n", blkwidth, blkheight, Threshold, AbsAsymCost);

            // Sun 23rd Nov 2014
            // Having analysed log calculated values the median value for AbsAsymCost was 4 for SAD with APC.
            // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
            // Over 48 million observations were logged, which represented 8.7 million unique records.
            // This is significantly lower than previous as they were based on decoded reconstructed frame or upon logged from a partially encoded Intra frame.
            // Expect more samples will be affected than previous and that the processing time will increase accordingly.

            ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained


            for (j = 0; j < blkheight; j++)
            {
              for (i = 0; i < blkwidth; i++)
              {

                     iSumHad += abs(HadDiff[i+j*blkwidth]);
                     iSumHadAPC += abs(APC[i+j*blkwidth]);

              }
            }

            // YGJ 14th May 2015
            // Was missing in Non-Sq, taken from Sq version

            ptrDist_iSumHad[(x >> shiftby_x) + (y >> shiftby_y)*(width>>shiftby_x)] = iSumHad;
            ptrDist_iSumHadAPC[(x >> shiftby_x) + (y >> shiftby_y)*(width>>shiftby_x)] = iSumHadAPC;
            ptrbool_ProceedwAPC[(x >> shiftby_x) + (y >> shiftby_y)*(width>>shiftby_x)] = ProceedwAPC;

            delete HadDiff;
            delete APC;

            //printf("SAD %d x %d, ACCS Threshold, %d, AbsAsymCost, %d, iSumHad, %d, iSumHadAPC, %d \n", blkwidth, blkheight, Threshold, AbsAsymCost, iSumHad, iSumHadAPC);

        }
        else if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
        {
            iSumHad = ptrDist_iSumHad[(x >> shiftby_x) + (y >> shiftby_y)*(width>>shiftby_x)];
            iSumHadAPC = ptrDist_iSumHadAPC[(x >> shiftby_x) + (y >> shiftby_y)*(width>>shiftby_x)];
            ProceedwAPC = ptrbool_ProceedwAPC[(x >> shiftby_x) + (y >> shiftby_y)*(width>>shiftby_x)];
        }

        yInt = yInt_Rec;

        //--------------

//
        int r, b, g;

        //-------------------------
        // YGJ Thurs 28th May 2015
        // Store the QP to array

        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) )
        {
            if (ProceedwAPC == true)
                imgFrmAsTxt[width * y + x] = ((int)iSumHad+ (int)(iSumHadAPC >> APC_Downscale));
            else
                imgFrmAsTxt[width * y + x] = (int)iSumHad;
        }
        else
            imgFrmAsTxt[width * y + x] = -1;
        //-------------------------

        //  APC score will be between 0 and 127.
        // Dependent upon value apply different colour
        if (ProceedwAPC == true)
        {
            //------------------
            // Using arrays as look up tables to ensure values set are consistent
            int loc = (int)log2((double)blkwidth) - 3;

            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
            float maxScaled = (float)((float)maxUnscaled * (0.1024));
            float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

            Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

            // For Non-Sq
            halfMaxThreshold >>= 1; // Half
            
            iSumHadAPC = iSumHadAPC >> APC_Downscale ; // fixed scale for APC

            iSumHad += iSumHadAPC;

            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

            float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = ((double)normHad) > 1.0? (float)1.0 : normHad;

            int val =  ((double)normHad) < 0.25? 0 :
                       ((double)normHad) < 0.5? 1 :
                       ((double)normHad) < 0.75? 2 : 3;

            //------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
            switch (val)
            {
                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                    break;
                case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                    break;
                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                    break;
                default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                    break;
            }
            //------------------

        }
        else
        {
            r = yInt; 
            g = yInt; 
            b = yInt; 
        }


        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


        // Partitioning -- Not Working
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; //yInt_RmO;
          g = 0; //yInt_RmO;
          b = 0; //yInt_RmO;
        }

        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      //piY += YStride;
      piY_Org += YStride;
      piY_Rec += YStrideRec;
      piY_Part += YStrideRec;

    }


    free(ptrY_Org8x8);
    free(ptrY_Rec8x8);

    free(ptrY_Org);

    free(ptrY_Rec);

    free(ptrY_Part);


    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

    if (m_rawTextData)
    {
        //-------------------------
        // YGJ Thurs 28th May 2015
        // Output vector to txt file
        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
        ofstream DecFrmAsTxt;
        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
        {
            if ((i+1)%width==0)
                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
            else
                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
        }
        DecFrmAsTxt.close();
        //-------------------------
    }

}



// YGJ 12th July 2015
// Storing values via custom structure
// RC Had, APCms, APCmsDownscale, AbsAsymCost, Thresh(48), EdgeCount
//struct StorValues

class StorValuesSSEwSASD
{
public:
    int SSE;
    int SASD;
    //int SASDDownscale; //happens during calc
    int AbsAsymCost;
    int SideThreshold;
    int EdgeThreshold;
    int SASDThreshold;
    int EdgeCost;
    int MeanOrgLuma;
    int MeanRecLuma;
    double SASDDownAsPercent;
};



//Void TAppDecTop::saveFrameAsPNG_AlwaysTrue_SSEx_wSASD_wEdgeDetect(TComPic* pcPic)
//{


//  // unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
//  // unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
//  // unsigned FrameRes = (height*width);
  
//  unsigned blkwidth = DistWidthSize(m_distWidthSize);
//  unsigned blksz = blkwidth*blkwidth;

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");


//    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
//    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
//    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
//    // YGJ 16th March 2015 - Block size can vary in SSE version.

//    int shiftby = (int)log2(blkwidth);
//    int downscaleby = (int)log2(blksz);

//    Distortion *ptrDist_SSE;   ptrDist_SSE = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_SSE == NULL)   printf("calloc failed\n");
//    Distortion *ptrDist_SASD;   ptrDist_SASD = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_SASD == NULL)   printf("calloc failed\n");
//    bool *ptrbool_perfSASD;   ptrbool_perfSASD = (bool *)calloc((FrameRes >> downscaleby), sizeof(bool));    if (ptrbool_perfSASD == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  char strpoc[6];
//  char strRange[8];

//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);
  
//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);

//  char strblkwidth[6];
//  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "AlwaysTrue_DecFrm_SSE");
//  strcat(SSIMHeatmap, strblkwidth);
//  strcat(SSIMHeatmap, "wSASD_wEdgeDetect_HeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, ".png");

//  // YGJ Tues 26th May 2015
//  // Store the QP to text file
//  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile);
//  strcat(FrmAsTxt, "AlwaysTrue_DecFrm_SSE");
//  strcat(FrmAsTxt, strblkwidth);
//  strcat(FrmAsTxt, "wSASD_wEdgeDetect_HeatMap_");
//  strcat(FrmAsTxt, strpoc);
//  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
//  strcat(FrmAsTxt, ".txt");

//  // YGJ 24th July 2015
//  char ValAsTxt[255];  strcpy(ValAsTxt, m_pchSSIMLogAndImageFile);
//  strcat(ValAsTxt, "AlwaysTrue_DecVal_SSE");
//  strcat(ValAsTxt, strblkwidth);
//  strcat(ValAsTxt, "wSASD_wEdgeDetect_HeatMap_");
//  strcat(ValAsTxt, strpoc);
//  strcat(ValAsTxt, "_Range");  strcat(ValAsTxt, strRange);
//  strcat(ValAsTxt, ".txt");

////  // YGJ 12th July 2015
////  // Storing values via custom structure
////  // RC Had, APCms, APCmsDownscale, AbsAsymCost, Thresh(48), EdgeCount
////  struct StorValuesSSEwSASD
////  {
////      int SSE;
////      int SASD;
////      int SASDDownscale;
////      int AbsAsymCost;
////      int Threshold;
////      int EdgeCost;
////      int MeanLuma;
////      double SASDDownAsPercent;
////  };
//  // Now store in vector form every 8x8 in FrameRes, downscale by downscaleby factor
//  std::vector<StorValuesSSEwSASD> StorValuesAsTxt; StorValuesAsTxt.resize(FrameRes >> downscaleby);

//  StorValuesSSEwSASD CurrScores;

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  // YGJ Thurs 28th May 2015
//  // Store the QP to array
//  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

//  unsigned MaxValue = (1<<bitDepthLuma)-1;
//    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//	for ( unsigned y = 0; y < height; y++ )
//	{
//	  for ( unsigned x = 0; x < width; x++ )
//	  {
//		unsigned yloc = y*width+x;

//		// allocate YUV value
//		int yInt = 0;

//		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//		int yInt_Org = (int)ptrY_Org[yloc];
//		int yInt_Rec = (int)ptrY_Rec[yloc];
//		int yInt_Part = (int)ptrY_Part[yloc];

//		// seems fine here
//		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
//			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

//        //bool SSERegion = false;
//		Distortion iSumHad =0;
//		Distortion iSumSSE =0;
//		Distortion iSumSASD =0;
//        bool SASD_Grth_Threshold = false;

//        //if ((y < (height-blkwidth)) && (x < (width-blkwidth)))

//        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
//        // YGJ 5th Jan 2014 - Every 8x8 block
//        //if ((y < (height-blkwidth)) && (x < (width-blkwidth)) && ((y % blkwidth == 0) && (x % blkwidth == 0)))
//        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) )
//		{
//          //SSERegion = true;

//          CurrScores.SSE = 0;
//          CurrScores.SASD = 0;
//          CurrScores.AbsAsymCost = 0;
//          CurrScores.SideThreshold = 0;
//          CurrScores.EdgeCost = 0;
//          CurrScores.MeanOrgLuma = 0;
//          CurrScores.MeanRecLuma = 0;
//          CurrScores.SASDDownAsPercent = 0.0;

//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* SSEDiff = new int[blksz];
//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* SASDDiff = new int[blksz];

//          long meanOrgLuma = 0;
//          long meanRecLuma = 0;

//			//for ( unsigned n = 0; n < blkwidth; n++ )
//			//{
//			//	for ( unsigned m = 0; m < blkwidth; m++ )
//			//	{
//                    unsigned n = 0, m = 0;
//					// y*width + x
//					unsigned yloc8x8 = n*blkwidth+m;

//					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//                    meanOrgLuma += y_Org;
//                    meanRecLuma += y_Rec;

//					////------------------
//					//// YGJ 12th July 2014
//					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
//					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//					//// a -- set up and initialise variables

//					////------------------

//					int Temp = y_Org - y_Rec;
//					int TempSq = shift == 0? LumaSq_LUT[abs(Temp)] : Temp*Temp;

//					SSEDiff[yloc8x8] = TempSq;

//					int OrgSq = shift == 0? LumaSq_LUT[y_Org] : y_Org*y_Org;
//					int RecSq=  shift == 0? LumaSq_LUT[y_Rec] : y_Rec*y_Rec;
					
//                    //SASDDiff[yloc8x8] = (abs(abs(OrgSq-RecSq) - TempSq)) >> 8; // YGJ 14th April 2015 was applying downshift by 8 later not during SASD calc.
//                    SASDDiff[yloc8x8] = (abs(abs(OrgSq-RecSq) - TempSq)) >> 7; // Should be >>7 as stated in thesis and paper
//                    imgFrmAsTxt[width * y + x] = ( (int)(SASDDiff[yloc8x8]));

//			//	}
//			//}

//            meanOrgLuma >>= downscaleby;
//            meanRecLuma >>= downscaleby;

//            CurrScores.MeanOrgLuma = meanOrgLuma;
//            CurrScores.MeanRecLuma = meanRecLuma;

//            int i=0, j=0; //, jj;//, k;

//			for (i = 0; i < blkwidth; i++)
//			{
//			  for (j = 0; j < blkwidth; j++)
//			  {
//				iSumSSE += abs(SSEDiff[i+j*blkwidth]);
//				iSumSASD += abs(SASDDiff[i+j*blkwidth]);
//			  }
//			}

//            CurrScores.SSE = iSumSSE;

//            //----
//            // YGJ 13th Apr 2015
//            // Added AysBlkTest prior to block test within block.
//            //----

//            // Like in HadRC and in SAD/HAD apply perceptual cost to perceptual poor blocks (where 1-SSIM score is high)
//            // Edges minus corners

//            int Top = 0;
//            int Left = 0;
//            int Right = 0;
//            int Bottom = 0;

//            for (i = 1; i < blkwidth-1; i++)
//            {
//                Top += abs(SASDDiff[i]);
//                Left += abs(SASDDiff[i*blkwidth]);
//                Right += abs(SASDDiff[i*blkwidth+blkwidth-1]);
//                Bottom += abs(SASDDiff[blkwidth*(blkwidth-1)+i]);
//            }

//            // Approx Average. If 8x8, then 6 items read then divide by width, 8.
//            Top /= blkwidth;
//            Left /= blkwidth;
//            Right /= blkwidth;
//            Bottom /= blkwidth;


//            // 1) Calc block sides:
//            // From ::saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
//            UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

//            //YGJ 14th April 2015 - Having used the log from the decoder (CrowdRun 1, 4 and 16 Mbps (a single frame, frame 77), a threshold of >2 was deemed appropiate
//            // This should reduce where SASD is added to the SSE score.
//            //UInt AsymBlkEdgeThresh = 2;

//            // Reverting back to match encoder and tests runs. From 2 back to 8.
//            // Same across all block sizes
//            UInt AsymBlkSideThresh = 8;


//            //bool PerformIntBlkEdge = AbsAsymCost > AsymBlkEdgeThresh ? true : false;  // 16 Found to be highest point to at which most APC features are retained
//            bool PerformIntBlkSides = true; //AbsAsymCost > AsymBlkSideThresh ? true : false;  // 16 Found to be highest point to at which most APC features are retained

//            // 2) Is SASD value sufficiently high enough to warrent further investigation?

//            // YGJ 11th Dec 2014 - Based upon recalc SASD from raw values for affected pixel of edge detect
//            // Median was 496, will approx to 512 for 8x8.

//            // YGJ 24th July 2015 - base thresh is 128 for 4x4, goes up by 2^2 for every increase in block size.
//            // Having deemed that there is something here, is of significance to be perceptually counted.
//            int SASDthreshold = 128 << ((shiftby - 2) << 1); //512;

//            bool PerformIntBlkEdge = true; //(PerformIntBlkSides == true) && (iSumSASD > SASDthreshold) ? true : false;

//            CurrScores.AbsAsymCost = AbsAsymCost;
//            CurrScores.SideThreshold = AsymBlkSideThresh;
//            CurrScores.SASDThreshold = SASDthreshold;


//            //----

//            int SumSASDEdgeCost=0;

//            //----

////            // Currently only works for 8x8 and not for all block sizes
////            if (PerformIntBlkEdge == true & blkwidth ==8)
////            {

////                SumSASDEdgeCost += ( (SASDDiff[9] << 1) - SASDDiff[8] - SASDDiff[1]) >  0 ? 1 : 0; // SE
////                SumSASDEdgeCost += ( (SASDDiff[3] << 1) - SASDDiff[2] - SASDDiff[11]) >  0 ? 1 : 0; //NE
////                SumSASDEdgeCost += ( (SASDDiff[24] << 1) - SASDDiff[25] - SASDDiff[16]) >  0 ? 1 : 0; // SW
////                SumSASDEdgeCost += ( (SASDDiff[18] << 1) - SASDDiff[19] - SASDDiff[26]) >  0 ? 1 : 0; // NW

////                SumSASDEdgeCost += ( (SASDDiff[13] << 1) - SASDDiff[12] - SASDDiff[5]) >  0 ? 1 : 0; // SE
////                SumSASDEdgeCost += ( (SASDDiff[7] << 1) - SASDDiff[6] - SASDDiff[15]) >  0 ? 1 : 0; //NE
////                SumSASDEdgeCost += ( (SASDDiff[28] << 1) - SASDDiff[29] - SASDDiff[20]) >  0 ? 1 : 0; // SW
////                SumSASDEdgeCost += ( (SASDDiff[22] << 1) - SASDDiff[23] - SASDDiff[30]) >  0 ? 1 : 0; // NW

////                SumSASDEdgeCost += ( (SASDDiff[41] << 1) - SASDDiff[40] - SASDDiff[33]) >  0 ? 1 : 0; // SE
////                SumSASDEdgeCost += ( (SASDDiff[35] << 1) - SASDDiff[34] - SASDDiff[43]) >  0 ? 1 : 0; //NE
////                SumSASDEdgeCost += ( (SASDDiff[56] << 1) - SASDDiff[57] - SASDDiff[48]) >  0 ? 1 : 0; // SW
////                SumSASDEdgeCost += ( (SASDDiff[50] << 1) - SASDDiff[51] - SASDDiff[58]) >  0 ? 1 : 0; // NW

////                SumSASDEdgeCost += ( (SASDDiff[45] << 1) - SASDDiff[44] - SASDDiff[37]) >  0 ? 1 : 0; // SE
////                SumSASDEdgeCost += ( (SASDDiff[39] << 1) - SASDDiff[38] - SASDDiff[47]) >  0 ? 1 : 0; //NE
////                SumSASDEdgeCost += ( (SASDDiff[60] << 1) - SASDDiff[61] - SASDDiff[52]) >  0 ? 1 : 0; // SW
////                SumSASDEdgeCost += ( (SASDDiff[54] << 1) - SASDDiff[55] - SASDDiff[62]) >  0 ? 1 : 0; // NW

////            }
////            else

//            // YGJ 24th July 2015 -  Making it more work for other block sizes 4,.. 64
//            if(PerformIntBlkEdge == true)
//            {
//                int w = blkwidth;
//                int w2 = w<<1;
//                int w3 = w + w2;

//                for (j = 0; j < blkwidth ; j += 4)
//                {
//                    for (i = 0; i < blkwidth ; i += 4)
//                    {
//                        int p = (j << shiftby) + i;

//                        SumSASDEdgeCost += ( (SASDDiff[w+1+p] << 1) - SASDDiff[w+p] - SASDDiff[1+p]) >  0 ? 1 : 0; // SE
//                        SumSASDEdgeCost += ( (SASDDiff[3+p] << 1) - SASDDiff[2+p] - SASDDiff[w+3+p]) >  0 ? 1 : 0; // NE
//                        SumSASDEdgeCost += ( (SASDDiff[w3+p] << 1) - SASDDiff[w3+1+p] - SASDDiff[w2+p]) >  0 ? 1 : 0; // SW
//                        SumSASDEdgeCost += ( (SASDDiff[w2+2+p] << 1) - SASDDiff[w2+3+p] - SASDDiff[w3+2+p]) >  0 ? 1 : 0; // NW

//                    }
//                }

//            }
            
//            //int SASD_EdgeCompassSum_thresh = 8; // Based upon modeling of raw data, median was 8. Removed abs, keep it simple. ~1/6 obs affected

//            int SASD_EdgeCompassSum_thresh = 8;

//            switch (blkwidth)
//            {
//                case 4: SASD_EdgeCompassSum_thresh = 2; break;
//                case 8: SASD_EdgeCompassSum_thresh = 8; break;
//                case 16: SASD_EdgeCompassSum_thresh = 32; break;
//                case 32: SASD_EdgeCompassSum_thresh = 128; break;
//                case 64: SASD_EdgeCompassSum_thresh = 512; break;
//            }


//            //SASD_Grth_Threshold = (SumSASDEdgeCost > SASD_EdgeCompassSum_thresh) && (iSumSASD > threshold) ? true : false;
//            SASD_Grth_Threshold = true; //(SumSASDEdgeCost > SASD_EdgeCompassSum_thresh) ? true : false;
//            //iSumSASD >>= 1;
//            // YGJ 24th July 2015 - updated to match encoder. Fixed scale of 2
//            iSumSASD <<= 1;
                     

//            CurrScores.EdgeThreshold = SASD_EdgeCompassSum_thresh;
//            CurrScores.EdgeCost = SumSASDEdgeCost;
//            CurrScores.SASD = iSumSASD;
//            CurrScores.SASDDownAsPercent = (double)((int)iSumSASD)/((int)iSumSSE);

//            StorValuesAsTxt.push_back(CurrScores);


//            ptrDist_SSE[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = iSumSSE;
//            ptrDist_SASD[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = iSumSASD;
//            ptrbool_perfSASD[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = SASD_Grth_Threshold;
			
//			delete SSEDiff;
//			delete SASDDiff;
//		}
//        else if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
//        {
//            iSumSSE = ptrDist_SSE[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
//            iSumSASD = ptrDist_SASD[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
//            SASD_Grth_Threshold = ptrbool_perfSASD[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
//        }
        
//		yInt = yInt_Rec;

//        int r, b, g;

//        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) )
//        {
//            if (SASD_Grth_Threshold == true)
//            {
//                //imgFrmAsTxt[width * y + x] = ((int)iSumSSE+ (int)(iSumSASD));
//                //imgFrmAsTxt[width * y + x] = ( (int)(iSumSASD));
//            }
//            else
//                imgFrmAsTxt[width * y + x] = (int)iSumSSE;
//        }
//        else
//            imgFrmAsTxt[width * y + x] = -1;
//        //-------------------------


//        //  APC score will be between 0 and 127.
//        // Dependent upon value apply different colour
//        if (SASD_Grth_Threshold == true)
//        {
//            //iSumHad = iSumSSE + iSumSASD;
//            iSumHad = iSumSASD;

//			//------------------------------

//			int loc = (int)log2((double)blkwidth) - 3;

//			int maxUnscaled = (maxLimitSSE_k[loc] * NormDist_OneMin10k[m_distRange]);
//			float maxScaled = (float)((float)maxUnscaled * (0.1024));

//			Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor;

//			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

									
////			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
////				printf("SSE %d wSASD (with EdgeDetect) is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
////				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
//			float normHad = ((float)dist)/((float)halfMaxThreshold);

//            // YGJ 15th March 2015
//            // Use 1/2 max based normalised value
//            // Based on normJND

//            normHad = ((double)normHad) > 1.0? 1.0 : normHad;

//            int val =  ((double)normHad) < 0.25? 0 :
//                       ((double)normHad) < 0.5? 1 :
//                       ((double)normHad) < 0.75? 2 : 3;

//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------

//		}
//		else
//		{
//			r = yInt;
//			g = yInt;
//			b = yInt;
//		}


//		// Rec - Org
//		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//		// Partitioning -- Not Working
//		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//		{
//		  r = 0; //yInt_RmO;
//		  g = 0; //yInt_RmO;
//		  b = 0; //yInt_RmO;
//		}
		
//		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//	  }
//	  //piY += YStride;
//	  piY_Org += YStride;
//	  piY_Rec += YStrideRec;
//	  piY_Part += YStrideRec;

//	}

//	free(ptrY_Org8x8);
//	free(ptrY_Rec8x8);

//	free(ptrY_Org);

//	free(ptrY_Rec);

//	free(ptrY_Part);

//	//-----------------------

//	if(m_outputSSIMHeatmaps)
//	{
//	  std::vector<unsigned char> png;

//	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//	  //if there's an error, display it
//	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//	}

//   //-----------------------

//    if (m_rawTextData)
//    {
//        //-------------------------
//        // YGJ Thurs 28th May 2015
//        // Output vector to txt file
//        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
//        ofstream DecFrmAsTxt;
//        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
//        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
//        {
//            if ((i+1)%width==0)
//                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
//            else
//                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
//        }
//        DecFrmAsTxt.close();
//        //-------------------------


////        class StorValuesSSEwSASD
////        {
////        public:
////            int SSE;
////            int SASD;
////            //int SASDDownscale; //happens during calc
////            int AbsAsymCost;
////            int SideThreshold;
////            int EdgeThreshold;
////            int SASDThreshold;
////            int EdgeCost;
////            int MeanOrgLuma;
////            int MeanRecLuma;
////            double SASDDownAsPercent;
////        };

//        ofstream DecValsAsTxt;
//        DecValsAsTxt.open (ValAsTxt, ios::out | ios::app);

//        DecValsAsTxt << "SSE, SASD, AbsAsymCost, SideThreshold, EdgeThreshold, SASDThreshold, EdgeCost, MeanOrgLuma, MeanRecLuma, SASDDownAsPercent" << endl ;

//        //StorValuesAsTxt
//        for (unsigned int i = 0; i< StorValuesAsTxt.size(); i ++)
//        {

//            if (StorValuesAsTxt[i].EdgeCost > StorValuesAsTxt[i].EdgeThreshold)
//                DecValsAsTxt << StorValuesAsTxt[i].SSE << ", " << StorValuesAsTxt[i].SASD << ", " << StorValuesAsTxt[i].AbsAsymCost << ", "
//                         << StorValuesAsTxt[i].SideThreshold << ", " << StorValuesAsTxt[i].EdgeThreshold << ", " << StorValuesAsTxt[i].SASDThreshold << ", "
//                         << StorValuesAsTxt[i].EdgeCost << ", " << StorValuesAsTxt[i].MeanOrgLuma << ", " << StorValuesAsTxt[i].MeanRecLuma <<  ", "
//                         << StorValuesAsTxt[i].SASDDownAsPercent << endl ;
//        }

//        DecValsAsTxt.close();



//    }

//}





Void TAppDecTop::saveFrameAsPNG_SSEx_wSASD_wEdgeDetect(TComPic* pcPic)
{


  // unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
  // unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
  // unsigned FrameRes = (height*width);
  
  unsigned blkwidth = DistWidthSize(m_distWidthSize);
  unsigned blksz = blkwidth*blkwidth;

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");


    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    // YGJ 16th March 2015 - Block size can vary in SSE version.

    int shiftby = (int)log2(blkwidth);
    int downscaleby = (int)log2(blksz);

    Distortion *ptrDist_SSE;   ptrDist_SSE = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_SSE == NULL)   printf("calloc failed\n");
    Distortion *ptrDist_SASD;   ptrDist_SASD = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_SASD == NULL)   printf("calloc failed\n");
    bool *ptrbool_perfSASD;   ptrbool_perfSASD = (bool *)calloc((FrameRes >> downscaleby), sizeof(bool));    if (ptrbool_perfSASD == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  char strpoc[6];  
  char strRange[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);
  
  snprintf(strRange, sizeof(strRange), "%d", m_distRange);

  char strblkwidth[6];
  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile.c_str());
  strcat(SSIMHeatmap, "DecFrm_SSE");   
  strcat(SSIMHeatmap, strblkwidth);  
  strcat(SSIMHeatmap, "wSASD_wEdgeDetect_HeatMap_");  
  strcat(SSIMHeatmap, strpoc);        
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  strcat(SSIMHeatmap, ".png");

  // YGJ Tues 26th May 2015
  // Store the QP to text file
  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());
  strcat(FrmAsTxt, "DecFrm_SSE");
  strcat(FrmAsTxt, strblkwidth);
  strcat(FrmAsTxt, "wSASD_wEdgeDetect_HeatMap_");
  strcat(FrmAsTxt, strpoc);
  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
  strcat(FrmAsTxt, ".txt");

  // YGJ 24th July 2015
  char ValAsTxt[255];  strcpy(ValAsTxt, m_pchSSIMLogAndImageFile.c_str());
  strcat(FrmAsTxt, "DecVal_SSE");
  strcat(FrmAsTxt, strblkwidth);
  strcat(FrmAsTxt, "wSASD_wEdgeDetect_HeatMap_");
  strcat(ValAsTxt, strpoc);
  strcat(ValAsTxt, "_Range");  strcat(ValAsTxt, strRange);
  strcat(ValAsTxt, ".txt");

//  // YGJ 12th July 2015
//  // Storing values via custom structure
//  // RC Had, APCms, APCmsDownscale, AbsAsymCost, Thresh(48), EdgeCount
//  struct StorValuesSSEwSASD
//  {
//      int SSE;
//      int SASD;
//      int SASDDownscale;
//      int AbsAsymCost;
//      int Threshold;
//      int EdgeCost;
//      int MeanLuma;
//      double SASDDownAsPercent;
//  };
  // Now store in vector form every 8x8 in FrameRes, downscale by downscaleby factor
  std::vector<StorValuesSSEwSASD> StorValuesAsTxt; StorValuesAsTxt.resize(FrameRes >> downscaleby);

  StorValuesSSEwSASD CurrScores;

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  // YGJ Thurs 28th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

  unsigned MaxValue = (1<<bitDepthLuma)-1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;

		// allocate YUV value
		int yInt = 0;

		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

		int yInt_Org = (int)ptrY_Org[yloc];  
		int yInt_Rec = (int)ptrY_Rec[yloc];  
		int yInt_Part = (int)ptrY_Part[yloc]; 

		// seems fine here
		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

        //bool SSERegion = false;
		Distortion iSumHad =0;
		Distortion iSumSSE =0;
		Distortion iSumSASD =0;
        bool SASD_Grth_Threshold = false;

        //if ((y < (height-blkwidth)) && (x < (width-blkwidth)))

        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) && ((y % blkwidth == 0) && (x % blkwidth == 0)))
		{
          //SSERegion = true;

          CurrScores.SSE = 0;
          CurrScores.SASD = 0;
          CurrScores.AbsAsymCost = 0;
          CurrScores.SideThreshold = 0;
          CurrScores.EdgeCost = 0;
          CurrScores.MeanOrgLuma = 0;
          CurrScores.MeanRecLuma = 0;
          CurrScores.SASDDownAsPercent = 0.0;

		  // http://www.cplusplus.com/forum/general/40423/
		  int* SSEDiff = new int[blksz];
		  // http://www.cplusplus.com/forum/general/40423/
		  int* SASDDiff = new int[blksz];

          long meanOrgLuma = 0;
          long meanRecLuma = 0;

			for ( unsigned n = 0; n < blkwidth; n++ )
			{
				for ( unsigned m = 0; m < blkwidth; m++ )
				{
					// y*width + x
					unsigned yloc8x8 = n*blkwidth+m;

					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

                    meanOrgLuma += y_Org;
                    meanRecLuma += y_Rec;

					////------------------
					//// YGJ 12th July 2014
					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
					//// a -- set up and initialise variables

					////------------------

					int Temp = y_Org - y_Rec;
					int TempSq = shift == 0? LumaSq_LUT[abs(Temp)] : Temp*Temp;

					SSEDiff[yloc8x8] = TempSq;

					int OrgSq = shift == 0? LumaSq_LUT[y_Org] : y_Org*y_Org;
					int RecSq=  shift == 0? LumaSq_LUT[y_Rec] : y_Rec*y_Rec;
					
                    SASDDiff[yloc8x8] = (abs(abs(OrgSq-RecSq) - TempSq)) >> 8; // YGJ 14th April 2015 was applying downshift by 8 later not during SASD calc.

				}
			}

            meanOrgLuma >>= downscaleby;
            meanRecLuma >>= downscaleby;

            CurrScores.MeanOrgLuma = meanOrgLuma;
            CurrScores.MeanRecLuma = meanRecLuma;

            int i=0, j=0; //, jj;//, k;

			for (i = 0; i < blkwidth; i++)
			{
			  for (j = 0; j < blkwidth; j++)
			  {
				iSumSSE += abs(SSEDiff[i+j*blkwidth]);
				iSumSASD += abs(SASDDiff[i+j*blkwidth]);
			  }
			}

            CurrScores.SSE = iSumSSE;

            //----
            // YGJ 13th Apr 2015
            // Added AysBlkTest prior to block test within block.
            //----

            // Like in HadRC and in SAD/HAD apply perceptual cost to perceptual poor blocks (where 1-SSIM score is high)
            // Edges minus corners

            int Top = 0;
            int Left = 0;
            int Right = 0;
            int Bottom = 0;

            for (i = 1; i < blkwidth-1; i++)
            {
                Top += abs(SASDDiff[i]);
                Left += abs(SASDDiff[i*blkwidth]);
                Right += abs(SASDDiff[i*blkwidth+blkwidth-1]);
                Bottom += abs(SASDDiff[blkwidth*(blkwidth-1)+i]);
            }

            // Approx Average. If 8x8, then 6 items read then divide by width, 8.
            Top /= blkwidth;
            Left /= blkwidth;
            Right /= blkwidth;
            Bottom /= blkwidth;


            // 1) Calc block sides:
            // From ::saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
            UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

            //YGJ 14th April 2015 - Having used the log from the decoder (CrowdRun 1, 4 and 16 Mbps (a single frame, frame 77), a threshold of >2 was deemed appropiate
            // This should reduce where SASD is added to the SSE score.
            //UInt AsymBlkEdgeThresh = 2;

            // Reverting back to match encoder and tests runs. From 2 back to 8.
            // Same across all block sizes
            UInt AsymBlkSideThresh = 8;


            //bool PerformIntBlkEdge = AbsAsymCost > AsymBlkEdgeThresh ? true : false;  // 16 Found to be highest point to at which most APC features are retained
            bool PerformIntBlkSides = AbsAsymCost > AsymBlkSideThresh ? true : false;  // 16 Found to be highest point to at which most APC features are retained

            // 2) Is SASD value sufficiently high enough to warrent further investigation?

            // YGJ 11th Dec 2014 - Based upon recalc SASD from raw values for affected pixel of edge detect
            // Median was 496, will approx to 512 for 8x8.

            // YGJ 24th July 2015 - base thresh is 128 for 4x4, goes up by 2^2 for every increase in block size.
            // Having deemed that there is something here, is of significance to be perceptually counted.
            int SASDthreshold = 128 << ((shiftby - 2) << 1); //512;

            bool PerformIntBlkEdge = (PerformIntBlkSides == true) && (iSumSASD > SASDthreshold) ? true : false;

            CurrScores.AbsAsymCost = AbsAsymCost;
            CurrScores.SideThreshold = AsymBlkSideThresh;
            CurrScores.SASDThreshold = SASDthreshold;


            //----

            int SumSASDEdgeCost=0;

            //----

//            // Currently only works for 8x8 and not for all block sizes
//            if (PerformIntBlkEdge == true & blkwidth ==8)
//            {

//                SumSASDEdgeCost += ( (SASDDiff[9] << 1) - SASDDiff[8] - SASDDiff[1]) >  0 ? 1 : 0; // SE
//                SumSASDEdgeCost += ( (SASDDiff[3] << 1) - SASDDiff[2] - SASDDiff[11]) >  0 ? 1 : 0; //NE
//                SumSASDEdgeCost += ( (SASDDiff[24] << 1) - SASDDiff[25] - SASDDiff[16]) >  0 ? 1 : 0; // SW
//                SumSASDEdgeCost += ( (SASDDiff[18] << 1) - SASDDiff[19] - SASDDiff[26]) >  0 ? 1 : 0; // NW

//                SumSASDEdgeCost += ( (SASDDiff[13] << 1) - SASDDiff[12] - SASDDiff[5]) >  0 ? 1 : 0; // SE
//                SumSASDEdgeCost += ( (SASDDiff[7] << 1) - SASDDiff[6] - SASDDiff[15]) >  0 ? 1 : 0; //NE
//                SumSASDEdgeCost += ( (SASDDiff[28] << 1) - SASDDiff[29] - SASDDiff[20]) >  0 ? 1 : 0; // SW
//                SumSASDEdgeCost += ( (SASDDiff[22] << 1) - SASDDiff[23] - SASDDiff[30]) >  0 ? 1 : 0; // NW

//                SumSASDEdgeCost += ( (SASDDiff[41] << 1) - SASDDiff[40] - SASDDiff[33]) >  0 ? 1 : 0; // SE
//                SumSASDEdgeCost += ( (SASDDiff[35] << 1) - SASDDiff[34] - SASDDiff[43]) >  0 ? 1 : 0; //NE
//                SumSASDEdgeCost += ( (SASDDiff[56] << 1) - SASDDiff[57] - SASDDiff[48]) >  0 ? 1 : 0; // SW
//                SumSASDEdgeCost += ( (SASDDiff[50] << 1) - SASDDiff[51] - SASDDiff[58]) >  0 ? 1 : 0; // NW

//                SumSASDEdgeCost += ( (SASDDiff[45] << 1) - SASDDiff[44] - SASDDiff[37]) >  0 ? 1 : 0; // SE
//                SumSASDEdgeCost += ( (SASDDiff[39] << 1) - SASDDiff[38] - SASDDiff[47]) >  0 ? 1 : 0; //NE
//                SumSASDEdgeCost += ( (SASDDiff[60] << 1) - SASDDiff[61] - SASDDiff[52]) >  0 ? 1 : 0; // SW
//                SumSASDEdgeCost += ( (SASDDiff[54] << 1) - SASDDiff[55] - SASDDiff[62]) >  0 ? 1 : 0; // NW

//            }
//            else

            // YGJ 24th July 2015 -  Making it more work for other block sizes 4,.. 64
            if(PerformIntBlkEdge == true)
            {
                int w = blkwidth;
                int w2 = w<<1;
                int w3 = w + w2;

                for (j = 0; j < blkwidth ; j += 4)
                {
                    for (i = 0; i < blkwidth ; i += 4)
                    {
                        int p = (j << shiftby) + i;

                        SumSASDEdgeCost += ( (SASDDiff[w+1+p] << 1) - SASDDiff[w+p] - SASDDiff[1+p]) >  0 ? 1 : 0; // SE
                        SumSASDEdgeCost += ( (SASDDiff[3+p] << 1) - SASDDiff[2+p] - SASDDiff[w+3+p]) >  0 ? 1 : 0; // NE
                        SumSASDEdgeCost += ( (SASDDiff[w3+p] << 1) - SASDDiff[w3+1+p] - SASDDiff[w2+p]) >  0 ? 1 : 0; // SW
                        SumSASDEdgeCost += ( (SASDDiff[w2+2+p] << 1) - SASDDiff[w2+3+p] - SASDDiff[w3+2+p]) >  0 ? 1 : 0; // NW

                    }
                }

            }
            
            //int SASD_EdgeCompassSum_thresh = 8; // Based upon modeling of raw data, median was 8. Removed abs, keep it simple. ~1/6 obs affected

            int SASD_EdgeCompassSum_thresh = 8;

            switch (blkwidth)
            {
                case 4: SASD_EdgeCompassSum_thresh = 2; break;
                case 8: SASD_EdgeCompassSum_thresh = 8; break;
                case 16: SASD_EdgeCompassSum_thresh = 32; break;
                case 32: SASD_EdgeCompassSum_thresh = 128; break;
                case 64: SASD_EdgeCompassSum_thresh = 512; break;
            }


            //SASD_Grth_Threshold = (SumSASDEdgeCost > SASD_EdgeCompassSum_thresh) && (iSumSASD > threshold) ? true : false;
            SASD_Grth_Threshold = (SumSASDEdgeCost > SASD_EdgeCompassSum_thresh) ? true : false;
            //iSumSASD >>= 1;
            // YGJ 24th July 2015 - updated to match encoder. Fixed scale of 2
            iSumSASD <<= 1;
                     

            CurrScores.EdgeThreshold = SASD_EdgeCompassSum_thresh;
            CurrScores.EdgeCost = SumSASDEdgeCost;
            CurrScores.SASD = iSumSASD;
            CurrScores.SASDDownAsPercent = (double)((int)iSumSASD)/((int)iSumSSE);

            StorValuesAsTxt.push_back(CurrScores);


            ptrDist_SSE[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = iSumSSE;
            ptrDist_SASD[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = iSumSASD;
            ptrbool_perfSASD[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = SASD_Grth_Threshold;
			
			delete SSEDiff;
			delete SASDDiff;
		}
        else if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
        {
            iSumSSE = ptrDist_SSE[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
            iSumSASD = ptrDist_SASD[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
            SASD_Grth_Threshold = ptrbool_perfSASD[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
        }
        
		yInt = yInt_Rec;

        int r, b, g;

        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) )
        {
            if (SASD_Grth_Threshold == true)
                imgFrmAsTxt[width * y + x] = ((int)iSumSSE+ (int)(iSumSASD));
            else
                imgFrmAsTxt[width * y + x] = (int)iSumSSE;
        }
        else
            imgFrmAsTxt[width * y + x] = -1;
        //-------------------------


        //  APC score will be between 0 and 127.
        // Dependent upon value apply different colour
        if (SASD_Grth_Threshold == true)
        {
            iSumHad = iSumSSE + iSumSASD;

			//------------------------------

			int loc = (int)log2((double)blkwidth) - 3;

			int maxUnscaled = (maxLimitSSE_k[loc] * NormDist_OneMin10k[m_distRange]);
			float maxScaled = (float)((float)maxUnscaled * (0.1024));

			Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor;

			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

									
//			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//				printf("SSE %d wSASD (with EdgeDetect) is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
			float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = ((double)normHad) > 1.0? (float)1.0 : normHad;

            int val =  ((double)normHad) < 0.25? 0 :
                       ((double)normHad) < 0.5? 1 :
                       ((double)normHad) < 0.75? 2 : 3;

			//------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
			switch (val)
			{
				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
					break;
				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
					break;
				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
					break;				
				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
					break;
			}
            //------------------

		}
		else
		{
			r = yInt; 
			g = yInt; 
			b = yInt; 
		}


		// Rec - Org
		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


		// Partitioning -- Not Working
		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
		{
		  r = 0; //yInt_RmO;
		  g = 0; //yInt_RmO;
		  b = 0; //yInt_RmO;
		}
		
		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  //piY += YStride;
	  piY_Org += YStride;
	  piY_Rec += YStrideRec;
	  piY_Part += YStrideRec;

	}

	free(ptrY_Org8x8);
	free(ptrY_Rec8x8);

	free(ptrY_Org);

	free(ptrY_Rec);

	free(ptrY_Part);

	//-----------------------

	if(m_outputSSIMHeatmaps)
	{
	  std::vector<unsigned char> png;

	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

	  //if there's an error, display it
	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
	}

   //-----------------------

    if (m_rawTextData)
    {
        //-------------------------
        // YGJ Thurs 28th May 2015
        // Output vector to txt file
        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
        ofstream DecFrmAsTxt;
        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
        {
            if ((i+1)%width==0)
                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
            else
                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
        }
        DecFrmAsTxt.close();
        //-------------------------


//        class StorValuesSSEwSASD
//        {
//        public:
//            int SSE;
//            int SASD;
//            //int SASDDownscale; //happens during calc
//            int AbsAsymCost;
//            int SideThreshold;
//            int EdgeThreshold;
//            int SASDThreshold;
//            int EdgeCost;
//            int MeanOrgLuma;
//            int MeanRecLuma;
//            double SASDDownAsPercent;
//        };

        ofstream DecValsAsTxt;
        DecValsAsTxt.open (ValAsTxt, ios::out | ios::app);

        DecValsAsTxt << "SSE, SASD, AbsAsymCost, SideThreshold, EdgeThreshold, SASDThreshold, EdgeCost, MeanOrgLuma, MeanRecLuma, SASDDownAsPercent" << endl ;

        //StorValuesAsTxt
        for (unsigned int i = 0; i< StorValuesAsTxt.size(); i ++)
        {

            if (StorValuesAsTxt[i].EdgeCost > StorValuesAsTxt[i].EdgeThreshold)
                DecValsAsTxt << StorValuesAsTxt[i].SSE << ", " << StorValuesAsTxt[i].SASD << ", " << StorValuesAsTxt[i].AbsAsymCost << ", "
                         << StorValuesAsTxt[i].SideThreshold << ", " << StorValuesAsTxt[i].EdgeThreshold << ", " << StorValuesAsTxt[i].SASDThreshold << ", "
                         << StorValuesAsTxt[i].EdgeCost << ", " << StorValuesAsTxt[i].MeanOrgLuma << ", " << StorValuesAsTxt[i].MeanRecLuma <<  ", "
                         << StorValuesAsTxt[i].SASDDownAsPercent << endl ;
        }

        DecValsAsTxt.close();



    }

}




//Void TAppDecTop::saveFrameAsPNG_SSEx_wSASD_wEdgeDetect_Log(TComPic* pcPic)
//{


//  // unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
//  // unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
//  // unsigned FrameRes = (height*width);

//  unsigned blkwidth = DistWidthSize(m_distWidthSize);
//  unsigned blksz = blkwidth*blkwidth;

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");


//    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
//    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
//    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
//    // YGJ 16th March 2015 - Block size can vary in SSE version.

//    int shiftby = (int)log2(blkwidth);
//    int downscaleby = (int)log2(blksz);

//    Distortion *ptrDist_SSE;   ptrDist_SSE = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_SSE == NULL)   printf("calloc failed\n");
//    Distortion *ptrDist_SASD;   ptrDist_SASD = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_SASD == NULL)   printf("calloc failed\n");
//    bool *ptrbool_perfSASD;   ptrbool_perfSASD = (bool *)calloc((FrameRes >> downscaleby), sizeof(bool));    if (ptrbool_perfSASD == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  char strpoc[6];
//  char strRange[8];

//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);

//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);

//  char strblkwidth[6];
//  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_SSE");
//  strcat(SSIMHeatmap, strblkwidth);
//  strcat(SSIMHeatmap, "wSASD_wEdgeDetect_HeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, ".png");

//  // YGJ Tues 26th May 2015
//  // Store the QP to text file
//  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile);
//  strcat(FrmAsTxt, "DecFrm_SSE");
//  strcat(FrmAsTxt, strblkwidth);
//  strcat(FrmAsTxt, "wSASD_wEdgeDetect_HeatMap_");
//  strcat(FrmAsTxt, strpoc);
//  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
//  strcat(FrmAsTxt, ".txt");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  // YGJ Thurs 28th May 2015
//  // Store the QP to array
//  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

//  unsigned MaxValue = (1<<bitDepthLuma)-1;
//    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//	for ( unsigned y = 0; y < height; y++ )
//	{
//	  for ( unsigned x = 0; x < width; x++ )
//	  {
//		unsigned yloc = y*width+x;

//		// allocate YUV value
//		int yInt = 0;

//		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//		int yInt_Org = (int)ptrY_Org[yloc];
//		int yInt_Rec = (int)ptrY_Rec[yloc];
//		int yInt_Part = (int)ptrY_Part[yloc];

//		// seems fine here
//		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
//			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

//        //bool SSERegion = false;
//		Distortion iSumHad =0;
//		Distortion iSumSSE =0;
//		Distortion iSumSASD =0;
//        bool SASD_Grth_Threshold = false;

//        //if ((y < (height-blkwidth)) && (x < (width-blkwidth)))

//        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
//        // YGJ 5th Jan 2014 - Every 8x8 block
//        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) && ((y % blkwidth == 0) && (x % blkwidth == 0)))
//		{
//          //SSERegion = true;


//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* SSEDiff = new int[blksz];
//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* SASDDiff = new int[blksz];

//			for ( unsigned n = 0; n < blkwidth; n++ )
//			{
//				for ( unsigned m = 0; m < blkwidth; m++ )
//				{
//					// y*width + x
//					unsigned yloc8x8 = n*blkwidth+m;

//					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//					////------------------
//					//// YGJ 12th July 2014
//					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
//					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//					//// a -- set up and initialise variables

//					////------------------

//					int Temp = y_Org - y_Rec;
//					int TempSq = shift == 0? LumaSq_LUT[abs(Temp)] : Temp*Temp;

//					SSEDiff[yloc8x8] = TempSq;

//					int OrgSq = shift == 0? LumaSq_LUT[y_Org] : y_Org*y_Org;
//					int RecSq=  shift == 0? LumaSq_LUT[y_Rec] : y_Rec*y_Rec;

//                    SASDDiff[yloc8x8] = (abs(abs(OrgSq-RecSq) - TempSq)) >> 8; // YGJ 14th April 2015 was applying downshift by 8 later not during SASD calc.


//				}
//			}

//            int i=0, j=0; //, jj;//, k;

//			for (i = 0; i < blkwidth; i++)
//			{
//			  for (j = 0; j < blkwidth; j++)
//			  {
//				iSumSSE += abs(SSEDiff[i+j*blkwidth]);
//				iSumSASD += abs(SASDDiff[i+j*blkwidth]);
//			  }
//			}

//            //----
//            // YGJ 13th Apr 2015
//            // Added AysBlkTest prior to block test within block.
//            //----

//            // Like in HadRC and in SAD/HAD apply perceptual cost to perceptual poor blocks (where 1-SSIM score is high)
//            // Edges minus corners

//            int Top = 0;
//            int Left = 0;
//            int Right = 0;
//            int Bottom = 0;

//            for (i = 1; i < blkwidth-1; i++)
//            {
//                Top += abs(SASDDiff[i]);
//                Left += abs(SASDDiff[i*blkwidth]);
//                Right += abs(SASDDiff[i*blkwidth+blkwidth-1]);
//                Bottom += abs(SASDDiff[blkwidth*(blkwidth-1)+i]);
//            }

//            // Approx Average. If 8x8, then 6 items read then divide by width, 8.
//            Top /= blkwidth;
//            Left /= blkwidth;
//            Right /= blkwidth;
//            Bottom /= blkwidth;

//            // From ::saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
//            UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

//            //YGJ 14th April 2015 - Having used the log from the decoder (CrowdRun 1, 4 and 16 Mbps (a single frame, frame 77), a threshold of >2 was deemed appropiate
//            // This should reduce where SASD is added to the SSE score.
//            UInt AsymBlkEdgeThresh = 2;

//            bool PerformIntBlkEdge = AbsAsymCost > AsymBlkEdgeThresh ? true : false;  // 16 Found to be highest point to at which most APC features are retained


//            //----

//            int SumSASDEdgeCost=0;

//            //----

//            // Currently only works for 8x8 and not for all block sizes
//            if (PerformIntBlkEdge == true)
//            {


//            SumSASDEdgeCost += ( (SASDDiff[9] << 1) - SASDDiff[8] - SASDDiff[1]) >  0 ? 1 : 0; // SE
//            SumSASDEdgeCost += ( (SASDDiff[3] << 1) - SASDDiff[2] - SASDDiff[11]) >  0 ? 1 : 0; //NE
//            SumSASDEdgeCost += ( (SASDDiff[24] << 1) - SASDDiff[25] - SASDDiff[16]) >  0 ? 1 : 0; // SW
//            SumSASDEdgeCost += ( (SASDDiff[18] << 1) - SASDDiff[19] - SASDDiff[26]) >  0 ? 1 : 0; // NW

//            SumSASDEdgeCost += ( (SASDDiff[13] << 1) - SASDDiff[12] - SASDDiff[5]) >  0 ? 1 : 0; // SE
//            SumSASDEdgeCost += ( (SASDDiff[7] << 1) - SASDDiff[6] - SASDDiff[15]) >  0 ? 1 : 0; //NE
//            SumSASDEdgeCost += ( (SASDDiff[28] << 1) - SASDDiff[29] - SASDDiff[20]) >  0 ? 1 : 0; // SW
//            SumSASDEdgeCost += ( (SASDDiff[22] << 1) - SASDDiff[23] - SASDDiff[30]) >  0 ? 1 : 0; // NW

//            SumSASDEdgeCost += ( (SASDDiff[41] << 1) - SASDDiff[40] - SASDDiff[33]) >  0 ? 1 : 0; // SE
//            SumSASDEdgeCost += ( (SASDDiff[35] << 1) - SASDDiff[34] - SASDDiff[43]) >  0 ? 1 : 0; //NE
//            SumSASDEdgeCost += ( (SASDDiff[56] << 1) - SASDDiff[57] - SASDDiff[48]) >  0 ? 1 : 0; // SW
//            SumSASDEdgeCost += ( (SASDDiff[50] << 1) - SASDDiff[51] - SASDDiff[58]) >  0 ? 1 : 0; // NW

//            SumSASDEdgeCost += ( (SASDDiff[45] << 1) - SASDDiff[44] - SASDDiff[37]) >  0 ? 1 : 0; // SE
//            SumSASDEdgeCost += ( (SASDDiff[39] << 1) - SASDDiff[38] - SASDDiff[47]) >  0 ? 1 : 0; //NE
//            SumSASDEdgeCost += ( (SASDDiff[60] << 1) - SASDDiff[61] - SASDDiff[52]) >  0 ? 1 : 0; // SW
//            SumSASDEdgeCost += ( (SASDDiff[54] << 1) - SASDDiff[55] - SASDDiff[62]) >  0 ? 1 : 0; // NW

//            }


//            // YGJ 11th Dec 2014 - Based upon recalc SASD from raw values for affected pixel of edge detect
//            // Median was 496, will approx to 512.
//            int threshold = 512;

//            int SASD_EdgeCompassSum_thresh = 8; // Based upon modeling of raw data, median was 8. Removed abs, keep it simple. ~1/6 obs affected


//            SASD_Grth_Threshold = (SumSASDEdgeCost > SASD_EdgeCompassSum_thresh) && (iSumSASD > threshold) ? true : false;
//            iSumSASD >>= 1;


//            ptrDist_SSE[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = iSumSSE;
//            ptrDist_SASD[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = iSumSASD;
//            ptrbool_perfSASD[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)] = SASD_Grth_Threshold;

//			delete SSEDiff;
//			delete SASDDiff;
//		}
//        else if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
//        {

//            iSumSSE = ptrDist_SSE[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
//            iSumSASD = ptrDist_SASD[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];
//            SASD_Grth_Threshold = ptrbool_perfSASD[(x >> shiftby) + (y >> shiftby)*(width>>shiftby)];

//        }

//		yInt = yInt_Rec;

//        int r, b, g;

//        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) )
//        {
//            if (SASD_Grth_Threshold == true)
//                imgFrmAsTxt[width * y + x] = ((int)iSumSSE+ (int)(iSumSASD));
//            else
//                imgFrmAsTxt[width * y + x] = (int)iSumSSE;
//        }
//        else
//            imgFrmAsTxt[width * y + x] = -1;
//        //-------------------------


//        //  APC score will be between 0 and 127.
//        // Dependent upon value apply different colour
//        if (SASD_Grth_Threshold == true)
//        {
//            iSumHad = iSumSSE + iSumSASD;

//			//------------------------------

//			int loc = (int)log2((double)blkwidth) - 3;

//			int maxUnscaled = (maxLimitSSE_k[loc] * NormDist_OneMin10k[m_distRange]);
//			float maxScaled = (float)((float)maxUnscaled * (0.1024));

//			Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor;

//			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;


////			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
////				printf("SSE %d wSASD (with EdgeDetect) is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
////				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);

//			float normHad = ((float)dist)/((float)halfMaxThreshold);

//            // YGJ 15th March 2015
//            // Use 1/2 max based normalised value
//            // Based on normJND

//            normHad = ((double)normHad) > 1.0? 1.0 : normHad;

//            int val =  ((double)normHad) < 0.25? 0 :
//                       ((double)normHad) < 0.5? 1 :
//                       ((double)normHad) < 0.75? 2 : 3;

//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------

//		}
//		else
//		{
//			r = yInt;
//			g = yInt;
//			b = yInt;
//		}


//		// Rec - Org
//		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//		// Partitioning -- Not Working
//		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//		{
//		  r = 0; //yInt_RmO;
//		  g = 0; //yInt_RmO;
//		  b = 0; //yInt_RmO;
//		}

//		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//	  }
//	  //piY += YStride;
//	  piY_Org += YStride;
//	  piY_Rec += YStrideRec;
//	  piY_Part += YStrideRec;

//	}

//	free(ptrY_Org8x8);
//	free(ptrY_Rec8x8);

//	free(ptrY_Org);

//	free(ptrY_Rec);

//	free(ptrY_Part);

//	//-----------------------

//	if(m_outputSSIMHeatmaps)
//	{
//	  std::vector<unsigned char> png;

//	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//	  //if there's an error, display it
//	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//	}

//   //-----------------------

//    if (m_rawTextData)
//    {
//        //-------------------------
//        // YGJ Thurs 28th May 2015
//        // Output vector to txt file
//        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
//        ofstream DecFrmAsTxt;
//        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
//        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
//        {
//            if ((i+1)%width==0)
//                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
//            else
//                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
//        }
//        DecFrmAsTxt.close();
//        //-------------------------
//    }

//}



// YGJ 12th July 2015
// Storing values via custom structure
// RC Had, APCms, APCmsDownscale, AbsAsymCost, Thresh(48), EdgeCount
//struct StorValues

class StorValues
{
public:
    int RCHad;
    int APCms;
    int APCmsDownscale;
    int AbsAsymCost;
    int Threshold;
    int EdgeCost;
    int MeanLuma;
    double APCmsDownAsPercent;
};


//Void TAppDecTop::saveFrameAsPNG_AlwaysTrue_RCHadPreAssess_wEdgeScaledMS_APC(TComPic* pcPic)
//{

//  // unsigned height = m_iSourceHeight;
////   unsigned width = m_iSourceWidth;
//  // unsigned FrameRes = (height*width);

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  // Decode order from reading from YUV file.

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//  Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");

//  // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
//  // Store values for when at the start of 8x8 and recalled for when within 8x8 block
//  Distortion *ptrDist_Had;   ptrDist_Had = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_Had == NULL)   printf("calloc failed\n");
//  Distortion *ptrDist_APCms;   ptrDist_APCms = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_APCms == NULL)   printf("calloc failed\n");
//  bool *ptrbool_perfAPCms;   ptrbool_perfAPCms = (bool *)calloc((FrameRes >> 6), sizeof(bool));    if (ptrbool_perfAPCms == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  char strpoc[6];
//  char strRange[8];

//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);

//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);

//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_AlwaysTrue_RCActivity_PreAssess_wCornerTestwEdgeScale_MSAPCHadActiHeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, ".png");

//  // YGJ Tues 26th May 2015
//  // Store the QP to text file
//  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile);
//  strcat(FrmAsTxt, "DecFrm_AlwaysTrue_RCActivity_PreAssess_wCornerTestwEdgeScale_MSAPCHadActiHeatMap_");
//  strcat(FrmAsTxt, strpoc);
//  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
//  strcat(FrmAsTxt, ".txt");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);
//  // YGJ Thurs 28th May 2015
//  // Store the QP to array
//  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);


//  // YGJ 12th July 2015
//  char ValAsTxt[255];  strcpy(ValAsTxt, m_pchSSIMLogAndImageFile);
//  strcat(ValAsTxt, "DecVal_AlwaysTrue_RCActivity_PreAssess_wCornerTestwEdgeScale_MSAPCHadActiHeatMap_");
//  strcat(ValAsTxt, strpoc);
//  strcat(ValAsTxt, "_Range");  strcat(ValAsTxt, strRange);
//  strcat(ValAsTxt, ".txt");

////  // YGJ 12th July 2015
////  // Storing values via custom structure
////  // RC Had, APCms, APCmsDownscale, AbsAsymCost, Thresh(48), EdgeCount
////  struct StorValues
////  {
////      int RCHad;
////      int APCms;
////      int APCmsDownscale;
////      int AbsAsymCost;
////      int Threshold;
////      int EdgeCost;
////      int MeanLuma;
////      double APCmsDownAsPercent;
////  };
//  // Now store in vector form every 8x8 in FrameRes
//  std::vector<StorValues> StorValuesAsTxt; StorValuesAsTxt.resize(FrameRes >> 6);

//  StorValues CurrScores;

//  // Edge count
//  int count = 0;

//  UInt Threshold = 48; //28; // Does a threshold of 28 sufficient as 16?
//  UInt AbsAsymCost = 0;

//  unsigned MaxValue = (1<<bitDepthLuma)-1;
//    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//    //////////////////////////
//    // YGJ 5th Jan 2015
//    // Non-Overlapping 8x8, to be more like Rate Control
//    // Save as previous values

//    for ( unsigned y = 0; y < height; y++ )
//    {
//      for ( unsigned x = 0; x < width; x++ )
//      {
//        unsigned yloc = y*width+x;

//        // allocate YUV value
//        int yInt = 0;

//        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//        int yInt_Org = (int)ptrY_Org[yloc];
//        int yInt_Part = (int)ptrY_Part[yloc];

//        // seems fine here
//        if (yInt_Org > 255 || yInt_Org < 0) // || yInt_Rec > 255 || yInt_Rec < 0)
//            printf("Out of range pixel value, yInt_Org, %d \n", yInt_Org); //, yInt_Rec);


//        Distortion iSumHad =0;
//        Distortion iSumHadAPC = 0;
//        bool PerformMsAPC = false;

//        Pel *diff;
//        int i, j, jj, k;
//        //int blksz = 64;
//        //Int SumAPCmsEdgeCost = 0; // Does not match Encoder


//        // YGJ 5th Jan 2014 - Every 8x8 block
//        if ((y < (height-8)) && (x < (width-8)) && ((y % 8 == 0) && (x % 8 == 0)))
//        {
//           // YGJ 12th July 2015 - Reset values
//           CurrScores.RCHad = 0;
//           CurrScores.APCms = 0;
//           CurrScores.APCmsDownscale = 0;
//           CurrScores.Threshold = 0; // Should be 48
//           CurrScores.EdgeCost = 0;
//           CurrScores.MeanLuma = 0;
//           CurrScores.APCmsDownAsPercent = 0.0;

//          //HadRegion = true;

////          Distortion diff[64];
//          TCoeff m1[8][8], m2[8][8], m3[8][8];
//          Int m1APC[8][8], m2APC[8][8], m3APC[8][8]; //, iSumHadAPC = 0; //, iSumAPCms = 0;
//          Int multiscaleAPC[64]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.


//            for ( unsigned n = 0; n < 8; n++ )
//            {
//                for ( unsigned m = 0; m < 8; m++ )
//                {
//                    unsigned yloc8x8 = n*m+m;

//                    CurrScores.MeanLuma += ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);

//                }
//            }

//            // Calc Mean
//            CurrScores.MeanLuma >>= 6;

//            diff = ptrY_Org8x8;

//            //-------------------------

//            // YGJ Sun 24th Aug 2014 - Pre Assessment to determine whether multi-scale APC is justified
//            // Calc APC for Top, Bottom, Left and Right side of 8x8 (First and Last Row and Columns)
//            // Note that APC is calculated by accessing the Look Up Table (LUT).
//            // While in SAD, APC can be accumulated then divided by 2, here the LUT used, (APC_NegAndPos_1D) via the function (RCHadAPC) has the values already divided by 2.
//            // However, in multi-scale APC they must be divided by their interval, which APC_NegAndPos_1D will perform by entering the number bits to shift by.
//            //
//            // Multi-scale APC does require significant amount of processing.
//            // Under rate-control this will occur when a new Group of Pictures (GOP) sequence requires the bit-rate to be budgetted by frame/slice type.
//            // Regardless, applying multi-scale APC irrespectively, can increase processing demand unnecessarily.
//            // Also, hadamard transform employs symmetry to elminate/minimise accumulated differences.
//            // Applying a test for asymmetrical perceptual changes can then differieniate when multi-scale is suitable to apply and limiting the use of additional complexity till then.
//            //
//            // A non-symmetrical distribution of two regions in a block can affect the percpetual rate of change along one of the edges of the block.
//            // By subtracting opposing edges from each other any dominant edge, where the perceptual rate of change is far higher than the others will be shown.
//            // The threshold by which the resulting value should tested against should be the block size, in this case, 8x8 = 64.
//            // If (abs(abs(T-B) - abs(L-R)) > 64
//            // In general, this should make the processing more adaptive/dynamic, only applying multi-scale APC  according to the level of asymmetric boundary changes where the intensity (Luma) is high.
//            // Expect processing demand to vary depending upon the scene in question.
//            // Based upon simulations based observations gathered from the first frame of Race Horses video (416 x 240) where 1560 samples are processed, one per 8x8 block region, the need to called multi-scale APC can be reduced by 2/3.

//            //----

//            // First calc Horizontal
//            // For Top and Left this their initial cost (stage 1 of 2).
//            // For Bottom it is the only time it will be updated (1 of 1).
//            // For Right it will be set during vertical (0 of 1).

//            //-----

//            //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
//            //H/V: x, 1/8, 1/4, 1/2
//            // H: 0: (0,4),(0,2),(0,1)
//            // H: 1: (1,5),(1,3),--
//            // H: 2: (2,6),--, (2,3)
//            // H: 3: (3,7),--,--
//            // H: 4: --,(4,6),(4,5)
//            // H: 5: --,(5,7),--
//            // H: 6: --,--,(6,7)
//            // H:7: Always  Zero

//            // This means for Top and Bottom the above is correct.
//            // For  Left    // H: 0: (0,4),(0,2),(0,1) needs to be performed.
//            // For Right as stated it is // H:7: Always  Zero

//            //-----

//            // Second  calc Vertical
//            // Like Horizontal but now for the others are updated/completed.
//            // Top and Left are completed
//            // Right is updated.

//            //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
//            //H/V: x, 1/8, 1/4, 1/2
//            // V: 0: (0,4),(0,2),(0,1)
//            // V: 1: (1,5),(1,3),--
//            // V: 2: (2,6),--, (2,3)
//            // V: 3: (3,7),--,--
//            // V: 4: --,(4,6),(4,5)
//            // V: 5: --,(5,7),--
//            // V: 6: --,--,(6,7)
//            // V:7: Always  Zero

//            // For Left and Right the above is correct
//            // Top -  // V: 0: (0,4),(0,2),(0,1)
//            // Bottom - // V:7: Always  Zero

//            //-----

//            // Now to check if full multi-scale APC is required of Hadamard is sufficient
//            // If (abs(abs(Top-Bottom) - abs(Left-Right)) > 64 then perform multii-scale APC.
//            // Multi-scale APC has a high score where boundary changes occur where  Luma intensity is high.
//            // Hadamard is suited for where symmetrical differences exist.
//            // Thus, multi-scale APC is suited for where asymmetric boundary changes occur for high Luma 8x8 blocks.
//            // It is possible that the top left corner pixel can strongly influence both Top and Left.
//            // To avoid the top left corner pixel affecting the scores, the test for full multi-scale APC is a series of differences.
//            // Furthermore, the threshold of 64 is sufficiently low enough to allow a range of potential candidates for the full multi-scale APC.

//            //---------------

//            // YGJ Wed 27th Aug 2014
//            // Pre-Assessment Test for multi-scale APC
//            // Just the sides without corners.
//            // Assuming perceptual information is continuous and may cross over blocksizes.
//            // If the change on the edges are high then they is likley asymmetric change in the block.
//            // For Hadamard symmetry is used to cancel accumulated differences.
//            // While asymmetric differences do not cancel out.
//            // This means APC on Had is best applied when asymmetric changes are high
//            // The use of this Pre-Assessment is devised to initially detect if asymmetric differences exist.
//            // If not the remaining process reverts back to the existing Hadamard method.
//            // The proposed method is expected to applible about 10% of the time, though this will vary depending upon video/frame content.

//            // Distance
//            int dist4 = 5; // 1/32 * 1/2  = 1/64  - This avoids making the change very extreme
//            int dist2 = 3; // 1/8 * 1/2 = 1/16 - This is used as a half-way point.
//            int dist1 = 0; // 1/2  = 1/2  - Must be zero as APC has already been halved. Also most crucial value

//            //int TopLeftPx = 0;  // Shared by Left and Top
//            int Top = 0, Left = 0;

//              // Ignore Corner, this leaves 1-6

//            Top += multiscaleAPC[1] = TComRdCost::RCHadAPC((int)diff[1], (int)diff[5], dist4) + TComRdCost::RCHadAPC((int)diff[1], (int)diff[3], dist2);
//            Top += multiscaleAPC[2] = TComRdCost::RCHadAPC((int)diff[2], (int)diff[6], dist4) + TComRdCost::RCHadAPC((int)diff[2], (int)diff[3], dist1);
//            Top += multiscaleAPC[3] = TComRdCost::RCHadAPC((int)diff[3], (int)diff[7], dist4);
//            Top += multiscaleAPC[4] = TComRdCost::RCHadAPC((int)diff[4], (int)diff[6], dist2) + TComRdCost::RCHadAPC((int)diff[4], (int)diff[5], dist1);
//            Top += multiscaleAPC[5] = TComRdCost::RCHadAPC((int)diff[5], (int)diff[7], dist2);
//            Top += multiscaleAPC[6] = TComRdCost::RCHadAPC((int)diff[6], (int)diff[7], dist1);
//            //---


//          // Since the first row (0) is done, and the last row (56) will be done later, just do the intervening rows (8, 16, 32, 40, 48)
//          for( k = 8; k < 56; k += 8 )
//          {
//            Left += multiscaleAPC[k] = TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+4], dist4)
//                                    +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+2], dist2)
//                                    +   TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+1], dist1);
//          }

//          //int BottomLeft = 0; // Shared by Left and Bottom
//          int Bottom = 0;
//          //---

//          // Ignore Corner, this leaves 57-62

//          Bottom += multiscaleAPC[57] = TComRdCost::RCHadAPC((int)diff[57], (int)diff[61], dist4) + TComRdCost::RCHadAPC((int)diff[57], (int)diff[59], dist2);
//          Bottom += multiscaleAPC[58] = TComRdCost::RCHadAPC((int)diff[58], (int)diff[62], dist4) + TComRdCost::RCHadAPC((int)diff[58], (int)diff[59], dist1);
//          Bottom += multiscaleAPC[59] = TComRdCost::RCHadAPC((int)diff[59], (int)diff[63], dist4);
//          Bottom += multiscaleAPC[60] = TComRdCost::RCHadAPC((int)diff[60], (int)diff[62], dist2) + TComRdCost::RCHadAPC((int)diff[60], (int)diff[61], dist1);
//          Bottom += multiscaleAPC[61] = TComRdCost::RCHadAPC((int)diff[61], (int)diff[63], dist2);
//          Bottom += multiscaleAPC[62] = TComRdCost::RCHadAPC((int)diff[62], (int)diff[63], dist1);

//          //---

//          // ----------
//          // Vertical

//        //  //---

//          // Ignore Corner, this leaves 8, 16, 24, 32, 40, 48

//          int iTemp;

//          iTemp = TComRdCost::RCHadAPC((int)diff[8], (int)diff[40], dist4)  + TComRdCost::RCHadAPC((int)diff[8], (int)diff[24], dist2);  Left += iTemp; multiscaleAPC[8] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[16], (int)diff[48], dist4) + TComRdCost::RCHadAPC((int)diff[16], (int)diff[24], dist1); Left += iTemp; multiscaleAPC[16] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[24], (int)diff[56], dist4);                                               Left += iTemp; multiscaleAPC[24] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[32], (int)diff[48], dist2) + TComRdCost::RCHadAPC((int)diff[32], (int)diff[40], dist1); Left += iTemp; multiscaleAPC[32] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[40], (int)diff[56], dist2);                                               Left += iTemp; multiscaleAPC[40] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[48], (int)diff[56], dist1);                                               Left += iTemp; multiscaleAPC[48] += iTemp;

//          //---

//          // Similar to before since the top left (0) has been calc for Left and top right (7) will be calc afterwards for Right only those in between need to be calc. (1- 6)
//          for( k = 1; k < 7; k++ )
//          {
//            iTemp = TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+32], dist4)
//                 +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+16], dist2)
//                 +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+8], dist1);

//            Top += iTemp; multiscaleAPC[k] += iTemp;
//          }

//          //---

//          int Right = 0;

//          // Ignore Corner, this leaves 15, 23, 31, 39, 47, 55
//          Right += multiscaleAPC[15] =  TComRdCost::RCHadAPC((int)diff[15], (int)diff[47], dist4) +  TComRdCost::RCHadAPC((int)diff[15], (int)diff[31], dist2);
//          Right += multiscaleAPC[23] =  TComRdCost::RCHadAPC((int)diff[23], (int)diff[55], dist4) +  TComRdCost::RCHadAPC((int)diff[23], (int)diff[31], dist1);
//          Right += multiscaleAPC[31] =  TComRdCost::RCHadAPC((int)diff[31], (int)diff[63], dist4);
//          Right += multiscaleAPC[39] =  TComRdCost::RCHadAPC((int)diff[39], (int)diff[55], dist2) +  TComRdCost::RCHadAPC((int)diff[39], (int)diff[47], dist1);
//          Right += multiscaleAPC[47] =  TComRdCost::RCHadAPC((int)diff[47], (int)diff[63], dist2);
//          Right += multiscaleAPC[55] =  TComRdCost::RCHadAPC((int)diff[55], (int)diff[63], dist1);
//          //---
//            //-------------------------
//            // Now to Test if the full multi-scale APC is required or not

//            //bool PerformMsAPC = abs(abs(Top-Bottom) - abs(Left-Right)) > 64 ? true : false;

//            // Step 2) Calc whether abs(abs(T-B)-abs(L-R)) is greater than the threshold.

//            //UInt
//            AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

//            // Sun 23rd Nov 2014
//            // Having analysed log calculated values the median value for AbsAsymCost was 48 for APC Multiscale (used in Had and RC Had).
//            // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
//            // Over 48 million observations were logged, which represented 8.7 million unique records.
//            //UInt Threshold = 48; //28; // Does a threshold of 28 sufficient as 16?

//            PerformMsAPC = true; //AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

//            switch(PerformMsAPC)
//            {

//                case true:
//                {

//                //Now the corners

//                  //---
//                  // Top Left (Horizontal and Vertical)
//                  multiscaleAPC[0] = TComRdCost::RCHadAPC((int)diff[0], (int)diff[4], dist4)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[2], dist2)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[1], dist1)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[32], dist4)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[16], dist2)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[8], dist1);

//                  // Bottom Left only has Horizontal components only
//                  multiscaleAPC[56] = TComRdCost::RCHadAPC((int)diff[56], (int)diff[60], dist4)
//                                    + TComRdCost::RCHadAPC((int)diff[56], (int)diff[58], dist2)
//                                    + TComRdCost::RCHadAPC((int)diff[56], (int)diff[57], dist1);


//                  // Top Right only has Vertical components only
//                  multiscaleAPC[7] = TComRdCost::RCHadAPC((int)diff[7], (int)diff[39], dist4)
//                                   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[23], dist2)
//                                   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[15], dist1);

//                  // Bottom Right has no components
//                  multiscaleAPC[63] = 0; // Always Zero
//                //-------------------------

//////                  // YGJ 3rd Dec 2014
//////                  // Based upon unpublished edge detection of by Myo. Modified to make it efficient and adapted for use here.
//////                  // 2 times corner minus averaged adjacent sides, in this case approximate average, should be div by 6 but using divide by 8.
//////                  // From modelling done in R this should reduce the no. of obs by ~1/2, focusing more on the ones with higher Had and 1-SSIM scores.
//////                  // Modelling showed that corner test should occur after thresholding, not before or alone.
//////                  // This approach is the most effective at shifting and broadening the peak in Had away from zero.
//////                  // From 30k sampled observations, 7k were affected, approx 23%.
//////                  // In R threshold was 32, divide was done by 6 and count min was >1.
//////                  // Here it is the same except that divide is 8.
//////                  // When modelled

//                  //count = 0;

//                  count =  ((abs(multiscaleAPC[0]) << 1) - ((abs(Top) +  abs(Left)) >> 3)) > 0 ? 1 : 0;
//                  count +=  ((abs(multiscaleAPC[7]) << 1) - ((abs(Top) +  abs(Right)) >> 3)) > 0 ? 1 : 0;
//                  count +=  ((abs(multiscaleAPC[56]) << 1) - ((abs(Bottom) +  abs(Left)) >> 3)) > 0 ? 1 : 0;

//                  PerformMsAPC = true; // count > 1? true: false;

//                }

//            }

//            // YGJ 10th July 2015 - Does not match encoder, disabling this section.
//            // Can not justify additional complexity per 8x8 block?
//            // Will need to test to see the difference

////            switch(PerformMsAPC)
////            {

////                case true:
////                {
////                  // Monday 5th January 2015

////                  // Edge Detect on APCms, similar to Edfge on SASD calc percetual importance of activity
////                  // Then the sum of the edges should be used to produced a weighted APCms score to add to the Had cost

////                  // At this point check for edges on APCms block.
////                  SumAPCmsEdgeCost += ( (multiscaleAPC[9] << 1) - multiscaleAPC[8] - multiscaleAPC[1]) >  0 ? 1 : 0; // SE
////                  SumAPCmsEdgeCost += ( (multiscaleAPC[3] << 1) - multiscaleAPC[2] - multiscaleAPC[11]) >  0 ? 1 : 0; //NE
////                  SumAPCmsEdgeCost += ( (multiscaleAPC[24] << 1) - multiscaleAPC[25] - multiscaleAPC[16]) >  0 ? 1 : 0; // SW
////                  SumAPCmsEdgeCost += ( (multiscaleAPC[18] << 1) - multiscaleAPC[19] - multiscaleAPC[26]) >  0 ? 1 : 0; // NW

////                  SumAPCmsEdgeCost += ( (multiscaleAPC[13] << 1) - multiscaleAPC[12] - multiscaleAPC[5]) >  0 ? 1 : 0; // SE
////                  SumAPCmsEdgeCost += ( (multiscaleAPC[7] << 1) - multiscaleAPC[6] - multiscaleAPC[15]) >  0 ? 1 : 0; //NE
////                  SumAPCmsEdgeCost += ( (multiscaleAPC[28] << 1) - multiscaleAPC[29] - multiscaleAPC[20]) >  0 ? 1 : 0; // SW
////                  SumAPCmsEdgeCost += ( (multiscaleAPC[22] << 1) - multiscaleAPC[23] - multiscaleAPC[30]) >  0 ? 1 : 0; // NW

////                  SumAPCmsEdgeCost += ( (multiscaleAPC[41] << 1) - multiscaleAPC[40] - multiscaleAPC[33]) >  0 ? 1 : 0; // SE
////                  SumAPCmsEdgeCost += ( (multiscaleAPC[35] << 1) - multiscaleAPC[34] - multiscaleAPC[43]) >  0 ? 1 : 0; //NE
////                  SumAPCmsEdgeCost += ( (multiscaleAPC[56] << 1) - multiscaleAPC[57] - multiscaleAPC[48]) >  0 ? 1 : 0; // SW
////                  SumAPCmsEdgeCost += ( (multiscaleAPC[50] << 1) - multiscaleAPC[51] - multiscaleAPC[58]) >  0 ? 1 : 0; // NW

////                  SumAPCmsEdgeCost += ( (multiscaleAPC[45] << 1) - multiscaleAPC[44] - multiscaleAPC[37]) >  0 ? 1 : 0; // SE
////                  SumAPCmsEdgeCost += ( (multiscaleAPC[39] << 1) - multiscaleAPC[38] - multiscaleAPC[47]) >  0 ? 1 : 0; //NE
////                  SumAPCmsEdgeCost += ( (multiscaleAPC[60] << 1) - multiscaleAPC[61] - multiscaleAPC[52]) >  0 ? 1 : 0; // SW
////                  SumAPCmsEdgeCost += ( (multiscaleAPC[54] << 1) - multiscaleAPC[55] - multiscaleAPC[62]) >  0 ? 1 : 0; // NW

////                  PerformMsAPC = SumAPCmsEdgeCost > 4? true: false; // Triggers on nearly everything

////                }

////            }


//            int *ptrAPCDiff;

//            switch(PerformMsAPC)
//            {

//            case true:
//                {
//                    //-------------------------
//                    // YGJ Fri 22nd Aug 2014 - Since the jump between pixels is 4 and APC is divided by 2 by default then the APC score should be divided by (4*2), 8, shift by 3.
//                    // Since APC LUT violates SSIM and other existing distortion measures use of symmetry, where pixel x vs y is the same as pixel y vs x, choice of which is the reference is important.
//                    // Use max for the two pixels to determine the reference point.

//                    // YGJ Sat 23rd Aug 2014 - MulitScaled APC Prior to Hadamard - accumulates the various weighted APC/2 scores by different intervals
//                    // APC/2, if space of 4, div by 4, if space of 2, div by 2, if space of 1, div by 1.
//                    // Repeat for Vertical and then accumulate.
//                    // When being used H1, div APC by 8.

//                    // Wrong (ignore)-> Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
//                    // YGJ Wed 27th Aug 2014 - Correction: RCHadAPC divides by two before it returns the value, just divide by the spacing 4, 2 or 1.
//                    //H/V: x, 1/64, 1/16, 1/2
//                    // H: 0: (0,4),(0,2),(0,1)
//                    // H: 1: (1,5),(1,3),--
//                    // H: 2: (2,6),--, (2,3)
//                    // H: 3: (3,7),--,--
//                    // H: 4: --,(4,6),(4,5)
//                    // H: 5: --,(5,7),--
//                    // H: 6: --,--,(6,7)
//                    // H:7: Always  Zero

//                    // First the inner square (block without the edges or corners)

//                // Horizontal
//                for( k = 8; k < 56; k += 8 )
//                {
//                  multiscaleAPC[k+1] = TComRdCost::RCHadAPC((int)diff[k+1], (int)diff[k+5], dist4) + TComRdCost::RCHadAPC((int)diff[k+1], (int)diff[k+3], dist2);
//                  multiscaleAPC[k+2] = TComRdCost::RCHadAPC((int)diff[k+2], (int)diff[k+6], dist4) + TComRdCost::RCHadAPC((int)diff[k+2], (int)diff[k+3], dist1);
//                  multiscaleAPC[k+3] = TComRdCost::RCHadAPC((int)diff[k+3], (int)diff[k+7], dist4);
//                  multiscaleAPC[k+4] = TComRdCost::RCHadAPC((int)diff[k+4], (int)diff[k+6], dist2) +  TComRdCost::RCHadAPC((int)diff[k+4], (int)diff[k+5], dist1);
//                  multiscaleAPC[k+5] = TComRdCost::RCHadAPC((int)diff[k+5], (int)diff[k+7], dist2);
//                  multiscaleAPC[k+6] = TComRdCost::RCHadAPC((int)diff[k+6], (int)diff[k+7], dist1);
//                }

//                //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
//                //H/V: x, 1/8, 1/4, 1/2
//                // V: 0: (0,4),(0,2),(0,1)
//                // V: 1: (1,5),(1,3),--
//                // V: 2: (2,6),--, (2,3)
//                // V: 3: (3,7),--,--
//                // V: 4: --,(4,6),(4,5)
//                // V: 5: --,(5,7),--
//                // V: 6: --,--,(6,7)
//                // V:7: Always  Zero

//                // Vertical
//                // Same as Horizontal but now k is from 0 to 7 and k+1/2/3/4/5/6/7 are now k+(1/2/3/4/5/6/7 x 8)
//                // Hence it is the same as Horizontal but rotated

//                // Remember to increment and not assign/replace existing value

//                for( k = 1; k < 7; k++ )
//                {
//                  multiscaleAPC[k+8] += TComRdCost::RCHadAPC((int)diff[k+8], (int)diff[k+40], dist4) + TComRdCost::RCHadAPC((int)diff[k+8], (int)diff[k+24], dist2);
//                  multiscaleAPC[k+16] += TComRdCost::RCHadAPC((int)diff[k+16], (int)diff[k+48], dist4) + TComRdCost::RCHadAPC((int)diff[k+16], (int)diff[k+24], dist1);
//                  multiscaleAPC[k+24] += TComRdCost::RCHadAPC((int)diff[k+24], (int)diff[k+56], dist4);
//                  multiscaleAPC[k+32] += TComRdCost::RCHadAPC((int)diff[k+32], (int)diff[k+48], dist2) + TComRdCost::RCHadAPC((int)diff[k+32], (int)diff[k+40], dist1);
//                  multiscaleAPC[k+40] += TComRdCost::RCHadAPC((int)diff[k+40], (int)diff[k+56], dist2);
//                  multiscaleAPC[k+48] += TComRdCost::RCHadAPC((int)diff[k+48], (int)diff[k+56], dist1);
//                }

//                //----
//              ptrAPCDiff = multiscaleAPC;

//              }
//              break; // End of (if (PerformMsAPC = true))
//            }


//            //horizontal
//            for (j=0; j < 8; j++)
//            {
//              jj = j << 3;


//              m2[j][0] = diff[jj  ] + diff[jj+4];
//              m2[j][1] = diff[jj+1] + diff[jj+5];
//              m2[j][2] = diff[jj+2] + diff[jj+6];
//              m2[j][3] = diff[jj+3] + diff[jj+7];
//              m2[j][4] = diff[jj  ] - diff[jj+4];
//              m2[j][5] = diff[jj+1] - diff[jj+5];
//              m2[j][6] = diff[jj+2] - diff[jj+6];
//              m2[j][7] = diff[jj+3] - diff[jj+7];


//              m1[j][0] = m2[j][0] + m2[j][2];
//              m1[j][1] = m2[j][1] + m2[j][3];
//              m1[j][2] = m2[j][0] - m2[j][2];
//              m1[j][3] = m2[j][1] - m2[j][3];
//              m1[j][4] = m2[j][4] + m2[j][6];
//              m1[j][5] = m2[j][5] + m2[j][7];
//              m1[j][6] = m2[j][4] - m2[j][6];
//              m1[j][7] = m2[j][5] - m2[j][7];

//              m2[j][0] = m1[j][0] + m1[j][1];
//              m2[j][1] = m1[j][0] - m1[j][1];
//              m2[j][2] = m1[j][2] + m1[j][3];
//              m2[j][3] = m1[j][2] - m1[j][3];
//              m2[j][4] = m1[j][4] + m1[j][5];
//              m2[j][5] = m1[j][4] - m1[j][5];
//              m2[j][6] = m1[j][6] + m1[j][7];
//              m2[j][7] = m1[j][6] - m1[j][7];

//              //---------------------
//              // Now for Had on APC
//              switch(PerformMsAPC)
//              {
//              case true:
//                      {

//                      m2APC[j][0] = ptrAPCDiff[jj  ] ;
//                      m2APC[j][1] = ptrAPCDiff[jj+1] ;
//                      m2APC[j][2] = ptrAPCDiff[jj+2] ;
//                      m2APC[j][3] = ptrAPCDiff[jj+3] ;
//                      m2APC[j][4] = - (ptrAPCDiff[jj+4] );
//                      m2APC[j][5] = - (ptrAPCDiff[jj+5] );
//                      m2APC[j][6] = - (ptrAPCDiff[jj+6] );
//                      m2APC[j][7] = - (ptrAPCDiff[jj+7] );

//                      m1APC[j][0] = m2APC[j][0] + m2APC[j][2];
//                      m1APC[j][1] = m2APC[j][1] + m2APC[j][3];
//                      m1APC[j][2] = m2APC[j][0] - m2APC[j][2];
//                      m1APC[j][3] = m2APC[j][1] - m2APC[j][3];
//                      m1APC[j][4] = m2APC[j][4] + m2APC[j][6];
//                      m1APC[j][5] = m2APC[j][5] + m2APC[j][7];
//                      m1APC[j][6] = m2APC[j][4] - m2APC[j][6];
//                      m1APC[j][7] = m2APC[j][5] - m2APC[j][7];

//                      m2APC[j][0] = m1APC[j][0] + m1APC[j][1];
//                      m2APC[j][1] = m1APC[j][0] - m1APC[j][1];
//                      m2APC[j][2] = m1APC[j][2] + m1APC[j][3];
//                      m2APC[j][3] = m1APC[j][2] - m1APC[j][3];
//                      m2APC[j][4] = m1APC[j][4] + m1APC[j][5];
//                      m2APC[j][5] = m1APC[j][4] - m1APC[j][5];
//                      m2APC[j][6] = m1APC[j][6] + m1APC[j][7];
//                      m2APC[j][7] = m1APC[j][6] - m1APC[j][7];

//                      }
//              }

//            }

//            //vertical
//            for (i=0; i < 8; i++)
//            {
//              m3[0][i] = m2[0][i] + m2[4][i];
//              m3[1][i] = m2[1][i] + m2[5][i];
//              m3[2][i] = m2[2][i] + m2[6][i];
//              m3[3][i] = m2[3][i] + m2[7][i];
//              m3[4][i] = m2[0][i] - m2[4][i];
//              m3[5][i] = m2[1][i] - m2[5][i];
//              m3[6][i] = m2[2][i] - m2[6][i];
//              m3[7][i] = m2[3][i] - m2[7][i];

//              m1[0][i] = m3[0][i] + m3[2][i];
//              m1[1][i] = m3[1][i] + m3[3][i];
//              m1[2][i] = m3[0][i] - m3[2][i];
//              m1[3][i] = m3[1][i] - m3[3][i];
//              m1[4][i] = m3[4][i] + m3[6][i];
//              m1[5][i] = m3[5][i] + m3[7][i];
//              m1[6][i] = m3[4][i] - m3[6][i];
//              m1[7][i] = m3[5][i] - m3[7][i];

//              m2[0][i] = m1[0][i] + m1[1][i];
//              m2[1][i] = m1[0][i] - m1[1][i];
//              m2[2][i] = m1[2][i] + m1[3][i];
//              m2[3][i] = m1[2][i] - m1[3][i];
//              m2[4][i] = m1[4][i] + m1[5][i];
//              m2[5][i] = m1[4][i] - m1[5][i];
//              m2[6][i] = m1[6][i] + m1[7][i];
//              m2[7][i] = m1[6][i] - m1[7][i];

//              //---------------------
//              // Now for Had on APC
//              switch(PerformMsAPC)
//              {
//              case true:
//                      {
//                          m3APC[0][i] = m2APC[0][i] + m2APC[4][i];
//                          m3APC[1][i] = m2APC[1][i] + m2APC[5][i];
//                          m3APC[2][i] = m2APC[2][i] + m2APC[6][i];
//                          m3APC[3][i] = m2APC[3][i] + m2APC[7][i];
//                          m3APC[4][i] = m2APC[0][i] - m2APC[4][i];
//                          m3APC[5][i] = m2APC[1][i] - m2APC[5][i];
//                          m3APC[6][i] = m2APC[2][i] - m2APC[6][i];
//                          m3APC[7][i] = m2APC[3][i] - m2APC[7][i];

//                          m1APC[0][i] = m3APC[0][i] + m3APC[2][i];
//                          m1APC[1][i] = m3APC[1][i] + m3APC[3][i];
//                          m1APC[2][i] = m3APC[0][i] - m3APC[2][i];
//                          m1APC[3][i] = m3APC[1][i] - m3APC[3][i];
//                          m1APC[4][i] = m3APC[4][i] + m3APC[6][i];
//                          m1APC[5][i] = m3APC[5][i] + m3APC[7][i];
//                          m1APC[6][i] = m3APC[4][i] - m3APC[6][i];
//                          m1APC[7][i] = m3APC[5][i] - m3APC[7][i];

//                          m2APC[0][i] = m1APC[0][i] + m1APC[1][i];
//                          m2APC[1][i] = m1APC[0][i] - m1APC[1][i];
//                          m2APC[2][i] = m1APC[2][i] + m1APC[3][i];
//                          m2APC[3][i] = m1APC[2][i] - m1APC[3][i];
//                          m2APC[4][i] = m1APC[4][i] + m1APC[5][i];
//                          m2APC[5][i] = m1APC[4][i] - m1APC[5][i];
//                          m2APC[6][i] = m1APC[6][i] + m1APC[7][i];
//                          m2APC[7][i] = m1APC[6][i] - m1APC[7][i];

//                      }
//              }


//            }

//            for (i = 0; i < 8; i++)
//            {
//              for (j = 0; j < 8; j++)
//              {
//                iSumHad += abs(m2[i][j]);
//                iSumHadAPC += PerformMsAPC == true? abs(m2APC[i][j]) : 0;
//                //iSumHadAPC += PerformMsAPC == true? abs(multiscaleAPC[i + (j << 3)]) : 0;
//              }
//            }
//            iSumHad -= abs(m2[0][0]); // Applies only to Activity (Rate Control version of) Had.
//            iSumHad =(iSumHad+2)>>2;

//            //iSumHadAPC -= PerformMsAPC == true? abs(multiscaleAPC[0]) : 0;
//            iSumHadAPC -= PerformMsAPC == true? abs(m2APC[0][0]) : 0;
//            iSumHadAPC =(iSumHadAPC+2)>>2;

//            ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)] = iSumHad;
//            ptrDist_APCms[(x >> 3) + (y >> 3)*(width>>3)] = iSumHadAPC;
//            ptrbool_perfAPCms[(x >> 3) + (y >> 3)*(width>>3)] = PerformMsAPC;

//            // YGJ 12th July 2015 - Storing values into vector for logging data
//            //StorValuesAsTxt[(x >> 3) + (y >> 3)*(width>>3)]

////               struct StorValues
////            {
////                int RCHad;
////                int APCms;
////                int APCmsDownscale;
////                int AbsAsymCost;
////                int Threshold;
////                int EdgeCost;
////            };

//            CurrScores.RCHad = iSumHad;
//            CurrScores.APCms = iSumHadAPC;
//            CurrScores.APCmsDownscale = iSumHadAPC >> RC_APC_Downscale;
//            CurrScores.AbsAsymCost = AbsAsymCost;
//            CurrScores.Threshold = Threshold;
//            CurrScores.EdgeCost = count;
//            CurrScores.APCmsDownAsPercent = CurrScores.APCmsDownscale / CurrScores.RCHad;

//            StorValuesAsTxt.push_back(CurrScores);


//        }
//        else if ((y%8 != 0) || (x%8 != 0))
//        {
			
//            iSumHad = ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)];
//            iSumHadAPC = ptrDist_APCms[(x >> 3) + (y >> 3)*(width>>3)];
//            PerformMsAPC = ptrbool_perfAPCms[(x >> 3) + (y >> 3)*(width>>3)];
//        }


//        yInt = yInt_Org;

//         int r=0, g=0, b=0;

//         // if (iSumHadAPC < 256)
//         //    PerformMsAPC = false;
             
//         if ((y < (height-8)) && (x < (width-8)) )
//         {
//             if (PerformMsAPC == true)
//                 //imgFrmAsTxt[width * y + x] = ((int)iSumHad+ (int)(iSumHadAPC >> RC_APC_Downscale));
//                 imgFrmAsTxt[width * y + x] = ((int)(iSumHadAPC >> RC_APC_Downscale));
//             else
//                 imgFrmAsTxt[width * y + x] = (int)iSumHad;
//         }
//         else
//             imgFrmAsTxt[width * y + x] = -1;
//         //-------------------------


//        if (PerformMsAPC == true)
//        {


//            //------------------

//            int blkwidth = 8;

//            //------------------

//            // Using arrays as look up tables to ensure values set are consistent
//            int loc = (int)log2((double)blkwidth) - 3;

//            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
//            float maxScaled = (float)((float)maxUnscaled * (0.1024));

//            Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor;

//            // For Rate-Control
//            halfMaxThreshold <<= 1; // Double

//            // Divide APC cost by 1/2 Blk size before adding to Had cost

//            //iSumHadAPC  = SumAPCmsEdgeCost > 8? iSumHadAPC : SumAPCmsEdgeCost > 4? iSumHadAPC >> 1 : iSumHadAPC >> 2;

//            iSumHadAPC = iSumHadAPC >> RC_APC_Downscale;
//            //iSumHad = iSumHad + iSumHadAPC;
//            iSumHad = iSumHadAPC;

//            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;
									
////            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
////                printf("RateControl Pre Assess Had with Multiscale-APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
////                halfMaxThreshold, iSumHad, halfMaxThreshold);
						
//            float normHad = ((float)dist)/((float)halfMaxThreshold);

//            // YGJ 15th March 2015
//            // Use 1/2 max based normalised value
//            // Based on normJND

//            normHad = ((double)normHad) > 1.0? 1.0 : normHad;

//            int val =  ((double)normHad) < 0.25? 0 :
//                       ((double)normHad) < 0.5? 1 :
//                       ((double)normHad) < 0.75? 2 : 3;
			
//            //------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//            switch (val)
//            {
//                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt); b = min(yInt << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//                    break;
//                case 1 :  r = 0; g= yInt; b = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//                    break;
//                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//                    break;
//                default : r = min(yInt << 1, 255) ;g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//                    break;
//            }
//            //------------------

//        }
//        else
//        {
//            r = g = b = yInt;
//        }

//        // Rec - Org
//        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;

//        // Partitioning -- Not Working?
//        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//        {
//          r = 0; //yInt_RmO;
//          g = 0; //yInt_RmO;
//          b = 0; //yInt_RmO;
//        }

//        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//      }
//      piY_Org += YStride;
//      piY_Part += YStrideRec;

//    }

//    free(ptrY_Org8x8);

//    free(ptrY_Org);

//    free(ptrY_Part);

//    //-----------------------

//    if(m_outputSSIMHeatmaps)
//    {
//      std::vector<unsigned char> png;

//      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//      //if there's an error, display it
//      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//    }

//   //-----------------------

//    if (m_rawTextData)
//    {
//        //-------------------------
//        // YGJ Thurs 28th May 2015
//        // Output vector to txt file
//        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
//        ofstream DecFrmAsTxt;
//        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
//        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
//        {
//            if ((i+1)%width==0)
//                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
//            else
//                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
//        }
//        DecFrmAsTxt.close();
//        //-------------------------

//        //               struct StorValues
//        //            {
//        //                int RCHad;
//        //                int APCms;
//        //                int APCmsDownscale;
//        //                int AbsAsymCost;
//        //                int Threshold;
//        //                int EdgeCost;
//        //            };

//        ofstream DecValsAsTxt;
//        DecValsAsTxt.open (ValAsTxt, ios::out | ios::app);

//        //StorValuesAsTxt
//        for (unsigned int i = 0; i< StorValuesAsTxt.size(); i ++)
//        {
//            if (StorValuesAsTxt[i].Threshold > 0)
//                DecValsAsTxt << StorValuesAsTxt[i].RCHad << ", " << StorValuesAsTxt[i].APCms << ", " << StorValuesAsTxt[i].APCmsDownscale << ", "
//                         << StorValuesAsTxt[i].AbsAsymCost << ", " << StorValuesAsTxt[i].Threshold << ", " << StorValuesAsTxt[i].EdgeCost << ", "
//                         << StorValuesAsTxt[i].MeanLuma << ", " << StorValuesAsTxt[i].APCmsDownAsPercent << endl ;
//        }

//        DecValsAsTxt.close();


//    }

//}



Void TAppDecTop::saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC(TComPic* pcPic)
{

  // unsigned height = m_iSourceHeight;
//   unsigned width = m_iSourceWidth;
  // unsigned FrameRes = (height*width);

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  // Decode order from reading from YUV file.

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

  Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");

  // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
  // Store values for when at the start of 8x8 and recalled for when within 8x8 block
  Distortion *ptrDist_Had;   ptrDist_Had = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_Had == NULL)   printf("calloc failed\n");
  Distortion *ptrDist_APCms;   ptrDist_APCms = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_APCms == NULL)   printf("calloc failed\n");
  bool *ptrbool_perfAPCms;   ptrbool_perfAPCms = (bool *)calloc((FrameRes >> 6), sizeof(bool));    if (ptrbool_perfAPCms == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  char strpoc[6];
  char strRange[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strRange, sizeof(strRange), "%d", m_distRange);

  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile.c_str());
  strcat(SSIMHeatmap, "DecFrm_RCActivity_PreAssess_wCornerTestwEdgeScale_MSAPCHadActiHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  strcat(SSIMHeatmap, ".png");

  // YGJ Tues 26th May 2015
  // Store the QP to text file
  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());
  strcat(FrmAsTxt, "DecFrm_RCActivity_PreAssess_wCornerTestwEdgeScale_MSAPCHadActiHeatMap_");
  strcat(FrmAsTxt, strpoc);
  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
  strcat(FrmAsTxt, ".txt");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);
  // YGJ Thurs 28th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);


  // YGJ 12th July 2015
  char ValAsTxt[255];  strcpy(ValAsTxt, m_pchSSIMLogAndImageFile.c_str());
  strcat(ValAsTxt, "DecVal_RCActivity_PreAssess_wCornerTestwEdgeScale_MSAPCHadActiHeatMap_");
  strcat(ValAsTxt, strpoc);
  strcat(ValAsTxt, "_Range");  strcat(ValAsTxt, strRange);
  strcat(ValAsTxt, ".txt");

//  // YGJ 12th July 2015
//  // Storing values via custom structure
//  // RC Had, APCms, APCmsDownscale, AbsAsymCost, Thresh(48), EdgeCount
//  struct StorValues
//  {
//      int RCHad;
//      int APCms;
//      int APCmsDownscale;
//      int AbsAsymCost;
//      int Threshold;
//      int EdgeCost;
//      int MeanLuma;
//      double APCmsDownAsPercent;
//  };
  // Now store in vector form every 8x8 in FrameRes
  std::vector<StorValues> StorValuesAsTxt; StorValuesAsTxt.resize(FrameRes >> 6);

  StorValues CurrScores;

  // Edge count
  int count = 0;

  UInt Threshold = 48; //28; // Does a threshold of 28 sufficient as 16?
  UInt AbsAsymCost = 0;

  unsigned MaxValue = (1<<bitDepthLuma)-1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

    //////////////////////////
    // YGJ 5th Jan 2015
    // Non-Overlapping 8x8, to be more like Rate Control
    // Save as previous values

    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;

        // allocate YUV value
        int yInt = 0; 

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc];
        int yInt_Part = (int)ptrY_Part[yloc]; 

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0) // || yInt_Rec > 255 || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d \n", yInt_Org); //, yInt_Rec);


        Distortion iSumHad =0; 
        Distortion iSumHadAPC = 0; 
        bool PerformMsAPC = false; 

        Pel *diff;
        int i, j, jj, k;
        //int blksz = 64;
        //Int SumAPCmsEdgeCost = 0; // Does not match Encoder


        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-8)) && (x < (width-8)) && ((y % 8 == 0) && (x % 8 == 0)))
        {
           // YGJ 12th July 2015 - Reset values
           CurrScores.RCHad = 0;
           CurrScores.APCms = 0;
           CurrScores.APCmsDownscale = 0;
           CurrScores.Threshold = 0; // Should be 48
           CurrScores.EdgeCost = 0;
           CurrScores.MeanLuma = 0;
           CurrScores.APCmsDownAsPercent = 0.0;

          //HadRegion = true;

//          Distortion diff[64];
          TCoeff m1[8][8], m2[8][8], m3[8][8]; 
          Int m1APC[8][8], m2APC[8][8], m3APC[8][8]; //, iSumHadAPC = 0; //, iSumAPCms = 0;
          Int multiscaleAPC[64]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.


            for ( unsigned n = 0; n < 8; n++ )
            {
                for ( unsigned m = 0; m < 8; m++ )
                {
                    unsigned yloc8x8 = n*m+m;

                    CurrScores.MeanLuma += ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);

                }
            }

            // Calc Mean
            CurrScores.MeanLuma >>= 6;

            diff = ptrY_Org8x8;

            //-------------------------

            // YGJ Sun 24th Aug 2014 - Pre Assessment to determine whether multi-scale APC is justified
            // Calc APC for Top, Bottom, Left and Right side of 8x8 (First and Last Row and Columns)
            // Note that APC is calculated by accessing the Look Up Table (LUT).
            // While in SAD, APC can be accumulated then divided by 2, here the LUT used, (APC_NegAndPos_1D) via the function (RCHadAPC) has the values already divided by 2.
            // However, in multi-scale APC they must be divided by their interval, which APC_NegAndPos_1D will perform by entering the number bits to shift by.
            //
            // Multi-scale APC does require significant amount of processing.
            // Under rate-control this will occur when a new Group of Pictures (GOP) sequence requires the bit-rate to be budgetted by frame/slice type.
            // Regardless, applying multi-scale APC irrespectively, can increase processing demand unnecessarily.
            // Also, hadamard transform employs symmetry to elminate/minimise accumulated differences.
            // Applying a test for asymmetrical perceptual changes can then differieniate when multi-scale is suitable to apply and limiting the use of additional complexity till then.
            //
            // A non-symmetrical distribution of two regions in a block can affect the percpetual rate of change along one of the edges of the block.
            // By subtracting opposing edges from each other any dominant edge, where the perceptual rate of change is far higher than the others will be shown.
            // The threshold by which the resulting value should tested against should be the block size, in this case, 8x8 = 64.
            // If (abs(abs(T-B) - abs(L-R)) > 64
            // In general, this should make the processing more adaptive/dynamic, only applying multi-scale APC  according to the level of asymmetric boundary changes where the intensity (Luma) is high.
            // Expect processing demand to vary depending upon the scene in question.
            // Based upon simulations based observations gathered from the first frame of Race Horses video (416 x 240) where 1560 samples are processed, one per 8x8 block region, the need to called multi-scale APC can be reduced by 2/3.

            //----

            // First calc Horizontal
            // For Top and Left this their initial cost (stage 1 of 2).
            // For Bottom it is the only time it will be updated (1 of 1).
            // For Right it will be set during vertical (0 of 1).

            //-----

            //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
            //H/V: x, 1/8, 1/4, 1/2
            // H: 0: (0,4),(0,2),(0,1)
            // H: 1: (1,5),(1,3),--
            // H: 2: (2,6),--, (2,3)
            // H: 3: (3,7),--,--
            // H: 4: --,(4,6),(4,5)
            // H: 5: --,(5,7),--
            // H: 6: --,--,(6,7)
            // H:7: Always  Zero

            // This means for Top and Bottom the above is correct.
            // For  Left    // H: 0: (0,4),(0,2),(0,1) needs to be performed.
            // For Right as stated it is // H:7: Always  Zero

            //-----

            // Second  calc Vertical
            // Like Horizontal but now for the others are updated/completed.
            // Top and Left are completed
            // Right is updated.

            //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
            //H/V: x, 1/8, 1/4, 1/2
            // V: 0: (0,4),(0,2),(0,1)
            // V: 1: (1,5),(1,3),--
            // V: 2: (2,6),--, (2,3)
            // V: 3: (3,7),--,--
            // V: 4: --,(4,6),(4,5)
            // V: 5: --,(5,7),--
            // V: 6: --,--,(6,7)
            // V:7: Always  Zero

            // For Left and Right the above is correct
            // Top -  // V: 0: (0,4),(0,2),(0,1)
            // Bottom - // V:7: Always  Zero

            //-----

            // Now to check if full multi-scale APC is required of Hadamard is sufficient
            // If (abs(abs(Top-Bottom) - abs(Left-Right)) > 64 then perform multii-scale APC.
            // Multi-scale APC has a high score where boundary changes occur where  Luma intensity is high.
            // Hadamard is suited for where symmetrical differences exist.
            // Thus, multi-scale APC is suited for where asymmetric boundary changes occur for high Luma 8x8 blocks.
            // It is possible that the top left corner pixel can strongly influence both Top and Left.
            // To avoid the top left corner pixel affecting the scores, the test for full multi-scale APC is a series of differences.
            // Furthermore, the threshold of 64 is sufficiently low enough to allow a range of potential candidates for the full multi-scale APC.

            //---------------

            // YGJ Wed 27th Aug 2014
            // Pre-Assessment Test for multi-scale APC
            // Just the sides without corners.
            // Assuming perceptual information is continuous and may cross over blocksizes.
            // If the change on the edges are high then they is likley asymmetric change in the block.
            // For Hadamard symmetry is used to cancel accumulated differences.
            // While asymmetric differences do not cancel out.
            // This means APC on Had is best applied when asymmetric changes are high
            // The use of this Pre-Assessment is devised to initially detect if asymmetric differences exist.
            // If not the remaining process reverts back to the existing Hadamard method.
            // The proposed method is expected to applible about 10% of the time, though this will vary depending upon video/frame content.

            // Distance
            int dist4 = 5; // 1/32 * 1/2  = 1/64  - This avoids making the change very extreme
            int dist2 = 3; // 1/8 * 1/2 = 1/16 - This is used as a half-way point.
            int dist1 = 0; // 1/2  = 1/2  - Must be zero as APC has already been halved. Also most crucial value

            //int TopLeftPx = 0;  // Shared by Left and Top
            int Top = 0, Left = 0;

              // Ignore Corner, this leaves 1-6

            Top += multiscaleAPC[1] = TComRdCost::RCHadAPC((int)diff[1], (int)diff[5], dist4) + TComRdCost::RCHadAPC((int)diff[1], (int)diff[3], dist2);
            Top += multiscaleAPC[2] = TComRdCost::RCHadAPC((int)diff[2], (int)diff[6], dist4) + TComRdCost::RCHadAPC((int)diff[2], (int)diff[3], dist1);
            Top += multiscaleAPC[3] = TComRdCost::RCHadAPC((int)diff[3], (int)diff[7], dist4);
            Top += multiscaleAPC[4] = TComRdCost::RCHadAPC((int)diff[4], (int)diff[6], dist2) + TComRdCost::RCHadAPC((int)diff[4], (int)diff[5], dist1);
            Top += multiscaleAPC[5] = TComRdCost::RCHadAPC((int)diff[5], (int)diff[7], dist2);
            Top += multiscaleAPC[6] = TComRdCost::RCHadAPC((int)diff[6], (int)diff[7], dist1);
            //---


          // Since the first row (0) is done, and the last row (56) will be done later, just do the intervening rows (8, 16, 32, 40, 48)
          for( k = 8; k < 56; k += 8 )
          {
            Left += multiscaleAPC[k] = TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+4], dist4)
                                    +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+2], dist2)
                                    +   TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+1], dist1);
          }

          //int BottomLeft = 0; // Shared by Left and Bottom
          int Bottom = 0;
          //---

          // Ignore Corner, this leaves 57-62

          Bottom += multiscaleAPC[57] = TComRdCost::RCHadAPC((int)diff[57], (int)diff[61], dist4) + TComRdCost::RCHadAPC((int)diff[57], (int)diff[59], dist2);
          Bottom += multiscaleAPC[58] = TComRdCost::RCHadAPC((int)diff[58], (int)diff[62], dist4) + TComRdCost::RCHadAPC((int)diff[58], (int)diff[59], dist1);
          Bottom += multiscaleAPC[59] = TComRdCost::RCHadAPC((int)diff[59], (int)diff[63], dist4);
          Bottom += multiscaleAPC[60] = TComRdCost::RCHadAPC((int)diff[60], (int)diff[62], dist2) + TComRdCost::RCHadAPC((int)diff[60], (int)diff[61], dist1);
          Bottom += multiscaleAPC[61] = TComRdCost::RCHadAPC((int)diff[61], (int)diff[63], dist2);
          Bottom += multiscaleAPC[62] = TComRdCost::RCHadAPC((int)diff[62], (int)diff[63], dist1);

          //---

          // ----------
          // Vertical

        //  //---

          // Ignore Corner, this leaves 8, 16, 24, 32, 40, 48

          int iTemp;

          iTemp = TComRdCost::RCHadAPC((int)diff[8], (int)diff[40], dist4)  + TComRdCost::RCHadAPC((int)diff[8], (int)diff[24], dist2);  Left += iTemp; multiscaleAPC[8] += iTemp;
          iTemp = TComRdCost::RCHadAPC((int)diff[16], (int)diff[48], dist4) + TComRdCost::RCHadAPC((int)diff[16], (int)diff[24], dist1); Left += iTemp; multiscaleAPC[16] += iTemp;
          iTemp = TComRdCost::RCHadAPC((int)diff[24], (int)diff[56], dist4);                                               Left += iTemp; multiscaleAPC[24] += iTemp;
          iTemp = TComRdCost::RCHadAPC((int)diff[32], (int)diff[48], dist2) + TComRdCost::RCHadAPC((int)diff[32], (int)diff[40], dist1); Left += iTemp; multiscaleAPC[32] += iTemp;
          iTemp = TComRdCost::RCHadAPC((int)diff[40], (int)diff[56], dist2);                                               Left += iTemp; multiscaleAPC[40] += iTemp;
          iTemp = TComRdCost::RCHadAPC((int)diff[48], (int)diff[56], dist1);                                               Left += iTemp; multiscaleAPC[48] += iTemp;

          //---

          // Similar to before since the top left (0) has been calc for Left and top right (7) will be calc afterwards for Right only those in between need to be calc. (1- 6)
          for( k = 1; k < 7; k++ )
          {
            iTemp = TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+32], dist4)
                 +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+16], dist2)
                 +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+8], dist1);

            Top += iTemp; multiscaleAPC[k] += iTemp;
          }

          //---

          int Right = 0;

          // Ignore Corner, this leaves 15, 23, 31, 39, 47, 55
          Right += multiscaleAPC[15] =  TComRdCost::RCHadAPC((int)diff[15], (int)diff[47], dist4) +  TComRdCost::RCHadAPC((int)diff[15], (int)diff[31], dist2);
          Right += multiscaleAPC[23] =  TComRdCost::RCHadAPC((int)diff[23], (int)diff[55], dist4) +  TComRdCost::RCHadAPC((int)diff[23], (int)diff[31], dist1);
          Right += multiscaleAPC[31] =  TComRdCost::RCHadAPC((int)diff[31], (int)diff[63], dist4);
          Right += multiscaleAPC[39] =  TComRdCost::RCHadAPC((int)diff[39], (int)diff[55], dist2) +  TComRdCost::RCHadAPC((int)diff[39], (int)diff[47], dist1);
          Right += multiscaleAPC[47] =  TComRdCost::RCHadAPC((int)diff[47], (int)diff[63], dist2);
          Right += multiscaleAPC[55] =  TComRdCost::RCHadAPC((int)diff[55], (int)diff[63], dist1);
          //---
            //-------------------------
            // Now to Test if the full multi-scale APC is required or not

            //bool PerformMsAPC = abs(abs(Top-Bottom) - abs(Left-Right)) > 64 ? true : false;

            // Step 2) Calc whether abs(abs(T-B)-abs(L-R)) is greater than the threshold.

            //UInt
            AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

            // Sun 23rd Nov 2014
            // Having analysed log calculated values the median value for AbsAsymCost was 48 for APC Multiscale (used in Had and RC Had).
            // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
            // Over 48 million observations were logged, which represented 8.7 million unique records.
            //UInt Threshold = 48; //28; // Does a threshold of 28 sufficient as 16?

            PerformMsAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

            //switch(PerformMsAPC)
            //{

                //case true:
                if (PerformMsAPC == true)
                {

                //Now the corners

                  //---
                  // Top Left (Horizontal and Vertical)
                  multiscaleAPC[0] = TComRdCost::RCHadAPC((int)diff[0], (int)diff[4], dist4)
                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[2], dist2)
                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[1], dist1)
                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[32], dist4)
                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[16], dist2)
                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[8], dist1);

                  // Bottom Left only has Horizontal components only
                  multiscaleAPC[56] = TComRdCost::RCHadAPC((int)diff[56], (int)diff[60], dist4)
                                    + TComRdCost::RCHadAPC((int)diff[56], (int)diff[58], dist2)
                                    + TComRdCost::RCHadAPC((int)diff[56], (int)diff[57], dist1);


                  // Top Right only has Vertical components only
                  multiscaleAPC[7] = TComRdCost::RCHadAPC((int)diff[7], (int)diff[39], dist4)
                                   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[23], dist2)
                                   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[15], dist1);

                  // Bottom Right has no components
                  multiscaleAPC[63] = 0; // Always Zero
                //-------------------------

////                  // YGJ 3rd Dec 2014
////                  // Based upon unpublished edge detection of by Myo. Modified to make it efficient and adapted for use here.
////                  // 2 times corner minus averaged adjacent sides, in this case approximate average, should be div by 6 but using divide by 8.
////                  // From modelling done in R this should reduce the no. of obs by ~1/2, focusing more on the ones with higher Had and 1-SSIM scores.
////                  // Modelling showed that corner test should occur after thresholding, not before or alone.
////                  // This approach is the most effective at shifting and broadening the peak in Had away from zero.
////                  // From 30k sampled observations, 7k were affected, approx 23%.
////                  // In R threshold was 32, divide was done by 6 and count min was >1.
////                  // Here it is the same except that divide is 8.
////                  // When modelled

                  //count = 0;

                  count =  ((abs(multiscaleAPC[0]) << 1) - ((abs(Top) +  abs(Left)) >> 3)) > 0 ? 1 : 0;
                  count +=  ((abs(multiscaleAPC[7]) << 1) - ((abs(Top) +  abs(Right)) >> 3)) > 0 ? 1 : 0;
                  count +=  ((abs(multiscaleAPC[56]) << 1) - ((abs(Bottom) +  abs(Left)) >> 3)) > 0 ? 1 : 0;

                  PerformMsAPC = count > 1? true: false;

                }

            //}

            // YGJ 10th July 2015 - Does not match encoder, disabling this section.
            // Can not justify additional complexity per 8x8 block?
            // Will need to test to see the difference

//            switch(PerformMsAPC)
//            {

//                case true:
//                {
//                  // Monday 5th January 2015

//                  // Edge Detect on APCms, similar to Edfge on SASD calc percetual importance of activity
//                  // Then the sum of the edges should be used to produced a weighted APCms score to add to the Had cost

//                  // At this point check for edges on APCms block.
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[9] << 1) - multiscaleAPC[8] - multiscaleAPC[1]) >  0 ? 1 : 0; // SE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[3] << 1) - multiscaleAPC[2] - multiscaleAPC[11]) >  0 ? 1 : 0; //NE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[24] << 1) - multiscaleAPC[25] - multiscaleAPC[16]) >  0 ? 1 : 0; // SW
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[18] << 1) - multiscaleAPC[19] - multiscaleAPC[26]) >  0 ? 1 : 0; // NW

//                  SumAPCmsEdgeCost += ( (multiscaleAPC[13] << 1) - multiscaleAPC[12] - multiscaleAPC[5]) >  0 ? 1 : 0; // SE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[7] << 1) - multiscaleAPC[6] - multiscaleAPC[15]) >  0 ? 1 : 0; //NE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[28] << 1) - multiscaleAPC[29] - multiscaleAPC[20]) >  0 ? 1 : 0; // SW
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[22] << 1) - multiscaleAPC[23] - multiscaleAPC[30]) >  0 ? 1 : 0; // NW

//                  SumAPCmsEdgeCost += ( (multiscaleAPC[41] << 1) - multiscaleAPC[40] - multiscaleAPC[33]) >  0 ? 1 : 0; // SE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[35] << 1) - multiscaleAPC[34] - multiscaleAPC[43]) >  0 ? 1 : 0; //NE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[56] << 1) - multiscaleAPC[57] - multiscaleAPC[48]) >  0 ? 1 : 0; // SW
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[50] << 1) - multiscaleAPC[51] - multiscaleAPC[58]) >  0 ? 1 : 0; // NW

//                  SumAPCmsEdgeCost += ( (multiscaleAPC[45] << 1) - multiscaleAPC[44] - multiscaleAPC[37]) >  0 ? 1 : 0; // SE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[39] << 1) - multiscaleAPC[38] - multiscaleAPC[47]) >  0 ? 1 : 0; //NE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[60] << 1) - multiscaleAPC[61] - multiscaleAPC[52]) >  0 ? 1 : 0; // SW
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[54] << 1) - multiscaleAPC[55] - multiscaleAPC[62]) >  0 ? 1 : 0; // NW

//                  PerformMsAPC = SumAPCmsEdgeCost > 4? true: false; // Triggers on nearly everything

//                }

//            }


            int *ptrAPCDiff;

            //switch(PerformMsAPC)
            //{

            //case true:
                if (PerformMsAPC == true)
                {
                    //-------------------------
                    // YGJ Fri 22nd Aug 2014 - Since the jump between pixels is 4 and APC is divided by 2 by default then the APC score should be divided by (4*2), 8, shift by 3.
                    // Since APC LUT violates SSIM and other existing distortion measures use of symmetry, where pixel x vs y is the same as pixel y vs x, choice of which is the reference is important.
                    // Use max for the two pixels to determine the reference point.

                    // YGJ Sat 23rd Aug 2014 - MulitScaled APC Prior to Hadamard - accumulates the various weighted APC/2 scores by different intervals
                    // APC/2, if space of 4, div by 4, if space of 2, div by 2, if space of 1, div by 1.
                    // Repeat for Vertical and then accumulate.
                    // When being used H1, div APC by 8.

                    // Wrong (ignore)-> Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
                    // YGJ Wed 27th Aug 2014 - Correction: RCHadAPC divides by two before it returns the value, just divide by the spacing 4, 2 or 1.
                    //H/V: x, 1/64, 1/16, 1/2
                    // H: 0: (0,4),(0,2),(0,1)
                    // H: 1: (1,5),(1,3),--
                    // H: 2: (2,6),--, (2,3)
                    // H: 3: (3,7),--,--
                    // H: 4: --,(4,6),(4,5)
                    // H: 5: --,(5,7),--
                    // H: 6: --,--,(6,7)
                    // H:7: Always  Zero

                    // First the inner square (block without the edges or corners)

                // Horizontal
                for( k = 8; k < 56; k += 8 )
                {
                  multiscaleAPC[k+1] = TComRdCost::RCHadAPC((int)diff[k+1], (int)diff[k+5], dist4) + TComRdCost::RCHadAPC((int)diff[k+1], (int)diff[k+3], dist2);
                  multiscaleAPC[k+2] = TComRdCost::RCHadAPC((int)diff[k+2], (int)diff[k+6], dist4) + TComRdCost::RCHadAPC((int)diff[k+2], (int)diff[k+3], dist1);
                  multiscaleAPC[k+3] = TComRdCost::RCHadAPC((int)diff[k+3], (int)diff[k+7], dist4);
                  multiscaleAPC[k+4] = TComRdCost::RCHadAPC((int)diff[k+4], (int)diff[k+6], dist2) +  TComRdCost::RCHadAPC((int)diff[k+4], (int)diff[k+5], dist1);
                  multiscaleAPC[k+5] = TComRdCost::RCHadAPC((int)diff[k+5], (int)diff[k+7], dist2);
                  multiscaleAPC[k+6] = TComRdCost::RCHadAPC((int)diff[k+6], (int)diff[k+7], dist1);
                }

                //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
                //H/V: x, 1/8, 1/4, 1/2
                // V: 0: (0,4),(0,2),(0,1)
                // V: 1: (1,5),(1,3),--
                // V: 2: (2,6),--, (2,3)
                // V: 3: (3,7),--,--
                // V: 4: --,(4,6),(4,5)
                // V: 5: --,(5,7),--
                // V: 6: --,--,(6,7)
                // V:7: Always  Zero

                // Vertical
                // Same as Horizontal but now k is from 0 to 7 and k+1/2/3/4/5/6/7 are now k+(1/2/3/4/5/6/7 x 8)
                // Hence it is the same as Horizontal but rotated

                // Remember to increment and not assign/replace existing value

                for( k = 1; k < 7; k++ )
                {
                  multiscaleAPC[k+8] += TComRdCost::RCHadAPC((int)diff[k+8], (int)diff[k+40], dist4) + TComRdCost::RCHadAPC((int)diff[k+8], (int)diff[k+24], dist2);
                  multiscaleAPC[k+16] += TComRdCost::RCHadAPC((int)diff[k+16], (int)diff[k+48], dist4) + TComRdCost::RCHadAPC((int)diff[k+16], (int)diff[k+24], dist1);
                  multiscaleAPC[k+24] += TComRdCost::RCHadAPC((int)diff[k+24], (int)diff[k+56], dist4);
                  multiscaleAPC[k+32] += TComRdCost::RCHadAPC((int)diff[k+32], (int)diff[k+48], dist2) + TComRdCost::RCHadAPC((int)diff[k+32], (int)diff[k+40], dist1);
                  multiscaleAPC[k+40] += TComRdCost::RCHadAPC((int)diff[k+40], (int)diff[k+56], dist2);
                  multiscaleAPC[k+48] += TComRdCost::RCHadAPC((int)diff[k+48], (int)diff[k+56], dist1);
                }

                //----
              ptrAPCDiff = multiscaleAPC;

              }
              //break; // End of (if (PerformMsAPC = true))
            //}


            //horizontal
            for (j=0; j < 8; j++)
            {
              jj = j << 3;


              m2[j][0] = diff[jj  ] + diff[jj+4];
              m2[j][1] = diff[jj+1] + diff[jj+5];
              m2[j][2] = diff[jj+2] + diff[jj+6];
              m2[j][3] = diff[jj+3] + diff[jj+7];
              m2[j][4] = diff[jj  ] - diff[jj+4];
              m2[j][5] = diff[jj+1] - diff[jj+5];
              m2[j][6] = diff[jj+2] - diff[jj+6];
              m2[j][7] = diff[jj+3] - diff[jj+7];


              m1[j][0] = m2[j][0] + m2[j][2];
              m1[j][1] = m2[j][1] + m2[j][3];
              m1[j][2] = m2[j][0] - m2[j][2];
              m1[j][3] = m2[j][1] - m2[j][3];
              m1[j][4] = m2[j][4] + m2[j][6];
              m1[j][5] = m2[j][5] + m2[j][7];
              m1[j][6] = m2[j][4] - m2[j][6];
              m1[j][7] = m2[j][5] - m2[j][7];

              m2[j][0] = m1[j][0] + m1[j][1];
              m2[j][1] = m1[j][0] - m1[j][1];
              m2[j][2] = m1[j][2] + m1[j][3];
              m2[j][3] = m1[j][2] - m1[j][3];
              m2[j][4] = m1[j][4] + m1[j][5];
              m2[j][5] = m1[j][4] - m1[j][5];
              m2[j][6] = m1[j][6] + m1[j][7];
              m2[j][7] = m1[j][6] - m1[j][7];

              //---------------------
              // Now for Had on APC
              //switch(PerformMsAPC)
              //{
              //case true:
              if (PerformMsAPC == true)
                      {

                      m2APC[j][0] = ptrAPCDiff[jj  ] ;
                      m2APC[j][1] = ptrAPCDiff[jj+1] ;
                      m2APC[j][2] = ptrAPCDiff[jj+2] ;
                      m2APC[j][3] = ptrAPCDiff[jj+3] ;
                      m2APC[j][4] = - (ptrAPCDiff[jj+4] );
                      m2APC[j][5] = - (ptrAPCDiff[jj+5] );
                      m2APC[j][6] = - (ptrAPCDiff[jj+6] );
                      m2APC[j][7] = - (ptrAPCDiff[jj+7] );

                      m1APC[j][0] = m2APC[j][0] + m2APC[j][2];
                      m1APC[j][1] = m2APC[j][1] + m2APC[j][3];
                      m1APC[j][2] = m2APC[j][0] - m2APC[j][2];
                      m1APC[j][3] = m2APC[j][1] - m2APC[j][3];
                      m1APC[j][4] = m2APC[j][4] + m2APC[j][6];
                      m1APC[j][5] = m2APC[j][5] + m2APC[j][7];
                      m1APC[j][6] = m2APC[j][4] - m2APC[j][6];
                      m1APC[j][7] = m2APC[j][5] - m2APC[j][7];

                      m2APC[j][0] = m1APC[j][0] + m1APC[j][1];
                      m2APC[j][1] = m1APC[j][0] - m1APC[j][1];
                      m2APC[j][2] = m1APC[j][2] + m1APC[j][3];
                      m2APC[j][3] = m1APC[j][2] - m1APC[j][3];
                      m2APC[j][4] = m1APC[j][4] + m1APC[j][5];
                      m2APC[j][5] = m1APC[j][4] - m1APC[j][5];
                      m2APC[j][6] = m1APC[j][6] + m1APC[j][7];
                      m2APC[j][7] = m1APC[j][6] - m1APC[j][7];

                      }
              //}

            }

            //vertical
            for (i=0; i < 8; i++)
            {
              m3[0][i] = m2[0][i] + m2[4][i];
              m3[1][i] = m2[1][i] + m2[5][i];
              m3[2][i] = m2[2][i] + m2[6][i];
              m3[3][i] = m2[3][i] + m2[7][i];
              m3[4][i] = m2[0][i] - m2[4][i];
              m3[5][i] = m2[1][i] - m2[5][i];
              m3[6][i] = m2[2][i] - m2[6][i];
              m3[7][i] = m2[3][i] - m2[7][i];

              m1[0][i] = m3[0][i] + m3[2][i];
              m1[1][i] = m3[1][i] + m3[3][i];
              m1[2][i] = m3[0][i] - m3[2][i];
              m1[3][i] = m3[1][i] - m3[3][i];
              m1[4][i] = m3[4][i] + m3[6][i];
              m1[5][i] = m3[5][i] + m3[7][i];
              m1[6][i] = m3[4][i] - m3[6][i];
              m1[7][i] = m3[5][i] - m3[7][i];

              m2[0][i] = m1[0][i] + m1[1][i];
              m2[1][i] = m1[0][i] - m1[1][i];
              m2[2][i] = m1[2][i] + m1[3][i];
              m2[3][i] = m1[2][i] - m1[3][i];
              m2[4][i] = m1[4][i] + m1[5][i];
              m2[5][i] = m1[4][i] - m1[5][i];
              m2[6][i] = m1[6][i] + m1[7][i];
              m2[7][i] = m1[6][i] - m1[7][i];

              //---------------------
              // Now for Had on APC
//              switch(PerformMsAPC)
//              {
//              case true:
              if (PerformMsAPC == true)
                      {
                          m3APC[0][i] = m2APC[0][i] + m2APC[4][i];
                          m3APC[1][i] = m2APC[1][i] + m2APC[5][i];
                          m3APC[2][i] = m2APC[2][i] + m2APC[6][i];
                          m3APC[3][i] = m2APC[3][i] + m2APC[7][i];
                          m3APC[4][i] = m2APC[0][i] - m2APC[4][i];
                          m3APC[5][i] = m2APC[1][i] - m2APC[5][i];
                          m3APC[6][i] = m2APC[2][i] - m2APC[6][i];
                          m3APC[7][i] = m2APC[3][i] - m2APC[7][i];

                          m1APC[0][i] = m3APC[0][i] + m3APC[2][i];
                          m1APC[1][i] = m3APC[1][i] + m3APC[3][i];
                          m1APC[2][i] = m3APC[0][i] - m3APC[2][i];
                          m1APC[3][i] = m3APC[1][i] - m3APC[3][i];
                          m1APC[4][i] = m3APC[4][i] + m3APC[6][i];
                          m1APC[5][i] = m3APC[5][i] + m3APC[7][i];
                          m1APC[6][i] = m3APC[4][i] - m3APC[6][i];
                          m1APC[7][i] = m3APC[5][i] - m3APC[7][i];

                          m2APC[0][i] = m1APC[0][i] + m1APC[1][i];
                          m2APC[1][i] = m1APC[0][i] - m1APC[1][i];
                          m2APC[2][i] = m1APC[2][i] + m1APC[3][i];
                          m2APC[3][i] = m1APC[2][i] - m1APC[3][i];
                          m2APC[4][i] = m1APC[4][i] + m1APC[5][i];
                          m2APC[5][i] = m1APC[4][i] - m1APC[5][i];
                          m2APC[6][i] = m1APC[6][i] + m1APC[7][i];
                          m2APC[7][i] = m1APC[6][i] - m1APC[7][i];

                      }
              //}


            }

            for (i = 0; i < 8; i++)
            {
              for (j = 0; j < 8; j++)
              {
                iSumHad += abs(m2[i][j]);
                iSumHadAPC += PerformMsAPC == true? abs(m2APC[i][j]) : 0;
                //iSumHadAPC += PerformMsAPC == true? abs(multiscaleAPC[i + (j << 3)]) : 0;
              }
            }
            iSumHad -= abs(m2[0][0]); // Applies only to Activity (Rate Control version of) Had.
            iSumHad =(iSumHad+2)>>2;

            //iSumHadAPC -= PerformMsAPC == true? abs(multiscaleAPC[0]) : 0;
            iSumHadAPC -= PerformMsAPC == true? abs(m2APC[0][0]) : 0;
            iSumHadAPC =(iSumHadAPC+2)>>2;

            ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)] = iSumHad;
            ptrDist_APCms[(x >> 3) + (y >> 3)*(width>>3)] = iSumHadAPC;
            ptrbool_perfAPCms[(x >> 3) + (y >> 3)*(width>>3)] = PerformMsAPC;

            // YGJ 12th July 2015 - Storing values into vector for logging data
            //StorValuesAsTxt[(x >> 3) + (y >> 3)*(width>>3)]

//               struct StorValues
//            {
//                int RCHad;
//                int APCms;
//                int APCmsDownscale;
//                int AbsAsymCost;
//                int Threshold;
//                int EdgeCost;
//            };

            CurrScores.RCHad = iSumHad;
            CurrScores.APCms = iSumHadAPC;
            CurrScores.APCmsDownscale = iSumHadAPC >> RC_APC_Downscale;
            CurrScores.AbsAsymCost = AbsAsymCost;
            CurrScores.Threshold = Threshold;
            CurrScores.EdgeCost = count;
            CurrScores.APCmsDownAsPercent = CurrScores.APCmsDownscale / CurrScores.RCHad;

            StorValuesAsTxt.push_back(CurrScores);


        }
        else if ((y%8 != 0) || (x%8 != 0))
        {
			
            iSumHad = ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)];
            iSumHadAPC = ptrDist_APCms[(x >> 3) + (y >> 3)*(width>>3)];
            PerformMsAPC = ptrbool_perfAPCms[(x >> 3) + (y >> 3)*(width>>3)];
        }


        yInt = yInt_Org;

         int r=0, g=0, b=0;

         if (iSumHadAPC < 256)
             PerformMsAPC = false;
             
         if ((y < (height-8)) && (x < (width-8)) )
         {
             if (PerformMsAPC == true)
                 imgFrmAsTxt[width * y + x] = ((int)iSumHad+ (int)(iSumHadAPC >> RC_APC_Downscale));
             else
                 imgFrmAsTxt[width * y + x] = (int)iSumHad;
         }
         else
             imgFrmAsTxt[width * y + x] = -1;
         //-------------------------


        if (PerformMsAPC == true)
        {


            //------------------

            int blkwidth = 8;

            //------------------

            // Using arrays as look up tables to ensure values set are consistent
            int loc = (int)log2((double)blkwidth) - 3;

            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
            float maxScaled = (float)((float)maxUnscaled * (0.1024));

            Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor;

            // For Rate-Control
            halfMaxThreshold <<= 1; // Double

            // Divide APC cost by 1/2 Blk size before adding to Had cost

            //iSumHadAPC  = SumAPCmsEdgeCost > 8? iSumHadAPC : SumAPCmsEdgeCost > 4? iSumHadAPC >> 1 : iSumHadAPC >> 2;

            iSumHadAPC = iSumHadAPC >> RC_APC_Downscale;
            iSumHad = iSumHad + iSumHadAPC;

            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;
									
//            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//                printf("RateControl Pre Assess Had with Multiscale-APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//                halfMaxThreshold, iSumHad, halfMaxThreshold);
						
            float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = ((double)normHad) > 1.0? (float)1.0 : normHad;

            int val =  ((double)normHad) < 0.25? 0 :
                       ((double)normHad) < 0.5? 1 :
                       ((double)normHad) < 0.75? 2 : 3;
			
            //------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
            switch (val)
            {
                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt); b = min(yInt << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                    break;
                case 1 :  r = 0; g= yInt; b = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                    break;
                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                    break;
                default : r = min(yInt << 1, 255) ;g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                    break;
            }
            //------------------

        }
        else
        {
            r = g = b = yInt;
        }

        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;

        // Partitioning -- Not Working?
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; //yInt_RmO;
          g = 0; //yInt_RmO;
          b = 0; //yInt_RmO;
        }

        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      piY_Org += YStride;
      piY_Part += YStrideRec;

    }

    free(ptrY_Org8x8);

    free(ptrY_Org);

    free(ptrY_Part);

    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

    if (m_rawTextData)
    {
        //-------------------------
        // YGJ Thurs 28th May 2015
        // Output vector to txt file
        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
        ofstream DecFrmAsTxt;
        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
        {
            if ((i+1)%width==0)
                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
            else
                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
        }
        DecFrmAsTxt.close();
        //-------------------------

        //               struct StorValues
        //            {
        //                int RCHad;
        //                int APCms;
        //                int APCmsDownscale;
        //                int AbsAsymCost;
        //                int Threshold;
        //                int EdgeCost;
        //            };

        ofstream DecValsAsTxt;
        DecValsAsTxt.open (ValAsTxt, ios::out | ios::app);

        //StorValuesAsTxt
        for (unsigned int i = 0; i< StorValuesAsTxt.size(); i ++)
        {
            if (StorValuesAsTxt[i].Threshold > 0)
                DecValsAsTxt << StorValuesAsTxt[i].RCHad << ", " << StorValuesAsTxt[i].APCms << ", " << StorValuesAsTxt[i].APCmsDownscale << ", "
                         << StorValuesAsTxt[i].AbsAsymCost << ", " << StorValuesAsTxt[i].Threshold << ", " << StorValuesAsTxt[i].EdgeCost << ", "
                         << StorValuesAsTxt[i].MeanLuma << ", " << StorValuesAsTxt[i].APCmsDownAsPercent << endl ;
        }

        DecValsAsTxt.close();


    }

}

Void TAppDecTop::saveFrameAsPNG_HadPreAssess_wCornerTest_APC(TComPic* pcPic)
{

  // unsigned height = m_iSourceHeight;
//   unsigned width = m_iSourceWidth;
  // unsigned FrameRes = (height*width);

  // Used to produce Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  // Decode order from reading from YUV file.

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");


    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    // YGJ 16th March 2015 - Block size can vary in SSE version.

    Distortion *ptrDist_Had;   ptrDist_Had = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_Had == NULL)   printf("calloc failed\n");
    Distortion *ptrDist_sadAPC;   ptrDist_sadAPC = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_sadAPC == NULL)   printf("calloc failed\n");
    bool *ptrbool_ProceedwAPC;   ptrbool_ProceedwAPC = (bool *)calloc((FrameRes >> 6), sizeof(bool));    if (ptrbool_ProceedwAPC == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];
  char strFactor[8];


  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile.c_str());
  strcat(SSIMHeatmap, "DecFrm_Had8x8withPreAssessAPC_wCornerTest_DistortionHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
  strcat(SSIMHeatmap, ".png");

  // YGJ Tues 26th May 2015
  // Store the QP to text file
  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());
  strcat(FrmAsTxt, "DecFrm_Had8x8withPreAssessAPC_wCornerTest_DistortionHeatMap_");
  strcat(FrmAsTxt, strpoc);
  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
  strcat(FrmAsTxt, "_Factor");  strcat(FrmAsTxt, strFactor);
  strcat(FrmAsTxt, ".txt");


  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);
  // YGJ Thurs 28th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

  // YGJ 4th May 2015 - Using Pred sanpled data and cross corner substation with APC values,
  // this threshold of 64 was able to capture high 1-SSIM distoriton blocks
  UInt Threshold = APCCrossCornSubThresh;

  // YGJ 4th May 2015 - Four test corner test points used.
  UInt AbsAsymCost = 0;

  // YGJ 22nd May 2015 - Calc SSIM  (Based upon img_dist_ssim.c (JM 18.6 H.264 Ref Encoder))
//  float OneMinSSIM = 0.0;  // Assuming Perfect score at this point

  unsigned MaxValue = (1<<bitDepthLuma)-1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;

        // allocate YUV value
        int yInt = 0; 

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc];// int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
        int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
        int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0  || yInt_Rec > 255 || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

        //bool HadRegion = false;
        Distortion iSumHad =0;

        Distortion iSumSAD = 0;
        Distortion sumAPC = 0;
        bool ProceedwAPC = false;

//        //==========
//        // SSIM
//        static const float K1 = 0.01f, K2 = 0.03f;
//        float max_pix_value_sqd;
//        float C1, C2;
//        float win_pixels = (float) (8 * 8);
//        float win_pixels_bias = win_pixels - 1;
//        float mb_ssim, meanOrg, meanEnc;
//        float varOrg, varEnc, covOrgEnc;
//        int imeanOrg, imeanEnc, ivarOrg, ivarEnc, icovOrgEnc;
//        float cur_distortion = 0.0;

//        max_pix_value_sqd = (float) ( MaxValue * MaxValue);
//        C1 = K1 * K1 * max_pix_value_sqd;
//        C2 = K2 * K2 * max_pix_value_sqd;

//        imeanOrg = 0;
//        imeanEnc = 0;
//        ivarOrg  = 0;
//        ivarEnc  = 0;
//        icovOrgEnc = 0;
//        //==========
        
        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-8)) && (x < (width-8)) && ((y % 8 == 0) && (x % 8 == 0)))
        {
          //HadRegion = true;

          for ( unsigned n = 0; n < 8; n++ )
          {
              for ( unsigned m = 0; m < 8; m++ )
              {
                  // y*width + x
                  unsigned yloc8x8 = n*8+m;

                  //Distortion y_Org =
                  ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
                  //Distortion y_Rec =
                  ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

                  ////------------------
                  //// YGJ 12th July 2014
                  //// Please note here the encoder assumes current/reconstructed block is `all zero block'
                  //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
                  //// a -- set up and initialise variables

                  ////------------------

//                  //========
//                  // SSIM
                  
//                  int y_Org = (int)ptrY_Org8x8[yloc8x8];
//                  int y_Rec = (int)ptrY_Rec8x8[yloc8x8];

//                  imeanOrg   += y_Org;
//                  imeanEnc   += y_Rec;
//                  ivarOrg    += y_Org * y_Org;
//                  ivarEnc    += y_Rec * y_Rec;
//                  icovOrgEnc += y_Org * y_Rec;
//                  //========

              }
          }

          TCoeff m1[8][8], m2[8][8], m3[8][8]; 

//            meanOrg = (float) imeanOrg / win_pixels;
//            meanEnc = (float) imeanEnc / win_pixels;

//            varOrg    = ((float) ivarOrg - ((float) imeanOrg) * meanOrg) / win_pixels_bias;
//            varEnc    = ((float) ivarEnc - ((float) imeanEnc) * meanEnc) / win_pixels_bias;
//            covOrgEnc = ((float) icovOrgEnc - ((float) imeanOrg) * meanEnc) / win_pixels_bias;

//            mb_ssim  = (float) ((2.0 * meanOrg * meanEnc + C1) * (2.0 * covOrgEnc + C2));
//            mb_ssim /= (float) (meanOrg * meanOrg + meanEnc * meanEnc + C1) * (varOrg + varEnc + C2);

//            cur_distortion = mb_ssim;

//            //Test Scenarios SSIM of 1, 0 and -1
//            if (cur_distortion >= 1.0 && cur_distortion < 1.01) // avoid float accuracy problem at very low QP(e.g.2)
//              cur_distortion = 1.0;

//            OneMinSSIM = 1- cur_distortion;

          // Here Had with integrated APC is applied based upon a pre-assessment.
          // Inspired from the investigation of Hadamard with multi-scale APC under rate control.
          // Under rate control the perceptual cost activity (via APC) remained high for asymmetric distributed observations
          // Having a pre-assessment which measures the APC for the block edges can determine whether Had or Had with integrated APC should be performed.
          // Unlike Hadamard with multi-scale APC under rate control, to save proccessing time Hadamard with integrated APC is performed.

          Int iStrideOrg = 8;
          Int iStrideCur = 8;

          Int k, i, j, jj;
          // Used now
          Pel* piOrg = ptrY_Org8x8; //piOrg;
          Pel* piCur = ptrY_Rec8x8; //piCur;
          // Used later
          Pel* myOrg = ptrY_Org8x8; //piOrg;
          Pel* myCur = ptrY_Rec8x8; //piCur;
          //
          Int APCVal[64];
          Int iTemp = 0;  // Usomg Int here as difference may be negative.

          // YGJ 21st Aug 2014
          Int HadDiff[64];

          //---------
          // YGJ Mon 25th Aug 2014
          // Like in Rate Control during Had8x8 test (and store) Top, Bottom (rows), Left and Right (columns) for asymmetry.
          // If asymmetrical then proceed with APCwHad else just perform Had.
          // Note the plus 255 is required to centre it at zero

          // Step 1) gather APC cost for Top, Left, Right and Bottom edges (without corners).
          //---

          // YGJ 22nd May 2015
          // Ensure that ACCS is performed where APC can be negative use: HadAPC (which calls Approx_APC_Reflected_1D_wNeg), does not work when all positive.

          // These top corners used later in corner test.
          HadDiff[0] = iTemp = piOrg[0] - piCur[0]; APCVal[0] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
          HadDiff[7] = iTemp = piOrg[7] - piCur[7]; APCVal[7] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

          //---
          piCur += (iStrideCur << 3) - iStrideCur;
          piOrg += (iStrideOrg << 3) - iStrideOrg;

          // These bottom corners used later in corner test.
          HadDiff[56] = iTemp = piOrg[0] - piCur[0]; APCVal[56] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
          HadDiff[63] = iTemp = piOrg[7] - piCur[7]; APCVal[63] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

          //---

          //---

        //  // ----------


          // Sun 23rd Nov 2014
          // Having analysed log calculated values the median value for AbsAsymCost was 48 for APC Multiscale (used in Had and RC Had).
          // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
          // Over 48 million observations were logged, which represented 8.7 million unique records.

//          // YGJ 4th May 2015 - Using Pred sanpled data and cross corner substation with APC values,
//          // this threshold of 64 was able to capture high 1-SSIM distoriton blocks


//          // YGJ 4th May 2015 - Four test corner test points used.
//          UInt
//          AbsAsymCost = abs((abs(APCVal[0])-abs(APCVal[63]))-(abs(APCVal[7])-abs(APCVal[56]))); // Less test points to estimate distortion perceptual variance
          //UInt AbsAsymCost = abs((HadDiff[0]-HadDiff[63])-(HadDiff[7]-HadDiff[56])); // Less test points to estimate distortion perceptual variance
           // As per model: Calc_ACCS_V2 <- abs((Corn_APC$APC0 - Corn_APC$APC63) - (Corn_APC$APC7 - Corn_APC$APC56))
          AbsAsymCost = abs((APCVal[0]-APCVal[63])-(APCVal[7]-APCVal[56]));

          ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

          //---------
          // Depending if the condition is met, different levels of processing is applied.
          // False means Had only. (existing)
          // True means Had with APC (proposed).

          // Step 3) Use a case statement on the bool of the threshold.
          //         For false, use existing method of SAD only on the inner block.
          //         For true, apply proposed method on inner block.
          // This means that processing load adapts dynamically to the conditions of the content.

          // reset piCur and piOrg
          piCur = myCur;
          piOrg = myOrg;

          // create pointer to an array and set it in ProceedwAPC.
          // Set the pointer to point to the HadDiff or HadwAPCDiff.
          // Refer to the pointer in the Hadamard Calculation.

          //Int *ptrDiff;
          sumAPC = 0;
          iSumSAD = 0;


                  for( k = 0; k < 63; k += 8 ) // Just the remaining inner square, between the edge rows and columns
                  {

                      HadDiff[k+0] = iTemp = piOrg[0] - piCur[0]; iSumSAD += abs(iTemp); APCVal[k+0] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0); sumAPC += abs(APCVal[k+0]);
                      HadDiff[k+1] = iTemp = piOrg[1] - piCur[1]; iSumSAD += abs(iTemp); APCVal[k+1] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0); sumAPC += abs(APCVal[k+1]);
                      HadDiff[k+2] = iTemp = piOrg[2] - piCur[2]; iSumSAD += abs(iTemp); APCVal[k+2] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0); sumAPC += abs(APCVal[k+2]);
                      HadDiff[k+3] = iTemp = piOrg[3] - piCur[3]; iSumSAD += abs(iTemp); APCVal[k+3] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0); sumAPC += abs(APCVal[k+3]);
                      HadDiff[k+4] = iTemp = piOrg[4] - piCur[4]; iSumSAD += abs(iTemp); APCVal[k+4] =TComRdCost ::HadAPC((int)piOrg[4], (int)piCur[4], 0); sumAPC += abs(APCVal[k+4]);
                      HadDiff[k+5] = iTemp = piOrg[5] - piCur[5]; iSumSAD += abs(iTemp); APCVal[k+5] =TComRdCost ::HadAPC((int)piOrg[5], (int)piCur[5], 0); sumAPC += abs(APCVal[k+5]);
                      HadDiff[k+6] = iTemp = piOrg[6] - piCur[6]; iSumSAD += abs(iTemp); APCVal[k+6] =TComRdCost ::HadAPC((int)piOrg[6], (int)piCur[6], 0); sumAPC += abs(APCVal[k+6]);
                      HadDiff[k+7] = iTemp = piOrg[7] - piCur[7]; iSumSAD += abs(iTemp); APCVal[k+7] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0); sumAPC += abs(APCVal[k+7]);

                      piCur += iStrideCur;
                      piOrg += iStrideOrg;

                  }

        ////----------------------------


            // End of Multi-Scale APC
            //=============================
            // Beginning of Hadamard with APC

            //Now to add/subtract to the Hadamard Diff.
            //Remember to divide accumulated multi-scale APC by 8 before adding to Diff. -- Not performed. Dampens the extended range by Multi-Scale

            //horizontal
            for (j=0; j < 8; j++)
            {
              jj = j << 3;
              //---------------------
              // Changed to support Had with Integrated APC subject to meeting threshold.


              m2[j][0] = HadDiff[jj  ] + HadDiff[jj+4];
              m2[j][1] = HadDiff[jj+1] + HadDiff[jj+5];
              m2[j][2] = HadDiff[jj+2] + HadDiff[jj+6];
              m2[j][3] = HadDiff[jj+3] + HadDiff[jj+7];
              m2[j][4] = HadDiff[jj  ] - HadDiff[jj+4];
              m2[j][5] = HadDiff[jj+1] - HadDiff[jj+5];
              m2[j][6] = HadDiff[jj+2] - HadDiff[jj+6];
              m2[j][7] = HadDiff[jj+3] - HadDiff[jj+7];

              m1[j][0] = m2[j][0] + m2[j][2];
              m1[j][1] = m2[j][1] + m2[j][3];
              m1[j][2] = m2[j][0] - m2[j][2];
              m1[j][3] = m2[j][1] - m2[j][3];
              m1[j][4] = m2[j][4] + m2[j][6];
              m1[j][5] = m2[j][5] + m2[j][7];
              m1[j][6] = m2[j][4] - m2[j][6];
              m1[j][7] = m2[j][5] - m2[j][7];

              m2[j][0] = m1[j][0] + m1[j][1];
              m2[j][1] = m1[j][0] - m1[j][1];
              m2[j][2] = m1[j][2] + m1[j][3];
              m2[j][3] = m1[j][2] - m1[j][3];
              m2[j][4] = m1[j][4] + m1[j][5];
              m2[j][5] = m1[j][4] - m1[j][5];
              m2[j][6] = m1[j][6] + m1[j][7];
              m2[j][7] = m1[j][6] - m1[j][7];


            }

            //vertical
            for (i=0; i < 8; i++)
            {
              m3[0][i] = m2[0][i] + m2[4][i];
              m3[1][i] = m2[1][i] + m2[5][i];
              m3[2][i] = m2[2][i] + m2[6][i];
              m3[3][i] = m2[3][i] + m2[7][i];
              m3[4][i] = m2[0][i] - m2[4][i];
              m3[5][i] = m2[1][i] - m2[5][i];
              m3[6][i] = m2[2][i] - m2[6][i];
              m3[7][i] = m2[3][i] - m2[7][i];

              m1[0][i] = m3[0][i] + m3[2][i];
              m1[1][i] = m3[1][i] + m3[3][i];
              m1[2][i] = m3[0][i] - m3[2][i];
              m1[3][i] = m3[1][i] - m3[3][i];
              m1[4][i] = m3[4][i] + m3[6][i];
              m1[5][i] = m3[5][i] + m3[7][i];
              m1[6][i] = m3[4][i] - m3[6][i];
              m1[7][i] = m3[5][i] - m3[7][i];

              m2[0][i] = m1[0][i] + m1[1][i];
              m2[1][i] = m1[0][i] - m1[1][i];
              m2[2][i] = m1[2][i] + m1[3][i];
              m2[3][i] = m1[2][i] - m1[3][i];
              m2[4][i] = m1[4][i] + m1[5][i];
              m2[5][i] = m1[4][i] - m1[5][i];
              m2[6][i] = m1[6][i] + m1[7][i];
              m2[7][i] = m1[6][i] - m1[7][i];


            }

            for (i = 0; i < 8; i++)
            {
              for (j = 0; j < 8; j++)
              {
                iSumHad += abs(m2[i][j]);
              }
            }

            iSumHad=((iSumHad+2)>>2);

            ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)] = iSumHad;
            ptrDist_sadAPC[(x >> 3) + (y >> 3)*(width>>3)] = sumAPC;
            ptrbool_ProceedwAPC[(x >> 3) + (y >> 3)*(width>>3)] = ProceedwAPC;

            //printf("HAD 8 x 8 (fixed), iSumHad, %d, iSumSAD, %d, OneMinSSIM, %f, ACCS Threshold, %d, AbsAsymCost, %d, sumAPC, %d, ProceedwAPC, %d \n", iSumHad, iSumSAD, OneMinSSIM, Threshold, AbsAsymCost, sumAPC, ProceedwAPC);

        }
        else if ((y%8 != 0) || (x%8 != 0))
        {
            //////////////////////////
            // YGJ 5th Jan 2015
            // Non-Overlapping 8x8, to be more like Rate Control
            // Use previous values

            iSumHad = ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)];
            sumAPC = ptrDist_sadAPC[(x >> 3) + (y >> 3)*(width>>3)];
            ProceedwAPC = ptrbool_ProceedwAPC[(x >> 3) + (y >> 3)*(width>>3)];
        }


        yInt = yInt_Rec;

//        // Convert YUV to RGB

        int r=0, g=0, b=0;

        //-------------------------
        // YGJ Thurs 28th May 2015
        // Store the QP to array

        if ((y < (height-8)) && (x < (width-8)) )
        {
            if (ProceedwAPC == true)
                imgFrmAsTxt[width * y + x] = ((int)iSumHad+ (int)(sumAPC >> 4));
            else
                imgFrmAsTxt[width * y + x] = (int)iSumHad;
        }
        else
            imgFrmAsTxt[width * y + x] = -1;
        //-------------------------

        if (ProceedwAPC == true)
        {

//              printf("within true for HadPreAssess, heatmap with Had, %d, APC, %d, note APC will be 1/16 then added \n", iSumHad, sumAPC);


            //------------------

            // Using arrays as look up tables to ensure values set are consistent
            int loc = 0; //(int)log2((double)blkwidth) - 3;

            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
            float maxScaled = (float)((float)maxUnscaled * (0.1024));
            float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

            //APC fixed down scale of 1/16
            iSumHad += (sumAPC >> 4);

            Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;


//            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//                printf("Pre Assess Had8x8w-APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//                halfMaxThreshold, iSumHad, halfMaxThreshold);

            float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = ((double)normHad) > 1.0? (float)1.0 : normHad;

            int val =  ((double)normHad) < 0.25? 0 :
                       ((double)normHad) < 0.5? 1 :
                       ((double)normHad) < 0.75? 2 : 3;

//            printf("within true for HadPreAssess, heatmap with Had, %d, APC, %d, note APC will be 1/16 then added, normHad, %f, val, %d \n", iSumHad, sumAPC, normHad, val);


            //------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
            switch (val)
            {
                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                    break;
                case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                    break;
                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                    break;
                default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                    break;
            }
            //------------------

        }
        else
        {
            r = g = b = yInt;
        }

        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;

        // Partitioning -- Not Working?
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; //yInt_RmO;
          g = 0; //yInt_RmO;
          b = 0; //yInt_RmO;
        }
        
        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      //piY += YStride;
      piY_Org += YStride;
      piY_Rec += YStrideRec;
      piY_Part += YStrideRec;

    }


    free(ptrY_Org8x8);
    free(ptrY_Rec8x8);

    free(ptrY_Org);

    free(ptrY_Rec);

    free(ptrY_Part);


    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

    if (m_rawTextData)
    {
        //-------------------------
        // YGJ Thurs 28th May 2015
        // Output vector to txt file
        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
        ofstream DecFrmAsTxt;
        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
        {
            if ((i+1)%width==0)
                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
            else
                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
        }
        DecFrmAsTxt.close();
        //-------------------------
    }
}

Void TAppDecTop::saveFrameAsPNG_Hadamard(TComPic* pcPic)
{


  // unsigned height = m_iSourceHeight;
//   unsigned width = m_iSourceWidth;
  // unsigned FrameRes = (height*width);

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    // YGJ 16th March 2015 - Block size can vary in SSE version.

    Distortion *ptrDist_Had;   ptrDist_Had = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_Had == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];
  char strFactor[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile.c_str());
  strcat(SSIMHeatmap, "DecFrm_HadamardDistortionHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
  strcat(SSIMHeatmap, ".png");

  // YGJ Tues 26th May 2015
  // Store the QP to text file
  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());
  strcat(FrmAsTxt, "DecFrm_HadamardDistortionHeatMap_");
  strcat(FrmAsTxt, strpoc);
  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
  strcat(FrmAsTxt, "_Factor");  strcat(FrmAsTxt, strFactor);
  strcat(FrmAsTxt, ".txt");


  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);
  // YGJ Thurs 28th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

  unsigned MaxValue = (1<<bitDepthLuma)-1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//int prevCloc = 0; // Previous cloc

    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;

        // allocate YUV value
        int yInt = 0; 

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc];
        int yInt_Rec = (int)ptrY_Rec[yloc];  
        int yInt_Part = (int)ptrY_Part[yloc]; 

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0  || yInt_Rec > 255 || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


        bool HadRegion = false;
        Distortion iSumHad =0;

        //if ((y < (height-8)) && (x < (width-8)))

        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-8)) && (x < (width-8)) && ((y % 8 == 0) && (x % 8 == 0)))
        {
          HadRegion = true;

          int HadDiff[64];
          TCoeff m1[8][8], m2[8][8], m3[8][8]; 


            for ( unsigned n = 0; n < 8; n++ )
            {
                for ( unsigned m = 0; m < 8; m++ )
                {
                    // y*width + x
                    unsigned yloc8x8 = n*8+m;

                    Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
                    Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);


                    ////------------------
                    //// YGJ 12th July 2014
                    //// Please note here the encoder assumes current/reconstructed block is `all zero block'
                    //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
                    //// a -- set up and initialise variables

                    ////------------------
                    HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
                    ////-------------------

                }
            }

            int j, jj, i;

            //horizontal
            for (j=0; j < 8; j++)
            {
              jj = j << 3;

              m2[j][0] = HadDiff[jj  ] + HadDiff[jj+4];
              m2[j][1] = HadDiff[jj+1] + HadDiff[jj+5];
              m2[j][2] = HadDiff[jj+2] + HadDiff[jj+6];
              m2[j][3] = HadDiff[jj+3] + HadDiff[jj+7];
              m2[j][4] = HadDiff[jj  ] - HadDiff[jj+4];
              m2[j][5] = HadDiff[jj+1] - HadDiff[jj+5];
              m2[j][6] = HadDiff[jj+2] - HadDiff[jj+6];
              m2[j][7] = HadDiff[jj+3] - HadDiff[jj+7];

              m1[j][0] = m2[j][0] + m2[j][2];
              m1[j][1] = m2[j][1] + m2[j][3];
              m1[j][2] = m2[j][0] - m2[j][2];
              m1[j][3] = m2[j][1] - m2[j][3];
              m1[j][4] = m2[j][4] + m2[j][6];
              m1[j][5] = m2[j][5] + m2[j][7];
              m1[j][6] = m2[j][4] - m2[j][6];
              m1[j][7] = m2[j][5] - m2[j][7];

              m2[j][0] = m1[j][0] + m1[j][1];
              m2[j][1] = m1[j][0] - m1[j][1];
              m2[j][2] = m1[j][2] + m1[j][3];
              m2[j][3] = m1[j][2] - m1[j][3];
              m2[j][4] = m1[j][4] + m1[j][5];
              m2[j][5] = m1[j][4] - m1[j][5];
              m2[j][6] = m1[j][6] + m1[j][7];
              m2[j][7] = m1[j][6] - m1[j][7];
            }

            //vertical
            for (i=0; i < 8; i++)
            {
              m3[0][i] = m2[0][i] + m2[4][i];
              m3[1][i] = m2[1][i] + m2[5][i];
              m3[2][i] = m2[2][i] + m2[6][i];
              m3[3][i] = m2[3][i] + m2[7][i];
              m3[4][i] = m2[0][i] - m2[4][i];
              m3[5][i] = m2[1][i] - m2[5][i];
              m3[6][i] = m2[2][i] - m2[6][i];
              m3[7][i] = m2[3][i] - m2[7][i];

              m1[0][i] = m3[0][i] + m3[2][i];
              m1[1][i] = m3[1][i] + m3[3][i];
              m1[2][i] = m3[0][i] - m3[2][i];
              m1[3][i] = m3[1][i] - m3[3][i];
              m1[4][i] = m3[4][i] + m3[6][i];
              m1[5][i] = m3[5][i] + m3[7][i];
              m1[6][i] = m3[4][i] - m3[6][i];
              m1[7][i] = m3[5][i] - m3[7][i];

              m2[0][i] = m1[0][i] + m1[1][i];
              m2[1][i] = m1[0][i] - m1[1][i];
              m2[2][i] = m1[2][i] + m1[3][i];
              m2[3][i] = m1[2][i] - m1[3][i];
              m2[4][i] = m1[4][i] + m1[5][i];
              m2[5][i] = m1[4][i] - m1[5][i];
              m2[6][i] = m1[6][i] + m1[7][i];
              m2[7][i] = m1[6][i] - m1[7][i];
            }

            for (i = 0; i < 8; i++)
            {
              for (j = 0; j < 8; j++)
              {
                iSumHad += abs(m2[i][j]);
              }
            }

            iSumHad=((iSumHad+2)>>2);

            ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)] = iSumHad;

        }
        else if ((y%8 != 0) || (x%8 != 0))
        {
            //////////////////////////
            // YGJ 5th Jan 2015
            // Non-Overlapping 8x8, to be more like Rate Control
            // Use previous values

            iSumHad = ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)];
            HadRegion = true;
        }

        yInt = yInt_Rec;


        int r = 0; //yInt + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
        int g = 0; //yInt - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
        int b = 0; //yInt + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);

//        //-------------------------

        //-------------------------
        // YGJ Thurs 28th May 2015
        // Store the QP to array
        if ((y < (height-8)) && (x < (width-8)) )
        {

                imgFrmAsTxt[width * y + x] = (int)iSumHad;
        }
        else
            imgFrmAsTxt[width * y + x] = -1;
        //-------------------------


        if (HadRegion == true)
        {
            int blkwidth = 8;

            //------------------

            // Using arrays as look up tables to ensure values set are consistent
            int loc = (int)log2((double)blkwidth) - 3;

            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
            float maxScaled = (float)((float)maxUnscaled * (0.1024));
            float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

            Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

            //------------------

            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
                printf("Had is greater than halfMaxThreshold (%d), iSumHad is %d, will be set to %d \n",
                halfMaxThreshold, iSumHad, halfMaxThreshold);

            // Normalise Had against assumed max.
            float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = ((double)normHad) > 1.0? (float)1.0 : normHad;

            int val =  ((double)normHad) < 0.25? 0 :
                       ((double)normHad) < 0.5? 1 :
                       ((double)normHad) < 0.75? 2 : 3;

            //------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
            switch (val)
            {
                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                    break;
                case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                    break;
                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                    break;
                default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                    break;
            }
            //------------------

        }
        else
        {
            r = g = b = yInt;
        }

        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


        // Partitioning -- Not Working?
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; //yInt_RmO;
          g = 0; //yInt_RmO;
          b = 0; //yInt_RmO;
        }

        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      //piY += YStride;
      piY_Org += YStride;
      piY_Rec += YStrideRec;
      piY_Part += YStrideRec;


    }

    free(ptrY_Org8x8);
    free(ptrY_Rec8x8);

    free(ptrY_Org);

    free(ptrY_Rec);

    free(ptrY_Part);


    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

    if (m_rawTextData)
    {
        //-------------------------
        // YGJ Thurs 28th May 2015
        // Output vector to txt file
        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
        ofstream DecFrmAsTxt;
        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
        {
            if ((i+1)%width==0)
                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
            else
                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
        }
        DecFrmAsTxt.close();
        //-------------------------
    }

}

Void TAppDecTop::saveFrameAsPNG_RateControlHad(TComPic* pcPic)
{

  // unsigned height = m_iSourceHeight;
//   unsigned width = m_iSourceWidth;
  // unsigned FrameRes = (height*width);

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");


    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    Distortion *ptrDist_Had;   ptrDist_Had = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_Had == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  char strpoc[6];
  char strRange[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);
  
  snprintf(strRange, sizeof(strRange), "%d", m_distRange);

  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile.c_str());
  strcat(SSIMHeatmap, "DecFrm_RateCtrlHadActivityHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  strcat(SSIMHeatmap, ".png");

  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());
  strcat(FrmAsTxt, "DecFrm_RateCtrlHadActivityHeatMap_");
  strcat(FrmAsTxt, strpoc);
  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
  strcat(FrmAsTxt, ".txt");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);
  // YGJ Thurs 28th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

  unsigned MaxValue = (1<<bitDepthLuma)-1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;
        
        // allocate YUV value
        int yInt = 0; //, uInt = 0, vInt = 0;

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc]; //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
        int yInt_Part = (int)ptrY_Part[yloc];  //int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0) // || yInt_Rec > 255 || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d \n", yInt_Org); //, yInt_Rec);

        bool HadRegion = false;
        Distortion iSumHad =0;

        // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-8)) && (x < (width-8)) && ((y % 8 == 0) && (x % 8 == 0)))
        {
          HadRegion = true;
          TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;

            for ( unsigned n = 0; n < 8; n++ )
            {
                for ( unsigned m = 0; m < 8; m++ )
                {
                    unsigned yloc8x8 = n*m+m;

                    ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);

                }
            }

            //-------------------------
            //-----

            int i, j, jj; //, k;

            // End of Multi-Scale APC
            //=============================
            // Beginning of Hadamard with APC

            //Now to add/subtract to the Hadamard Diff.
            //Remember to divide accumulated multi-scale APC by 8 before adding to Diff. -- Not performed. Dampens the extended range by Multi-Scale
            //int APCscale = 0;

            //horizontal
            for (j=0; j < 8; j++)
            {
              jj = j << 3;

              m2[j][0] = ptrY_Org8x8[jj  ] + ptrY_Org8x8[jj+4];// + multiscaleAPC[jj  ];
              m2[j][1] = ptrY_Org8x8[jj+1] + ptrY_Org8x8[jj+5];// + multiscaleAPC[jj+1];
              m2[j][2] = ptrY_Org8x8[jj+2] + ptrY_Org8x8[jj+6];// + multiscaleAPC[jj+2];
              m2[j][3] = ptrY_Org8x8[jj+3] + ptrY_Org8x8[jj+7];// + multiscaleAPC[jj+3];
              m2[j][4] = ptrY_Org8x8[jj  ] - ptrY_Org8x8[jj+4];// - multiscaleAPC[jj+4];
              m2[j][5] = ptrY_Org8x8[jj+1] - ptrY_Org8x8[jj+5];// - multiscaleAPC[jj+5];
              m2[j][6] = ptrY_Org8x8[jj+2] - ptrY_Org8x8[jj+6];// - multiscaleAPC[jj+6];
              m2[j][7] = ptrY_Org8x8[jj+3] - ptrY_Org8x8[jj+7];// - multiscaleAPC[jj+7];

              m1[j][0] = m2[j][0] + m2[j][2];
              m1[j][1] = m2[j][1] + m2[j][3];
              m1[j][2] = m2[j][0] - m2[j][2];
              m1[j][3] = m2[j][1] - m2[j][3];
              m1[j][4] = m2[j][4] + m2[j][6];
              m1[j][5] = m2[j][5] + m2[j][7];
              m1[j][6] = m2[j][4] - m2[j][6];
              m1[j][7] = m2[j][5] - m2[j][7];

              m2[j][0] = m1[j][0] + m1[j][1];
              m2[j][1] = m1[j][0] - m1[j][1];
              m2[j][2] = m1[j][2] + m1[j][3];
              m2[j][3] = m1[j][2] - m1[j][3];
              m2[j][4] = m1[j][4] + m1[j][5];
              m2[j][5] = m1[j][4] - m1[j][5];
              m2[j][6] = m1[j][6] + m1[j][7];
              m2[j][7] = m1[j][6] - m1[j][7];
            }

            //vertical
            for (i=0; i < 8; i++)
            {
              m3[0][i] = m2[0][i] + m2[4][i];
              m3[1][i] = m2[1][i] + m2[5][i];
              m3[2][i] = m2[2][i] + m2[6][i];
              m3[3][i] = m2[3][i] + m2[7][i];
              m3[4][i] = m2[0][i] - m2[4][i];
              m3[5][i] = m2[1][i] - m2[5][i];
              m3[6][i] = m2[2][i] - m2[6][i];
              m3[7][i] = m2[3][i] - m2[7][i];

              m1[0][i] = m3[0][i] + m3[2][i];
              m1[1][i] = m3[1][i] + m3[3][i];
              m1[2][i] = m3[0][i] - m3[2][i];
              m1[3][i] = m3[1][i] - m3[3][i];
              m1[4][i] = m3[4][i] + m3[6][i];
              m1[5][i] = m3[5][i] + m3[7][i];
              m1[6][i] = m3[4][i] - m3[6][i];
              m1[7][i] = m3[5][i] - m3[7][i];

              m2[0][i] = m1[0][i] + m1[1][i];
              m2[1][i] = m1[0][i] - m1[1][i];
              m2[2][i] = m1[2][i] + m1[3][i];
              m2[3][i] = m1[2][i] - m1[3][i];
              m2[4][i] = m1[4][i] + m1[5][i];
              m2[5][i] = m1[4][i] - m1[5][i];
              m2[6][i] = m1[6][i] + m1[7][i];
              m2[7][i] = m1[6][i] - m1[7][i];
            }

            for (i = 0; i < 8; i++)
            {
              for (j = 0; j < 8; j++)
              {
                iSumHad += abs(m2[i][j]);
              }
            }
            iSumHad -= abs(m2[0][0]); // Applies only to Activity (Rate Control version of) Had.
            iSumHad =(iSumHad+2)>>2;

            ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)] = iSumHad;

        }
        else if ((y < (height-8)) && (x < (width-8)))  //if ((y%8 != 0) || (x%8 != 0))
        {
            HadRegion = true;

            iSumHad = ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)];
        }

        yInt = yInt_Org;


        int r = 0; //yInt + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
        int g = 0; //yInt - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
        int b = 0; //yInt + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);

        //-------------------------
        // YGJ Thurs 28th May 2015
        // Store the QP to array

        if ((y < (height-8)) && (x < (width-8)) )
        {

                imgFrmAsTxt[width * y + x] = (int)iSumHad;
        }
        else
            imgFrmAsTxt[width * y + x] = -1;
        //-------------------------


        if (HadRegion == true)
        {

            //------------------

            int blkwidth = 8;

            // Using arrays as look up tables to ensure values set are consistent
            int loc = (int)log2((double)blkwidth) - 3;

            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
            float maxScaled = (float)((float)maxUnscaled * (0.1024));

            Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor;

            // For Rate-Control
            halfMaxThreshold <<= 1; // Double

            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;
								   
//            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//                printf("RateControl Had is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//                halfMaxThreshold, iSumHad, halfMaxThreshold);


            float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = ((double)normHad) > 1.0? (float)1.0 : normHad;

            int val =  ((double)normHad) < 0.25? 0 :
                       ((double)normHad) < 0.5? 1 :
                       ((double)normHad) < 0.75? 2 : 3;


            //------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
            switch (val)
            {
                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt); b = min(yInt << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                    break;
                case 1 :  r = 0; g= yInt; b = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                    break;
                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                    break;
                default : r = min(yInt << 1, 255) ;g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                    break;
            }
            //------------------

        }
        else
        {
            r = g = b = yInt;
        }


        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


        // Partitioning -- Not Working?
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; //yInt_RmO;
          g = 0; //yInt_RmO;
          b = 0; //yInt_RmO;
        }



        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      //piY += YStride;
      piY_Org += YStride;
//      piY_Rec += YStrideRec;
      piY_Part += YStrideRec;

    }


    free(ptrY_Org8x8);

    free(ptrY_Org);

    free(ptrY_Part);

    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

    if (m_rawTextData)
    {
        //-------------------------
        // YGJ Thurs 28th May 2015
        // Output vector to txt file
        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
        ofstream DecFrmAsTxt;
        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
        {
            if ((i+1)%width==0)
                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
            else
                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
        }
        DecFrmAsTxt.close();
        //-------------------------
    }

}

Void TAppDecTop::saveFrameAsPNG_RateControlJND(TComPic* pcPic)
{

  // unsigned height = m_iSourceHeight;
//   unsigned width = m_iSourceWidth;
  // unsigned FrameRes = (height*width);

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strRange, sizeof(strRange), "%d", m_distRange);

  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile.c_str());
  strcat(SSIMHeatmap, "DecFrm_RateCtrlJNDActivityHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  strcat(SSIMHeatmap, ".png");

  char FrmAsTxt[255];  strcpy(FrmAsTxt, m_pchSSIMLogAndImageFile.c_str());
  strcat(FrmAsTxt, "DecFrm_RateCtrlJNDActivityHeatMap_");
  strcat(FrmAsTxt, strpoc);
  strcat(FrmAsTxt, "_Range");  strcat(FrmAsTxt, strRange);
  strcat(FrmAsTxt, ".txt");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);
  // YGJ Thurs 28th May 2015
  // Store the QP to array
  std::vector<int> imgFrmAsTxt; imgFrmAsTxt.resize(FrameRes);

  unsigned MaxValue = (1<<bitDepthLuma)-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
    Int   shift = bitDepthLuma-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;


    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;

        // allocate YUV value
        int yInt = 0; //, uInt = 0, vInt = 0;

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc]; //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
        int yInt_Part = (int)ptrY_Part[yloc];  //int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0) // || yInt_Rec > 255 || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d \n", yInt_Org); //, yInt_Rec);


        yInt = yInt_Org;


        int r = 0; //yInt + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
        int g = 0; //yInt - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
        int b = 0; //yInt + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);

        {



            /// YGJ 15th March 2015
            ///
            /// Calc JND
            ///
            /// Uisng formula:
            /// if pixel < 127 then calc: 17 * (1-( pixel/127)^0.5) + 3
            /// else ( for pixel > 126): 3/128 * pixel/127 + 3
            ///
            /// For pixel = 254, JND = 3+3/64 (3.046875)
            /// For pixel = 0, JND = 20.
            ///
            /// Then scale up to range supported by visual heatmap
            /// JND score as int = JND*50
            /// Tested with spreadsheet

            double JND = 0.0;

            if (yInt < 127)
                JND = 17*(1-(pow((double)yInt/127,0.5))) + 3;
            else
                JND = 3/128 * yInt/127 +3;


                imgFrmAsTxt[width * y + x] = (int)JND;
            //-------------------------

            if (JND < 10)
            {

            float JNDMax = 20.0;
            float normJND = (float)(((float)JND)/(JNDMax*0.5));
            normJND = normJND > 1.0? (float)1.0 : normJND;

            int val =  normJND > 0.75? 0 :
                       normJND > 0.5? 1 :
                       normJND > 0.25? 2 : 3;


                //------------------
                // YGJ 27th Oct 2014
                // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
                // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
                switch (val)
                {
                    case 0 : //yInt = JNDScaledUp;
                             r = 0; g = (int)((normJND/(float)0.25)*yInt); b = min(yInt << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                        break;
                    case 1 : //yInt = JNDScaledUp - 256;
                             r = 0; g= yInt; b = (int)(yInt-((normJND-0.25)/(float)0.25)*yInt); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                        break;
                    case 2 : //yInt = JNDScaledUp - 512;
                             r = (int)(((normJND-0.50)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                        break;
                    default : //yInt = JNDScaledUp - 768;
                             r = min(yInt << 1, 255) ;g= (int)(yInt-((normJND-0.75)/(float)0.25)*yInt); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                        break;
                }
            }
            else
            {
                r = g = b = yInt;
            }
            //------------------

        }


        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


        // Partitioning -- Not Working?
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; //yInt_RmO;
          g = 0; //yInt_RmO;
          b = 0; //yInt_RmO;
        }



        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      piY_Org += YStride;
      piY_Part += YStrideRec;

    }


    free(ptrY_Org8x8);

    free(ptrY_Org);

    free(ptrY_Part);

    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

    if (m_rawTextData)
    {
        //-------------------------
        // YGJ Thurs 28th May 2015
        // Output vector to txt file
        // http://stackoverflow.com/questions/10750057/c-printing-out-the-contents-of-a-vector
        ofstream DecFrmAsTxt;
        DecFrmAsTxt.open (FrmAsTxt, ios::out | ios::app);
        for(int i = 0; i < imgFrmAsTxt.size(); ++i)
        {
            if ((i+1)%width==0)
                DecFrmAsTxt << imgFrmAsTxt[i] <<  endl;
            else
                DecFrmAsTxt << imgFrmAsTxt[i] << ", ";
        }
        DecFrmAsTxt.close();
        //-------------------------
    }

}


//! \}
