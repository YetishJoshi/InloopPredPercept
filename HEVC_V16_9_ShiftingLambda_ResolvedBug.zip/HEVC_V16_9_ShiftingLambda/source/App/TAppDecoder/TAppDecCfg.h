/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2016, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     TAppDecCfg.h
    \brief    Decoder configuration class (header)
*/

  //================================
  // YGJ - Modified Decoder
  //================================


#ifndef __TAPPDECCFG__
#define __TAPPDECCFG__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TLibCommon/CommonDef.h"
#include <vector>

//! \ingroup TAppDecoder
//! \{

// ====================================================================================================================
// Class definition
// ====================================================================================================================

/// Decoder configuration class
class TAppDecCfg
{
protected:
  std::string   m_bitstreamFileName;                    ///< input bitstream file name
  std::string   m_reconFileName;                        ///< output reconstruction file name
  Int           m_iSkipFrame;                           ///< counter for frames prior to the random access point to skip
  Int           m_outputBitDepth[MAX_NUM_CHANNEL_TYPE]; ///< bit depth used for writing output
  InputColourSpaceConversion m_outputColourSpaceConvert;

  //================================
  // YGJ
  //----------------
  //SChar*         m_pchRefFile;                         ///< Reference  file to compare Difference and SSIM Heatmaps from -  YGJ 17th July 2013
//  // file I/O
//  std::string m_inputFileName;                                ///< source file name
//  std::string m_bitstreamFileName;                            ///< output bitstream file
//  std::string m_reconFileName;                                ///< output reconstruction file
  std::string         m_pchRefFile;                         ///< Reference  file to compare Difference and SSIM Heatmaps from -  YGJ 3rd April 2016

  //----------------
  Int       m_iSourceWidth;                                   ///< source width in pixel
  Int       m_iSourceHeight;                                  ///< source height in pixel (when interlaced = field height)
  Int       m_frameoutput;
  Int       m_distWidthSize;                        ///< Set the width size of the distortion measures
  Int       m_distRange;                        ///< Set the range  of the distortion measures between 0 and 20, which reflect the range of norm distribution scale 
  Int       m_SADFactor;                        ///< Affects SAD and Had (not Had RC - activity) Set the factor to divide the max threshold range by, will be between 0 to 16. 
  Int       m_maxCUsize;                        ///< Set the max size for a Coding Unit in terms of bits - part of heatmap
  // YGJ 1st Sept 2014
  Int       m_inputChromaFormat;                           ///< Same as TypeDef.h "CHROMA_400 = 0, CHROMA_420 = 1, CHROMA_422 = 2, CHROMA_444 = 3,")
  //SChar*     m_pchSSIMLogAndImageFile;                     ///< Location and Name of the SSIMandSSE Log and SSIM/Partition Image file
  std::string         m_pchSSIMLogAndImageFile;              ///< Location and Name of the SSIMandSSE Log and SSIM/Partition Image file -  YGJ 3rd April 2016
  Int       m_outputSSIMAndSSELog;                      ///< Save log file of SSIM and SSE for each frame
  Int      m_outputSSIMHeatmaps;                          ///< Whether or not to output SSIM Heat maps, 0 = false, 1 = true
  Int      m_outputFrmPartition;                          ///< Whether or not to output SSIM Heat maps, 0 = false, 1 = true
   // coding tools (bit-depth)
  Int       m_inputBitDepthY;                               ///< bit-depth of input file (luma component)
  Int       m_inputBitDepthC;                               ///< bit-depth of input file (chroma component)
  Int       m_internalBitDepth[MAX_NUM_CHANNEL_TYPE];       ///< bit depth used for writing output
  Int       m_rawTextData;                                  ///< Outputs Image values as uncompressed raw text data (very large files)
  //-------------------  
  //================================

  Int           m_iMaxTemporalLayer;                  ///< maximum temporal layer to be decoded
  Int           m_decodedPictureHashSEIEnabled;       ///< Checksum(3)/CRC(2)/MD5(1)/disable(0) acting on decoded picture hash SEI message
  Bool          m_decodedNoDisplaySEIEnabled;         ///< Enable(true)/disable(false) writing only pictures that get displayed based on the no display SEI message
  std::string   m_colourRemapSEIFileName;             ///< output Colour Remapping file name
  std::vector<Int> m_targetDecLayerIdSet;             ///< set of LayerIds to be included in the sub-bitstream extraction process.
  Int           m_respectDefDispWindow;               ///< Only output content inside the default display window
#if O0043_BEST_EFFORT_DECODING
  UInt          m_forceDecodeBitDepth;                ///< if non-zero, force the bit depth at the decoder (best effort decoding)
#endif
  std::string   m_outputDecodedSEIMessagesFilename;   ///< filename to output decoded SEI messages to. If '-', then use stdout. If empty, do not output details.
  Bool          m_bClipOutputVideoToRec709Range;      ///< If true, clip the output video to the Rec 709 range on saving.

public:
  TAppDecCfg()
  : m_bitstreamFileName()
  , m_reconFileName()
  , m_iSkipFrame(0)
  // m_outputBitDepth array initialised below
  , m_outputColourSpaceConvert(IPCOLOURSPACE_UNCHANGED)
  //================================
  // YGJ
  //---------------
  , m_pchRefFile(NULL) ///< Reference  file to compare Difference and SSIM Heatmaps from -  YGJ 17th July 2013
  , m_iSourceWidth(0)
  , m_iSourceHeight(0)
  , m_frameoutput(0)
  , m_distWidthSize(8)
  , m_distRange(8)
  , m_SADFactor(0)
  , m_maxCUsize(2048)
  , m_inputChromaFormat(1)
  , m_pchSSIMLogAndImageFile(NULL)
  , m_outputSSIMAndSSELog(0)
  , m_outputSSIMHeatmaps(0)
  , m_outputFrmPartition (0)  
  //-------------
  , m_inputBitDepthY(0)
  , m_inputBitDepthC(0)
  //---------------  
  , m_rawTextData (0)
  //================================
  , m_iMaxTemporalLayer(-1)
  , m_decodedPictureHashSEIEnabled(0)
  , m_decodedNoDisplaySEIEnabled(false)
  , m_colourRemapSEIFileName()
  , m_targetDecLayerIdSet()
  , m_respectDefDispWindow(0)
#if O0043_BEST_EFFORT_DECODING
  , m_forceDecodeBitDepth(0)
#endif
  , m_outputDecodedSEIMessagesFilename()
  , m_bClipOutputVideoToRec709Range(false)
  {
    for (UInt channelTypeIndex = 0; channelTypeIndex < MAX_NUM_CHANNEL_TYPE; channelTypeIndex++)
    {
      m_outputBitDepth[channelTypeIndex] = 0;
    }
  }

  virtual ~TAppDecCfg() {}

  Bool  parseCfg        ( Int argc, TChar* argv[] );   ///< initialize option class from configuration
};

//! \}

#endif


