/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2016, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     TComRdCost.h
    \brief    RD cost computation classes (header)
*/

  //================================
  // YGJ - This file has modified to allow te prediction values to be passed through to calculate the perceptual distortion assessment
  //================================


#ifndef __TCOMRDCOST__
#define __TCOMRDCOST__


#include "CommonDef.h"
#include "TComPattern.h"
#include "TComMv.h"

#include "TComSlice.h"
#include "TComRdCostWeightPrediction.h"

#include  <math.h>

//! \ingroup TLibCommon
//! \{

class DistParam;
class TComPattern;

// ====================================================================================================================
// Type definition
// ====================================================================================================================

// for function pointer
typedef Distortion (*FpDistFunc) (DistParam*); // TODO: can this pointer be replaced with a reference? - there are no NULL checks on pointer.

// ====================================================================================================================
// Class definition
// ====================================================================================================================

/// distortion parameter class
class DistParam
{
public:
  const Pel*            pOrg;
  const Pel*            pCur;
  const Pel*  		pPred;  // YGJ 26th July 2014 - Req for when assessing Quantised Transform of Residual only. This allows perceptual distortion measure to account for actual value than just relative.
  Int                   iStrideOrg;
  Int                   iStrideCur;
  Int   iStridePred;  // YGJ 26th July 2014 - Req for when assessing Quantised Transform of Residual only. This allows perceptual distortion measure to account for actual value than just relative.
  Int                   iRows;
  Int                   iCols;
  Int                   iStep;
  FpDistFunc            DistFunc;
  Int                   bitDepth;

  Bool                  bApplyWeight;     // whether weighted prediction is used or not
  Bool                  bIsBiPred;

  const WPScalingParam *wpCur;           // weighted prediction scaling parameters for current ref
  ComponentID           compIdx;
  Distortion            m_maximumDistortionForEarlyExit; /// During cost calculations, if distortion exceeds this value, cost calculations may early-terminate.

  // (vertical) subsampling shift (for reducing complexity)
  // - 0 = no subsampling, 1 = even rows, 2 = every 4th, etc.
  Int             iSubShift;



  DistParam()
   : pOrg(NULL),
     pCur(NULL),
     pPred(NULL),    // YGJ 26th July 2014 - Req for when assessing Quantised Transform of Residual only. This allows perceptual distortion measure to account for actual value than just relative.
     iStrideOrg(0),
     iStrideCur(0),
     iStridePred(0),  // YGJ 26th July 2014 - Req for when assessing Quantised Transform of Residual only. This allows perceptual distortion measure to account for actual value than just relative.
     iRows(0),
     iCols(0),
     iStep(1),
     DistFunc(NULL),
     bitDepth(0),
     bApplyWeight(false),
     bIsBiPred(false),
     wpCur(NULL),
     compIdx(MAX_NUM_COMPONENT),
     m_maximumDistortionForEarlyExit(std::numeric_limits<Distortion>::max()),
     iSubShift(0)//,
	 //m_iLambdaPVCScale(0)
  { }
};

/// RD cost computation class
class TComRdCost
{
private:
  // for distortion

  FpDistFunc              m_afpDistortFunc[DF_TOTAL_FUNCTIONS]; // [eDFunc]
  CostMode                m_costMode;
  Double                  m_distortionWeight[MAX_NUM_COMPONENT]; // only chroma values are used.
  Double                  m_dLambda;
  Double                  m_sqrtLambda;
  Double                  m_dLambdaMotionSAD[2 /* 0=standard, 1=for transquant bypass when mixed-lossless cost evaluation enabled*/];
  Double                  m_dLambdaMotionSSE[2 /* 0=standard, 1=for transquant bypass when mixed-lossless cost evaluation enabled*/];
  Double                  m_dFrameLambda;

  // for motion cost
  TComMv                  m_mvPredictor;
  Double                  m_motionLambda;
  Int                     m_iCostScale;



public:
  TComRdCost();
  virtual ~TComRdCost();

  Double calcRdCost( Double numBits, Double distortion, DFunc eDFunc = DF_DEFAULT );

  Void    setDistortionWeight  ( const ComponentID compID, const Double distortionWeight ) { m_distortionWeight[compID] = distortionWeight; }
  Void    setLambda      ( Double dLambda, const BitDepths &bitDepths );
  Void    setFrameLambda ( Double dLambda ) { m_dFrameLambda = dLambda; }

  Double  getSqrtLambda ()   { return m_sqrtLambda; }

  Double  getLambda() { return m_dLambda; }
  Double  getChromaWeight () { return ((m_distortionWeight[COMPONENT_Cb] + m_distortionWeight[COMPONENT_Cr]) / 2.0); }

  Void    setCostMode(CostMode   m )    { m_costMode = m; }

  //============

  // YGJ Thurs 31st March 2016
  // Passing perceptual homogenity scaling cost.
  // Integer, with a max 16 and min of zero.
  // The score is based upon the number of edges detected, which is restricted to 1/4 block size.
  // For 4x4 this is 1, 8x8 it is 2, 16x16: 4, 32x32: 8 and 64x64: 16.
  // This is limited to SSE, square block based assessment which is used in mode decision.
  // It will control lambda PVC cost which is added to lambda.
  // The variable will be set by RDcost and retrived by TEncSlice::compressSlice to pass to TEncRateCtrol.
  // Two functions will be created to access this variable, one protected, setLambdaPVCScale and another public getLambdaPVCScale.
  // Void   setLambdaPVCScale(int NumOfEdge) { m_iLambdaPVCScale = NumOfEdge; }

  //============

  // Distortion Functions
  Void    init();

  Void    setDistParam( UInt uiBlkWidth, UInt uiBlkHeight, DFunc eDFunc, DistParam& rcDistParam );
  Void    setDistParam( const TComPattern* const pcPatternKey, const Pel* piRefY, Int iRefStride,            DistParam& rcDistParam );
  Void    setDistParam( const TComPattern* const pcPatternKey, const Pel* piRefY, Int iRefStride, Int iStep, DistParam& rcDistParam, Bool bHADME=false );
  Void    setDistParam( DistParam& rcDP, Int bitDepth, const Pel* p1, Int iStride1, const Pel* p2, Int iStride2, Int iWidth, Int iHeight, Bool bHadamard = false );

  Distortion calcHAD(Int bitDepth, const Pel* pi0, Int iStride0, const Pel* pi1, Int iStride1, Int iWidth, Int iHeight );

  // for motion cost
  static UInt    xGetExpGolombNumberOfBits( Int iVal );
  Void    selectMotionLambda( Bool bSad, Int iAdd, Bool bIsTransquantBypass ) { m_motionLambda = (bSad ? m_dLambdaMotionSAD[(bIsTransquantBypass && m_costMode==COST_MIXED_LOSSLESS_LOSSY_CODING) ?1:0] + iAdd : m_dLambdaMotionSSE[(bIsTransquantBypass && m_costMode==COST_MIXED_LOSSLESS_LOSSY_CODING)?1:0] + iAdd); }
  Void    setPredictor( TComMv& rcMv )
  {
    m_mvPredictor = rcMv;
  }
  Void    setCostScale( Int iCostScale )    { m_iCostScale = iCostScale; }
  Distortion getCost( UInt b )                 { return Distortion(( m_motionLambda * b ) / 65536.0); }
  Distortion getCostOfVectorWithPredictor( const Int x, const Int y )
  {
    return Distortion((m_motionLambda * getBitsOfVectorWithPredictor(x, y)) / 65536.0);
  }
  UInt getBitsOfVectorWithPredictor( const Int x, const Int y )
  {
    return xGetExpGolombNumberOfBits((x << m_iCostScale) - m_mvPredictor.getHor())
    +      xGetExpGolombNumberOfBits((y << m_iCostScale) - m_mvPredictor.getVer());
  }

  //================================
  // YGJ 
  // Low call frequency, so it is fine to perform use an inline if statement. This way APC_Aligned_1D is half the size, and it is already large.
  static const int RCHadAPC(unsigned char OrgPx1, unsigned char OrgPx2, unsigned char ShiftBy ){return (int) (OrgPx1 > OrgPx2 ?
                  (APC_Aligned_1D[((OrgPx1 >> BitDiff) << 8) + ((abs(OrgPx1-OrgPx2)) >> BitDiff)]) >> ShiftBy
                : (APC_Aligned_1D[((OrgPx2 >> BitDiff) << 8) + ((abs(OrgPx2-OrgPx1)) >> BitDiff)]) >> ShiftBy );};

  // YGJ 21st May 2015 - Using Approx_APC_Aligned_1D instead of APC_Aligned_1D to reduce memory requirements.
  static const int HadAPC(unsigned char Org, unsigned char Rec, unsigned char ShiftBy ){return (int)
                  ((Approx_APC_Reflected_1D_wNeg[((Org >> BitDiff) << LUT_Wx2) + LUToffset + ((Org-Rec) >> BitDiff)]) >> ShiftBy);};
  //================================

private:

  static Distortion xGetSSE           ( DistParam* pcDtParam );
  static Distortion xGetSSE4          ( DistParam* pcDtParam );
  static Distortion xGetSSE8          ( DistParam* pcDtParam );
  static Distortion xGetSSE16         ( DistParam* pcDtParam );
  static Distortion xGetSSE32         ( DistParam* pcDtParam );
  static Distortion xGetSSE64         ( DistParam* pcDtParam );
  static Distortion xGetSSE16N        ( DistParam* pcDtParam );

  static Distortion xGetSAD           ( DistParam* pcDtParam );
  static Distortion xGetSAD4          ( DistParam* pcDtParam );
  static Distortion xGetSAD8          ( DistParam* pcDtParam );
  static Distortion xGetSAD16         ( DistParam* pcDtParam );
  static Distortion xGetSAD32         ( DistParam* pcDtParam );
  static Distortion xGetSAD64         ( DistParam* pcDtParam );
  static Distortion xGetSAD16N        ( DistParam* pcDtParam );

  static Distortion xGetSAD12         ( DistParam* pcDtParam );
  static Distortion xGetSAD24         ( DistParam* pcDtParam );
  static Distortion xGetSAD48         ( DistParam* pcDtParam );

  static Distortion xGetHADs          ( DistParam* pcDtParam );
  static Distortion xCalcHADs2x2      ( const Pel *piOrg, const Pel *piCurr, Int iStrideOrg, Int iStrideCur, Int iStep );
  static Distortion xCalcHADs4x4      ( const Pel *piOrg, const Pel *piCurr, Int iStrideOrg, Int iStrideCur, Int iStep );
  static Distortion xCalcHADs8x8      ( const Pel *piOrg, const Pel *piCurr, Int iStrideOrg, Int iStrideCur, Int iStep );

  //================================
  // YGJ 7th Nov 2014
  static UInt BitDiff;

  // YGJ 4th Sept 2015
  static UInt BitDepthShifted;

  // YGJ 21st May 2015
  static UInt BitDiffplus2;
  static const UInt LUT_Wx1 = 6;   // LUT width times 1
  static const UInt LUT_Wx2 = 7;  // must be used with LUToffset
  static const UInt LUToffset = 63; // must be used with LUT_Wx2 to centre align starting point

  // YGJ 22nd May 2015 - threshold closest to the 3rd quartile value of 52
  // for given distribution based on 30k sampled observation of raw pixel data taken at prediction stage
  static const UInt APCCrossCornSubThresh = 128; // Used in Had and SAD where ACCS determines if APC is required.
  static const UInt APC_Downscale = 7; // Used in Had and SAD where APC score is downscaled by 1/128. Based on decoder simulator log. 32k obs. Minor yet significant change.

  // YGJ 13th Oct 2014
  static int              m_thresholdAdjust; // Used by APC in SAd and Hadamard to adjust the threshold as sqrt Lambda increase above 16.
  static int              m_scaleCost; // Used to scale down the pxost of APC in SAD and Had and in SASD in SSE as sqrt Lambda increases above 16 and then again above 32.,
  static unsigned int     m_thresholdMin;

  // YGJ 13th Oct 2014
  // As lambda increases the associated threshold for SAD and Hadamard increases and the perceptual cost reduces.
  // the R-D curve for the proposed and existing begin to converge at QP 37 (sqrt lambda of 16) and again at QP 43 (sqrt lambda 32).
  //void setThresholdAdjust() {m_thresholdAdjust = max(0, ((int)getSqrtLambda()) - 16);}
  // YGJ 2nd Nov 2015 
  // Trying to lower the threshold as QP increases.
  // First set one or other to zero.
  // Did that setThresh just increased time, suspect the use of max
  // setScale decreased PSNR by the smallest possible amount and also increase bit usage of b-frame by a tiny anount from 960 to 1000.
  // Testing with CrowdRun 3 frame test.
  //void setThresholdAdjust() {m_thresholdAdjust = max(0, ((int)getSqrtLambda()) - 16);}
  //void setThresholdAdjust() {m_thresholdAdjust = min(0, (int)getSqrtLambda() - 32) ;}
  // Instead of casting using lrint part of C99 standard to cast double to int efficiently
  //void setThresholdAdjust() {m_thresholdAdjust = (int)getSqrtLambda() - 32 ;}
  void setThresholdAdjust() {m_thresholdAdjust = 0;} //lrint(getSqrtLambda()) - 32 ;}
  void setScaleCost() {m_scaleCost = (int)getSqrtLambda() < 16 ? 0 : (int)getSqrtLambda() < 32 ? 1 : 2;}
  //void setScaleCost() {m_scaleCost = lrint(getSqrtLambda()) < 16 ? 0 : lrint(getSqrtLambda()) < 32 ? 1 : 2;}

  // YGJ 31st Aug 2014 - Used gather Additional Pixel Cost (APC) for SAD, hadamard transform and hadamard in rate control
  // APC_Aligned_1D - used by exclusively by SAD - 1D array aligned so each row represents the original pixel intensity
  // and the offset is the absolute difference for the given SAD operation.
  // APC_NegAndPos_1D - used by the hadamard operations where sign of the difference, and thus sign of the APC score is important.
  static  const unsigned char Approx_APC_Aligned_1D[4096];
  static  const unsigned char Approx_APC_Reflected_1D[8192];
  static  const signed char Approx_APC_Reflected_1D_wNeg[8192];

  static  const unsigned char APC_Aligned_1D[65536];

  // YGJ Fri 21st Aug 2015
  // Prediction corner threshold LUT
  // Created as a single threshold of 128 for all sub-blocks was causing issues in mode decision
  // Mode decision has thresholds that scale with block size and this was missing with the initial coruner check
  // Note this is a 1D array amust be accessed by [col + row*width], in this case from 0 to 63.
  // Update, missing width 6, now is 9x9
//  static  const unsigned char PredCrnThresh_LUT[81];
  static  const unsigned short PredCrnThresh_LUT[81];

  // YGJ 1st Nov 2014 - Used to calc SASD >> 8 using a LUT and without absolute function.
  //static  const unsigned char SASD_LUTwoAbs[131072];


  // YGJ Fri 4th Sept 2015 - Split up LUT due to race condition during testing and to improve efficent use of memory. Divided large LUT (131072) to 16 smaller LUTs (16384)


  static const unsigned char SASD_LUTwoAbs_0[16384];
  static const unsigned char SASD_LUTwoAbs_16[16384];
  static const unsigned char SASD_LUTwoAbs_32[16384];
  static const unsigned char SASD_LUTwoAbs_48[16384];

  static const unsigned char SASD_LUTwoAbs_64[16384];
  static const unsigned char SASD_LUTwoAbs_80[16384];
  static const unsigned char SASD_LUTwoAbs_96[16384];
  static const unsigned char SASD_LUTwoAbs_112[16384];

  static const unsigned char SASD_LUTwoAbs_128[16384];
  static const unsigned char SASD_LUTwoAbs_144[16384];
  static const unsigned char SASD_LUTwoAbs_160[16384];
  static const unsigned char SASD_LUTwoAbs_176[16384];

  static const unsigned char SASD_LUTwoAbs_192[16384];
  static const unsigned char SASD_LUTwoAbs_208[16384];
  static const unsigned char SASD_LUTwoAbs_224[16384];
  static const unsigned char SASD_LUTwoAbs_240[16384];


  static const unsigned char SASD_LUTwoAbs(Pel Orig, Intermediate_Int iTemp);



  //================================

  static const Pel Zero4[4];
  static const Pel Zero8[8];
  static const Pel Zero16[16];
  static const Pel Zero32[32];
  static const Pel Zero64[64];


public:

  Distortion   getDistPart(Int bitDepth, const Pel* piCur, Int iCurStride, const Pel* piOrg, Int iOrgStride, UInt uiBlkWidth, UInt uiBlkHeight, const ComponentID compID, DFunc eDFunc = DF_SSE );
  
  //================================
  // YGJ
  static int  getThresholdAdjust() {return m_thresholdAdjust;}
  static int  getScaleCost() {return m_scaleCost;}
  static unsigned int getMinThreshold() {return m_thresholdMin;}
  //================================

  //================================
  //YGJ 31st Aug 2014 - Added a version with support for Pred (when Quantised Residue is used)
  Distortion   getDistPartwPred(Int bitDepth,
                           Pel* piPred,
                           Int iPredStride,
                           Pel* piCur,
                           Int iCurStride,
                           Pel* piOrg,
                           Int iOrgStride,
                           UInt uiBlkWidth,
                           UInt uiBlkHeight,
                           const ComponentID compID,
                           DFunc eDFunc = DF_SSE );

  //================================

  //================================
  // YGJ 25th June 2015 - store bit depth minus 8.
  int getBitDiff(){return BitDiff;}
  void setBitDiff(int LumaBitDepth){BitDiff = LumaBitDepth-8;}
  //================================



};// END CLASS DEFINITION TComRdCost

//! \}

#endif // __TCOMRDCOST__
