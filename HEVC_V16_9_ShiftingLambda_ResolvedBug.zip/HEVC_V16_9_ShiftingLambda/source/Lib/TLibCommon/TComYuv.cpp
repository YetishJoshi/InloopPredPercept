/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2016, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     TComYuv.cpp
    \brief    general YUV buffer class
    \todo     this should be merged with TComPicYuv
*/

  //================================
  // YGJ - This file has modified to allow te prediction values to be passed through to calculate the perceptual distortion assessment.
  // Used by encoder and decoder.
  // HighFreq function - applying Ticket 1212, to avoid invalid negative or exceeding bitdepth
  //================================

#include <stdlib.h>
#include <memory.h>
#include <assert.h>
#include <math.h>

#include "CommonDef.h"
#include "TComYuv.h"
#include "TComInterpolationFilter.h"

//! \ingroup TLibCommon
//! \{

TComYuv::TComYuv()
{
  for(Int comp=0; comp<MAX_NUM_COMPONENT; comp++)
  {
    m_apiBuf[comp] = NULL;
  }
}

TComYuv::~TComYuv()
{
  destroy();
}

Void TComYuv::create( UInt iWidth, UInt iHeight, ChromaFormat chromaFormatIDC )
{
  destroy();
  // set width and height
  m_iWidth   = iWidth;
  m_iHeight  = iHeight;
  m_chromaFormatIDC = chromaFormatIDC;

  for(Int comp=0; comp<MAX_NUM_COMPONENT; comp++)
  {
    // memory allocation
    m_apiBuf[comp]  = (Pel*)xMalloc( Pel, getWidth(ComponentID(comp))*getHeight(ComponentID(comp)) );
  }
}

Void TComYuv::destroy()
{
  // memory free
  for(Int comp=0; comp<MAX_NUM_COMPONENT; comp++)
  {
    if (m_apiBuf[comp]!=NULL)
    {
      xFree( m_apiBuf[comp] );
      m_apiBuf[comp] = NULL;
    }
  }
}

Void TComYuv::clear()
{
  for(Int comp=0; comp<MAX_NUM_COMPONENT; comp++)
  {
    if (m_apiBuf[comp]!=NULL)
    {
      ::memset( m_apiBuf[comp], 0, ( getWidth(ComponentID(comp)) * getHeight(ComponentID(comp))  )*sizeof(Pel) );
    }
  }
}




Void TComYuv::copyToPicYuv   ( TComPicYuv* pcPicYuvDst, const UInt ctuRsAddr, const UInt uiAbsZorderIdx, const UInt uiPartDepth, const UInt uiPartIdx ) const
{
  for(Int comp=0; comp<getNumberValidComponents(); comp++)
  {
    copyToPicComponent  ( ComponentID(comp), pcPicYuvDst, ctuRsAddr, uiAbsZorderIdx, uiPartDepth, uiPartIdx );
  }
}

Void TComYuv::copyToPicComponent  ( const ComponentID compID, TComPicYuv* pcPicYuvDst, const UInt ctuRsAddr, const UInt uiAbsZorderIdx, const UInt uiPartDepth, const UInt uiPartIdx ) const
{
  const Int iWidth  = getWidth(compID) >>uiPartDepth;
  const Int iHeight = getHeight(compID)>>uiPartDepth;

  const Pel* pSrc     = getAddr(compID, uiPartIdx, iWidth);
        Pel* pDst     = pcPicYuvDst->getAddr ( compID, ctuRsAddr, uiAbsZorderIdx );

  const UInt  iSrcStride  = getStride(compID);
  const UInt  iDstStride  = pcPicYuvDst->getStride(compID);

  for ( Int y = iHeight; y != 0; y-- )
  {
    ::memcpy( pDst, pSrc, sizeof(Pel)*iWidth);
    pDst += iDstStride;
    pSrc += iSrcStride;
  }
}


//================================
//-----------------------------
// YGJ 31st Aug 2014 - Where Partitions are shown
// This is used by the decoder to save frames as PNG files with mode decision block partitions.

Void TComYuv::copyToPicYuvWPart   ( TComPicYuv* pcPicYuvDst, const UInt iCuAddr, const UInt uiAbsZorderIdx, const UInt uiPartDepth, const UInt uiPartIdx ) const
{
  for(Int ch=0; ch<getNumberValidComponents(); ch++)
    copyToPicComponentWPart  ( ComponentID(ch), pcPicYuvDst, iCuAddr, uiAbsZorderIdx, uiPartDepth, uiPartIdx );
}

Void TComYuv::copyToPicComponentWPart  ( const ComponentID ch, TComPicYuv* pcPicYuvDst, const UInt iCuAddr, const UInt uiAbsZorderIdx, const UInt uiPartDepth, const UInt uiPartIdx ) const
{
  const Int iWidth  = getWidth(ch) >>uiPartDepth;
  const Int iHeight = getHeight(ch)>>uiPartDepth;

  const Pel* pSrc     = getAddr(ch, uiPartIdx, iWidth);
        Pel* pDst     = pcPicYuvDst->getAddr ( ch, iCuAddr, uiAbsZorderIdx );

  const UInt  iSrcStride  = getStride(ch);
  const UInt  iDstStride  = pcPicYuvDst->getStride(ch);

  // For Luma Channel (it is zero, when on the edge set to zero - see  enum ComponentID in TypeDef.h)
  if (ch == 0)
	{
	  Pel *pBlk, *pBlkWidth; // As source, Destination and copy selection can be different size, need two, on for pixel and one block width
	  pBlk = (Pel *)calloc(1, sizeof(Pel)); //Null/Zero acts as edge.
	  pBlkWidth = (Pel *)calloc(iWidth, sizeof(Pel)); //Null/Zero acts as edge.

      for (Int y = iHeight; y != 0; y-- )
	  {
        if (y == iHeight)
        {
          //Bottom  Edge (assuming  zero is top left hand corner)
          ::memcpy( pDst, pBlkWidth, sizeof(Pel)*iWidth);                
          pDst += iDstStride;		
          pSrc += iSrcStride;
        }
        else
        {
          // Left Hand Side Edge
          ::memcpy( pDst, pBlk, sizeof(Pel));            	
          pDst++;
		  pSrc++;
          //Copy remaining as is
          ::memcpy( pDst, pSrc, sizeof(Pel)*(iWidth-1));
          pDst += (iDstStride-1); // Width minus one -  account for the pixel set to NULL to act as an edge
		  pSrc += (iSrcStride-1);
        }
      }
	}
	else //For non-Luma channel copy as per normal 
	{
	  for ( Int y = iHeight; y != 0; y-- )
	  {
		::memcpy( pDst, pSrc, sizeof(Pel)*iWidth);
		pDst += iDstStride;
		pSrc += iSrcStride;
	  }
	}

}

//-----------------------------
// YGJ 5th Oct 2014 - QP-Partitions Heat
// This is used by the decoder to save frames as PNG files with mode decision block partitions.

Void TComYuv::copyToPicYuvWQPPart   ( TComPicYuv* pcPicYuvDst, const UInt iCuAddr, const UInt uiAbsZorderIdx, const UInt uiQP, const UInt uiSkipFlag, const UInt uiPartDepth, const UInt uiPartIdx ) const
{
  //printf("copyToPicYuvWQPPart: pBlk (uiQP %d) (skip flag %d): ", (int)uiQP,  (int)uiSkipFlag);


  for(Int ch=0; ch<getNumberValidComponents(); ch++)
    copyToPicComponentWQPPart  ( ComponentID(ch), pcPicYuvDst, iCuAddr, uiAbsZorderIdx, uiQP, uiSkipFlag, uiPartDepth, uiPartIdx );
}

Void TComYuv::copyToPicComponentWQPPart  ( const ComponentID ch, TComPicYuv* pcPicYuvDst, const UInt iCuAddr, const UInt uiAbsZorderIdx, const UInt uiQP, const UInt uiSkipFlag, const UInt uiPartDepth, const UInt uiPartIdx ) const
{
  const Int iWidth  = getWidth(ch) >>uiPartDepth;
  const Int iHeight = getHeight(ch)>>uiPartDepth;

  const Pel* pSrc     = getAddr(ch, uiPartIdx, iWidth);
        Pel* pDst     = pcPicYuvDst->getAddr ( ch, iCuAddr, uiAbsZorderIdx );

  const UInt  iSrcStride  = getStride(ch);
  const UInt  iDstStride  = pcPicYuvDst->getStride(ch);

  Pel *pBlk;
  pBlk = (Pel *)calloc(iWidth, sizeof(Pel)); //Null/Zero acts as edge.


  if (ch == 0) //QP Value
  {
      Pel qp = (Pel)uiQP;

      // Set up with QP
      for ( Int x = 0; x < iWidth; x++ )  {
          pBlk[x] = qp;
      }
  }
  else // Skip Value
  {
      Pel skip = (Pel)uiSkipFlag;

      // Set up with QP
      for ( Int x = 0; x < iWidth; x++ )  {
          pBlk[x] = skip;
      }

  }

   // { // Back to normal (no partitions)
      for ( Int y = iHeight; y != 0; y-- )
      {
                ::memcpy( pDst, pBlk, sizeof(Pel)*iWidth);

            pDst += iDstStride;
            pSrc += iSrcStride;

      }
  //}

//      // YGJ 26th June 2015
//      // Logging out iWidth and iHeight.
//      // Expect them to be sq, same values, 4x4, 8x8, 16x16, 32x32 and 64x64
//      // Need to test to confirm

//      if ( iWidth != iHeight || (iWidth != 4 && iWidth != 8 && iWidth != 16 && iWidth != 32 && iWidth != 64) )
//        printf("copyToPicComponentWQPPart, iWidth, %d,  iHeight, %d \n", iWidth, iHeight);

//      // Great, nothing logged.
//      // It can be assumed that all blocks are sq and valid values are 4, 8, 16, 32 and 64.


}

//-----------------------------
// YGJ 9th Oct 2014 - Bit Usage
// This is used by the decoder to save frames as PNG files with mode decision block partitions.

Void TComYuv::copyToPicYuv_CU_BitUsage   ( TComPicYuv* pcPicYuvDst, const UInt iCuAddr, const UInt uiAbsZorderIdx, const UInt px[4], const UInt uiPartDepth, const UInt uiPartIdx ) const
{

  for(Int ch=0; ch<getNumberValidComponents(); ch++)
    copyToPicComponent_CU_BitUsage  ( ComponentID(ch), pcPicYuvDst, iCuAddr, uiAbsZorderIdx, px, uiPartDepth, uiPartIdx );
}

Void TComYuv::copyToPicComponent_CU_BitUsage  ( const ComponentID ch, TComPicYuv* pcPicYuvDst, const UInt iCuAddr, const UInt uiAbsZorderIdx, const UInt px[4], const UInt uiPartDepth, const UInt uiPartIdx ) const
{
  const Int iWidth  = getWidth(ch) >>uiPartDepth;
  const Int iHeight = getHeight(ch)>>uiPartDepth;

  const Pel* pSrc     = getAddr(ch, uiPartIdx, iWidth);
        Pel* pDst     = pcPicYuvDst->getAddr ( ch, iCuAddr, uiAbsZorderIdx );

  const UInt  iSrcStride  = getStride(ch);
  const UInt  iDstStride  = pcPicYuvDst->getStride(ch);

  Pel *pBlk;
  pBlk = (Pel *)calloc(iWidth, sizeof(Pel)); //Null/Zero acts as edge.


    // Set up with bits cost across 4 px values (8x4 = potential cost upto 2^32)
    for ( Int x = 0; x < 4; x++ )  {
        pBlk[x] = px[x];
    }


    // Save cost to first four pixels of every row in block
    for ( Int y = iHeight; y != 0; y-- )
    {
                
        ::memcpy( pDst, pBlk, sizeof(Pel)*4);

        pDst += iDstStride;
        pSrc += iSrcStride;

    }
////------------------------

}

//-----------------------------
// YGJ 5th Oct 2014 - QP-Partitions Heat
// This is used by the decoder to save frames as PNG files with mode decision block partitions.

Void TComYuv::copyToPicYuvWPartSize   ( TComPicYuv* pcPicYuvDst, const UInt iCuAddr, const UInt uiAbsZorderIdx, const UInt uiPartDepth, const UInt uiPartIdx ) const
{
  for(Int ch=0; ch<getNumberValidComponents(); ch++)
    copyToPicComponentWPartSize  ( ComponentID(ch), pcPicYuvDst, iCuAddr, uiAbsZorderIdx, uiPartDepth, uiPartIdx );
}

Void TComYuv::copyToPicComponentWPartSize  ( const ComponentID ch, TComPicYuv* pcPicYuvDst, const UInt iCuAddr, const UInt uiAbsZorderIdx, const UInt uiPartDepth, const UInt uiPartIdx ) const
{
  const Int iWidth  = getWidth(ch) >>uiPartDepth;
  const Int iHeight = getHeight(ch)>>uiPartDepth;

  const Pel* pSrc     = getAddr(ch, uiPartIdx, iWidth);
        Pel* pDst     = pcPicYuvDst->getAddr ( ch, iCuAddr, uiAbsZorderIdx );

  const UInt  iSrcStride  = getStride(ch);
  const UInt  iDstStride  = pcPicYuvDst->getStride(ch);

  Pel *pBlk;
  pBlk = (Pel *)calloc(iWidth, sizeof(Pel)); //Null/Zero acts as edge.


  //if (ch == 0) //Block size (width and height are the same value)
  //{

//      Pel size = (Pel)iHeight;; //(Pel)iWidth;

      // Set up with block width in all cells in row
      for ( Int x = 0; x < iWidth; x++ )  {
          pBlk[x] = (Pel)iHeight; //size;
      }
  //}


   // { // Back to normal (no partitions)
   // copy to all rows.
      for ( Int y = iHeight; y != 0; y-- )
      {
                ::memcpy( pDst, pBlk, sizeof(Pel)*iWidth);

            pDst += iDstStride;
            pSrc += iSrcStride;

      }
  //}

//      // YGJ 26th June 2015
//      // Logging out iWidth and iHeight.
//      // Expect them to be sq, same values, 4x4, 8x8, 16x16, 32x32 and 64x64
//      // Need to test to confirm

//      if (iWidth < 16 ) //( iWidth != iHeight || (iWidth != 4 && iWidth != 8 && iWidth != 16 && iWidth != 32 && iWidth != 64) )
//        printf("copyToPicComponentWQPPart, iWidth, %d,  iHeight, %d \n", iWidth, iHeight);
//          printf("pBlk[x], %d, %d, %d, %d \n", pBlk[0], pBlk[1], pBlk[2], pBlk[3]);

//      // Great, nothing logged.
//      // It can be assumed that all blocks are sq and valid values are 4, 8, 16, 32 and 64.


}


//================================


Void TComYuv::copyFromPicYuv   ( const TComPicYuv* pcPicYuvSrc, const UInt ctuRsAddr, const UInt uiAbsZorderIdx )
{
  for(Int comp=0; comp<getNumberValidComponents(); comp++)
  {
    copyFromPicComponent  ( ComponentID(comp), pcPicYuvSrc, ctuRsAddr, uiAbsZorderIdx );
  }
}

Void TComYuv::copyFromPicComponent  ( const ComponentID compID, const TComPicYuv* pcPicYuvSrc, const UInt ctuRsAddr, const UInt uiAbsZorderIdx )
{
        Pel* pDst     = getAddr(compID);
  const Pel* pSrc     = pcPicYuvSrc->getAddr ( compID, ctuRsAddr, uiAbsZorderIdx );

  const UInt iDstStride  = getStride(compID);
  const UInt iSrcStride  = pcPicYuvSrc->getStride(compID);
  const Int  iWidth=getWidth(compID);
  const Int  iHeight=getHeight(compID);

  for (Int y = iHeight; y != 0; y-- )
  {
    ::memcpy( pDst, pSrc, sizeof(Pel)*iWidth);
    pDst += iDstStride;
    pSrc += iSrcStride;
  }
}




Void TComYuv::copyToPartYuv( TComYuv* pcYuvDst, const UInt uiDstPartIdx ) const
{
  for(Int comp=0; comp<getNumberValidComponents(); comp++)
  {
    copyToPartComponent  ( ComponentID(comp), pcYuvDst, uiDstPartIdx );
  }
}

Void TComYuv::copyToPartComponent( const ComponentID compID, TComYuv* pcYuvDst, const UInt uiDstPartIdx ) const
{
  const Pel* pSrc     = getAddr(compID);
        Pel* pDst     = pcYuvDst->getAddr( compID, uiDstPartIdx );

  const UInt iSrcStride  = getStride(compID);
  const UInt iDstStride  = pcYuvDst->getStride(compID);
  const Int  iWidth=getWidth(compID);
  const Int  iHeight=getHeight(compID);

  for (Int y = iHeight; y != 0; y-- )
  {
    ::memcpy( pDst, pSrc, sizeof(Pel)*iWidth);
    pDst += iDstStride;
    pSrc += iSrcStride;
  }
}




Void TComYuv::copyPartToYuv( TComYuv* pcYuvDst, const UInt uiSrcPartIdx ) const
{
  for(Int comp=0; comp<getNumberValidComponents(); comp++)
  {
    copyPartToComponent  ( ComponentID(comp), pcYuvDst, uiSrcPartIdx );
  }
}

Void TComYuv::copyPartToComponent( const ComponentID compID, TComYuv* pcYuvDst, const UInt uiSrcPartIdx ) const
{
  const Pel* pSrc     = getAddr(compID, uiSrcPartIdx);
        Pel* pDst     = pcYuvDst->getAddr(compID, 0 );

  const UInt  iSrcStride  = getStride(compID);
  const UInt  iDstStride  = pcYuvDst->getStride(compID);

  const UInt uiHeight = pcYuvDst->getHeight(compID);
  const UInt uiWidth = pcYuvDst->getWidth(compID);

  for ( UInt y = uiHeight; y != 0; y-- )
  {
    ::memcpy( pDst, pSrc, sizeof(Pel)*uiWidth);
    pDst += iDstStride;
    pSrc += iSrcStride;
  }
}




Void TComYuv::copyPartToPartYuv   ( TComYuv* pcYuvDst, const UInt uiPartIdx, const UInt iWidth, const UInt iHeight ) const
{
  for(Int comp=0; comp<getNumberValidComponents(); comp++)
  {
    copyPartToPartComponent   (ComponentID(comp), pcYuvDst, uiPartIdx, iWidth>>getComponentScaleX(ComponentID(comp)), iHeight>>getComponentScaleY(ComponentID(comp)) );
  }
}

Void TComYuv::copyPartToPartComponent  ( const ComponentID compID, TComYuv* pcYuvDst, const UInt uiPartIdx, const UInt iWidthComponent, const UInt iHeightComponent ) const
{
  const Pel* pSrc =           getAddr(compID, uiPartIdx);
        Pel* pDst = pcYuvDst->getAddr(compID, uiPartIdx);
  if( pSrc == pDst )
  {
    //th not a good idea
    //th best would be to fix the caller
    return ;
  }

  const UInt  iSrcStride = getStride(compID);
  const UInt  iDstStride = pcYuvDst->getStride(compID);
  for ( UInt y = iHeightComponent; y != 0; y-- )
  {
    ::memcpy( pDst, pSrc, iWidthComponent * sizeof(Pel) );
    pSrc += iSrcStride;
    pDst += iDstStride;
  }
}




Void TComYuv::copyPartToPartComponentMxN  ( const ComponentID compID, TComYuv* pcYuvDst, const TComRectangle &rect) const
{
  const Pel* pSrc =           getAddrPix( compID, rect.x0, rect.y0 );
        Pel* pDst = pcYuvDst->getAddrPix( compID, rect.x0, rect.y0 );
  if( pSrc == pDst )
  {
    //th not a good idea
    //th best would be to fix the caller
    return ;
  }

  const UInt  iSrcStride = getStride(compID);
  const UInt  iDstStride = pcYuvDst->getStride(compID);
  const UInt uiHeightComponent=rect.height;
  const UInt uiWidthComponent=rect.width;
  for ( UInt y = uiHeightComponent; y != 0; y-- )
  {
    ::memcpy( pDst, pSrc, uiWidthComponent * sizeof( Pel ) );
    pSrc += iSrcStride;
    pDst += iDstStride;
  }
}




Void TComYuv::addClip( const TComYuv* pcYuvSrc0, const TComYuv* pcYuvSrc1, const UInt uiTrUnitIdx, const UInt uiPartSize, const BitDepths &clipBitDepths )
{
  for(Int comp=0; comp<getNumberValidComponents(); comp++)
  {
    const ComponentID compID=ComponentID(comp);
    const Int uiPartWidth =uiPartSize>>getComponentScaleX(compID);
    const Int uiPartHeight=uiPartSize>>getComponentScaleY(compID);

    const Pel* pSrc0 = pcYuvSrc0->getAddr(compID, uiTrUnitIdx, uiPartWidth );
    const Pel* pSrc1 = pcYuvSrc1->getAddr(compID, uiTrUnitIdx, uiPartWidth );
          Pel* pDst  = getAddr(compID, uiTrUnitIdx, uiPartWidth );

    const UInt iSrc0Stride = pcYuvSrc0->getStride(compID);
    const UInt iSrc1Stride = pcYuvSrc1->getStride(compID);
    const UInt iDstStride  = getStride(compID);
    const Int clipbd = clipBitDepths.recon[toChannelType(compID)];
#if O0043_BEST_EFFORT_DECODING
    const Int bitDepthDelta = clipBitDepths.stream[toChannelType(compID)] - clipbd;
#endif

    for ( Int y = uiPartHeight-1; y >= 0; y-- )
    {
      for ( Int x = uiPartWidth-1; x >= 0; x-- )
      {
#if O0043_BEST_EFFORT_DECODING
        pDst[x] = Pel(ClipBD<Int>( Int(pSrc0[x]) + rightShiftEvenRounding<Pel>(pSrc1[x], bitDepthDelta), clipbd));
#else
        pDst[x] = Pel(ClipBD<Int>( Int(pSrc0[x]) + Int(pSrc1[x]), clipbd));
#endif
      }
      pSrc0 += iSrc0Stride;
      pSrc1 += iSrc1Stride;
      pDst  += iDstStride;
    }
  }
}




Void TComYuv::subtract( const TComYuv* pcYuvSrc0, const TComYuv* pcYuvSrc1, const UInt uiTrUnitIdx, const UInt uiPartSize )
{
  for(Int comp=0; comp<getNumberValidComponents(); comp++)
  {
    const ComponentID compID=ComponentID(comp);
    const Int uiPartWidth =uiPartSize>>getComponentScaleX(compID);
    const Int uiPartHeight=uiPartSize>>getComponentScaleY(compID);

    const Pel* pSrc0 = pcYuvSrc0->getAddr( compID, uiTrUnitIdx, uiPartWidth );
    const Pel* pSrc1 = pcYuvSrc1->getAddr( compID, uiTrUnitIdx, uiPartWidth );
          Pel* pDst  = getAddr( compID, uiTrUnitIdx, uiPartWidth );

    const Int  iSrc0Stride = pcYuvSrc0->getStride(compID);
    const Int  iSrc1Stride = pcYuvSrc1->getStride(compID);
    const Int  iDstStride  = getStride(compID);

    for (Int y = uiPartHeight-1; y >= 0; y-- )
    {
      for (Int x = uiPartWidth-1; x >= 0; x-- )
      {
        pDst[x] = pSrc0[x] - pSrc1[x];
      }
      pSrc0 += iSrc0Stride;
      pSrc1 += iSrc1Stride;
      pDst  += iDstStride;
    }
  }
}




Void TComYuv::addAvg( const TComYuv* pcYuvSrc0, const TComYuv* pcYuvSrc1, const UInt iPartUnitIdx, const UInt uiWidth, const UInt uiHeight, const BitDepths &clipBitDepths )
{
  for(Int comp=0; comp<getNumberValidComponents(); comp++)
  {
    const ComponentID compID=ComponentID(comp);
    const Pel* pSrc0  = pcYuvSrc0->getAddr( compID, iPartUnitIdx );
    const Pel* pSrc1  = pcYuvSrc1->getAddr( compID, iPartUnitIdx );
    Pel* pDst   = getAddr( compID, iPartUnitIdx );

    const UInt  iSrc0Stride = pcYuvSrc0->getStride(compID);
    const UInt  iSrc1Stride = pcYuvSrc1->getStride(compID);
    const UInt  iDstStride  = getStride(compID);
    const Int   clipbd      = clipBitDepths.recon[toChannelType(compID)];
    const Int   shiftNum    = std::max<Int>(2, (IF_INTERNAL_PREC - clipbd)) + 1;
    const Int   offset      = ( 1 << ( shiftNum - 1 ) ) + 2 * IF_INTERNAL_OFFS;

    const Int   iWidth      = uiWidth  >> getComponentScaleX(compID);
    const Int   iHeight     = uiHeight >> getComponentScaleY(compID);

    if (iWidth&1)
    {
      assert(0);
      exit(-1);
    }
    else if (iWidth&2)
    {
      for ( Int y = 0; y < iHeight; y++ )
      {
        for (Int x=0 ; x < iWidth; x+=2 )
        {
          pDst[ x + 0 ] = ClipBD( rightShift(( pSrc0[ x + 0 ] + pSrc1[ x + 0 ] + offset ), shiftNum), clipbd );
          pDst[ x + 1 ] = ClipBD( rightShift(( pSrc0[ x + 1 ] + pSrc1[ x + 1 ] + offset ), shiftNum), clipbd );
        }
        pSrc0 += iSrc0Stride;
        pSrc1 += iSrc1Stride;
        pDst  += iDstStride;
      }
    }
    else
    {
      for ( Int y = 0; y < iHeight; y++ )
      {
        for (Int x=0 ; x < iWidth; x+=4 )
        {
          pDst[ x + 0 ] = ClipBD( rightShift(( pSrc0[ x + 0 ] + pSrc1[ x + 0 ] + offset ), shiftNum), clipbd );
          pDst[ x + 1 ] = ClipBD( rightShift(( pSrc0[ x + 1 ] + pSrc1[ x + 1 ] + offset ), shiftNum), clipbd );
          pDst[ x + 2 ] = ClipBD( rightShift(( pSrc0[ x + 2 ] + pSrc1[ x + 2 ] + offset ), shiftNum), clipbd );
          pDst[ x + 3 ] = ClipBD( rightShift(( pSrc0[ x + 3 ] + pSrc1[ x + 3 ] + offset ), shiftNum), clipbd );
        }
        pSrc0 += iSrc0Stride;
        pSrc1 += iSrc1Stride;
        pDst  += iDstStride;
      }
    }
  }
}

Void TComYuv::removeHighFreq( const TComYuv* pcYuvSrc,
                              const UInt uiPartIdx,
                              const UInt uiWidth,
                              const UInt uiHeight,
                              const Int bitDepths[MAX_NUM_CHANNEL_TYPE],
                              const Bool bClipToBitDepths
                              )
{
  for(Int comp=0; comp<getNumberValidComponents(); comp++)
  {
    const ComponentID compID=ComponentID(comp);

    //================================
    // YGJ - This file has modified to allow te prediction values to be passed through to calculate the perceptual distortion assessment.
    // Used by encoder and decoder.
    // HighFreq function - applying Ticket 1212, to avoid invalid negative or exceeding bitdepth
    // https://hevc.hhi.fraunhofer.de/trac/hevc/ticket/1212
    //
    // This proposed resolution of Motion Estimation clipping is required for prediction level perceptual assessment via LUT to be stable.
    //
    // From software maintainers:
    //    Resolution set to wontfix
    //    Status changed from assigned to closed
    //
    // The JCTVC previously decided that clipping could be
    // disabled at this point for the benefit of run-time
    // knowing that clipping was useful. Clipping has not
    // been removed from the code, just disabled.
    //
    // This patch proposes to add a modified form of clipping
    // back into the code. This seems to be opposite to the
    // previous direction of the JCTVC, and therefore any
    // such changes should be discussed by the committee.

    //================================

    // YGJ - added to have max bitdepth value to reference against
    int iMaxValBitDepth = (1<<bitDepths[toChannelType(compID)]) - 1; //(1 << g_bitDepth[0])-1;
    const Pel* pSrc  = pcYuvSrc->getAddr(compID, uiPartIdx);
    Pel* pDst  = getAddr(compID, uiPartIdx);

    const Int iSrcStride = pcYuvSrc->getStride(compID);
    const Int iDstStride = getStride(compID);
    const Int iWidth  = uiWidth >>getComponentScaleX(compID);
    const Int iHeight = uiHeight>>getComponentScaleY(compID);
    if (bClipToBitDepths)
    {
      const Int clipBd=bitDepths[toChannelType(compID)];
      for ( Int y = iHeight-1; y >= 0; y-- )
      {
        for ( Int x = iWidth-1; x >= 0; x-- )
        {
          pDst[x ] = ClipBD((2 * pDst[x]) - pSrc[x], clipBd);
        }
        pSrc += iSrcStride;
        pDst += iDstStride;
      }
    }
    else
    {
      for ( Int y = iHeight-1; y >= 0; y-- )
      {
        for ( Int x = iWidth-1; x >= 0; x-- )
        {
	     //================================
		 // YGJ 
         //pDst[x ] = (2 * pDst[x]) - pSrc[x];
         // Applied Fix as stated in Ticket 1212.		 
		 // Apply same as if bClipToBitDepths is enabled. - No too rigid
		 //pDst[x ] = ClipBD((2 * pDst[x]) - pSrc[x], clipBd);
		 //Fix ensures pixel values are within Range.
         int Dst2 = pDst[x]<<1;
		 pDst[x ] = pSrc[x ] > (Dst2 + 1) && pSrc[x] <= Dst2-iMaxValBitDepth ?
         Dst2 - pSrc[x ] : pDst[x ];
		 		 
         //================================
        }
        pSrc += iSrcStride;
        pDst += iDstStride;
      }
    }
  }
}

//! \}
